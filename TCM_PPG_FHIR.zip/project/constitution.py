def calculate_constitution(answer):

    score = {
        "pinghe": 0,
        "qixu": 0,
        "yangxu": 0,
        "yinxu": 0,
        "tanshi": 0,
        "shire": 0,
        "xueyu": 0,
        "qiyu": 0,
        "tebing": 0
    }

    for q in answer:
        constitution_type = q["type"]
        value = q["score"]

        if constitution_type in score:
            score[constitution_type] += value

    return score



def get_main_type(score):

    return max(
        score,
        key=score.get
    )
@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

set "PYTHON_CMD="
where py >nul 2>nul && set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  where python >nul 2>nul && set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  echo [ERROR] Python 3 was not found.
  echo Please install Python 3.11 or newer and enable "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/4] Creating virtual environment...
  %PYTHON_CMD% -m venv .venv || goto :error
)
set "PY=.venv\Scripts\python.exe"

echo [2/4] Installing required packages...
"%PY%" -m pip install --disable-pip-version-check -r requirements.txt || goto :error

echo [3/4] Initializing database...
"%PY%" database.py || goto :error

echo [4/4] Starting website in DEBUG/visible-console mode...
echo URL: http://127.0.0.1:5000/
echo Close this window or press Ctrl+C to stop the server.
set "AUTO_OPEN_BROWSER=1"
"%PY%" app.py
goto :eof

:error
echo.
echo Startup failed. Check the error above.
pause
exit /b 1

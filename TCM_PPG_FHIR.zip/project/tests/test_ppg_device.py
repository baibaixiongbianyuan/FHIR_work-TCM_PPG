from ppg_device import parse_sensor_line


def test_json_line_without_hrv():
    d=parse_sensor_line('{"heartRate":72,"oxygen":98,"confidence":95}')
    assert d["heartRate"]==72
    assert d["spo2"]==98
    assert d["hrv"] is None


def test_key_value_line():
    d=parse_sensor_line('heartRate=73 oxygen=97 hrv=41')
    assert d["heartRate"]==73 and d["spo2"]==97 and d["hrv"]==41


def test_csv_line_hrv_optional():
    d=parse_sensor_line('75,98')
    assert d["heartRate"]==75 and d["spo2"]==98 and d["hrv"] is None

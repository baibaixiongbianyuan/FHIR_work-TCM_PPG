import os,tempfile,unittest
fd,path=tempfile.mkstemp(suffix='.db'); os.close(fd); os.environ['FHIR_DB_PATH']=path
from app import app,init_db
from seed_demo import generate_samples,replace_local_demo

class FhirApiTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  init_db(); replace_local_demo(generate_samples()); cls.client=app.test_client()
 @classmethod
 def tearDownClass(cls):
  try: os.remove(path)
  except FileNotFoundError: pass
 def login(self,u,p): return self.client.post('/auth/login',json={'username':u,'password':p})
 def test_roles_and_patient_scope(self):
  self.assertEqual(self.login('patient','patient123').status_code,200)
  self.assertEqual(self.client.get('/EMR/Patient/001').status_code,200)
  self.assertEqual(self.client.get('/admin/users').status_code,403)
 def test_constitution_uses_observation_and_clinical_impression(self):
  self.login('patient','patient123')
  b=self.client.get('/EMR/Patient/001').get_json(); rs=[e['resource'] for e in b['entry']]
  self.assertFalse(any(r['resourceType']=='Condition' for r in rs))
  self.assertTrue(any(r['resourceType']=='ClinicalImpression' for r in rs))
  score=next(r for r in rs if r.get('id')=='tcm-constitution-scores-001')
  self.assertEqual(len(score['component']),9)
 def test_questionnaires(self):
  q=self.client.get('/questionnaire-schema').get_json(); self.assertEqual(len(q['items']),45)
  o=self.client.get('/odor-questionnaire-schema').get_json(); self.assertEqual(len(o['items']),5)
 def test_full_patient_assessment_voice_and_odor(self):
  self.login('patient','patient123')
  data={'family':'Test','given':'User','gender':'unknown','birthDate':'2000-01-01','heartRate':72,'spo2':98,'hrv':42,'voiceRmsDb':-20.2,'voicePitchHz':180.5,'voiceDuration':4.2,'breathRate':16,'odor1':True}
  data.update({f'q{i}':((i-1)%5)+1 for i in range(1,46)})
  r=self.client.post('/patient/assessment',json=data); self.assertEqual(r.status_code,200)
  b=self.client.get('/EMR/Patient/001').get_json(); rs=[e['resource'] for e in b['entry']]
  self.assertTrue(any(str(x.get('id','')).startswith('odor-response-') for x in rs))
  self.assertTrue(any(str(x.get('id','')).startswith('voice-pitch-') for x in rs))
 def test_clinician_note_and_admin(self):
  self.login('clinician','clinician123'); r=self.client.post('/clinician/note/001',json={'note':'建議追蹤趨勢。'}); self.assertEqual(r.status_code,200)
  self.client.post('/auth/logout'); self.login('admin','admin123'); self.assertEqual(self.client.get('/admin/users').status_code,200); self.assertEqual(self.client.get('/admin/audit').status_code,200)

if __name__=='__main__': unittest.main()

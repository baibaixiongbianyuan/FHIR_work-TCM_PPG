from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone
from typing import Any

from questions import questions

TZ_TAIPEI = timezone(timedelta(hours=8))

QUESTION_OPTIONS = {"1":"從不","2":"很少","3":"有時","4":"經常","5":"總是"}
CONSTITUTION_LABELS = {
    "pinghe":"平和質","qixu":"氣虛質","yangxu":"陽虛質","yinxu":"陰虛質",
    "tanshi":"痰濕質","shire":"濕熱質","xueyu":"血瘀質","qiyu":"氣鬱質","tebing":"特稟質"
}
CONSTITUTION_ADVICE = {
    "pinghe":"整體問卷表現較均衡，建議維持規律作息、均衡飲食與適度運動。",
    "qixu":"問卷較偏向疲倦、氣短等表現，建議留意休息與循序漸進的活動安排。",
    "yangxu":"問卷較偏向怕冷或手腳冰冷，建議注意保暖並維持規律作息。",
    "yinxu":"問卷較偏向口乾、燥熱或睡眠不安，建議補充水分並避免過度熬夜。",
    "tanshi":"問卷較偏向身體沉重、困倦等表現，建議維持適量活動並注意飲食均衡。",
    "shire":"問卷較偏向口苦、出油或悶熱感，建議清淡飲食並維持良好作息。",
    "xueyu":"問卷較偏向瘀青、固定部位不適等表現，建議持續紀錄並由專業人員綜合判讀。",
    "qiyu":"問卷較偏向壓力、情緒低落或胸悶，建議安排放鬆活動並保持規律運動。",
    "tebing":"問卷較偏向敏感或過敏相關表現，建議留意可能誘發因素並做好日常紀錄。",
}
ODOR_QUESTIONS = [
    ("odor-1", "最近是否覺得口氣和平常不同？"),
    ("odor-2", "汗液是否出現明顯或和平常不同的氣味？"),
    ("odor-3", "痰液是否有和平常不同的氣味？"),
    ("odor-4", "大小便氣味是否和平常明顯不同？"),
    ("odor-5", "是否出現其他和平常不同的體味？"),
]


def _answer_item(link_id: str, text: str, score: int) -> dict[str, Any]:
    score = max(1, min(5, int(score)))
    code = str(score)
    return {"linkId": link_id, "text": text, "answer": [{"valueCoding":{"code":code,"display":QUESTION_OPTIONS[code]}}]}


def score_constitution(data: dict[str, Any]) -> tuple[dict[str,int], str]:
    scores = {k:0 for k in CONSTITUTION_LABELS}
    for q in questions:
        score = int(data.get(f"q{q['id']}", 3))
        if score < 1 or score > 5:
            raise ValueError("問卷分數須介於 1～5")
        scores[q["type"]] += score
    main = max(scores, key=scores.get)
    return scores, main


def build_constitution_questionnaire() -> dict[str, Any]:
    return {
        "resourceType":"Questionnaire","id":"tcm-body-constitution-q","status":"active",
        "url":"https://example.org/fhir/Questionnaire/tcm-body-constitution",
        "title":"中醫九大體質問卷（教學版初步評估）",
        "description":"45 題教學示範問卷，每種體質 5 題；結果僅供健康紀錄與競賽展示，不作為醫療診斷。",
        "subjectType":["Patient"],
        "item":[{
            "linkId":str(q["id"]),"text":q["question"],"type":"choice",
            "answerOption":[{"valueCoding":{"code":str(i),"display":QUESTION_OPTIONS[str(i)]}} for i in range(1,6)]
        } for q in questions]
    }


def build_odor_questionnaire() -> dict[str, Any]:
    return {
        "resourceType":"Questionnaire","id":"tcm-odor-q","status":"active",
        "url":"https://example.org/fhir/Questionnaire/tcm-odor-self-report",
        "title":"聞診氣味自述問卷",
        "description":"氣味資料由使用者主觀填寫，並非感測器直接量測。",
        "subjectType":["Patient"],
        "item":[{"linkId":qid,"text":text,"type":"boolean"} for qid,text in ODOR_QUESTIONS]
    }


def generate_samples_from_input(data: dict[str, Any]) -> list[dict[str, Any]]:
    now = datetime.now(TZ_TAIPEI).replace(microsecond=0)
    # 健康紀錄時間使用實際擷取/儲存當下，不再為 Demo 人為加 1～2 分鐘。
    measured = now
    issued = now

    family = str(data.get("family", "Test")).strip() or "Test"
    given = str(data.get("given", "Subject")).strip() or "Subject"
    gender = str(data.get("gender", "unknown"))
    if gender not in {"male","female","other","unknown"}: raise ValueError("性別欄位格式不正確")
    birth_date = str(data.get("birthDate", "2000-01-01"))
    heart_rate = int(data.get("heartRate",72)); spo2 = int(data.get("spo2",98)); hrv = int(data.get("hrv",42))
    if not 30 <= heart_rate <= 220: raise ValueError("心率須介於 30–220 次／分鐘")
    if not 70 <= spo2 <= 100: raise ValueError("血氧飽和度須介於 70–100%")
    if not 1 <= hrv <= 300: raise ValueError("HRV RMSSD 須介於 1–300 毫秒")

    scores, main = score_constitution(data)
    questionnaire_answers = [_answer_item(str(q["id"]), q["question"], int(data.get(f"q{q['id']}",3))) for q in questions]
    label = CONSTITUTION_LABELS[main]
    advice = CONSTITUTION_ADVICE[main]

    data_source = str(data.get("dataSource","manual")).strip().lower()
    if data_source not in {"device","manual","mixed"}: data_source="manual"
    device_fields = {str(x) for x in (data.get("deviceFields") or []) if str(x) in {"heartRate","spo2","hrv"}}
    if data_source=="device" and not device_fields: device_fields={"heartRate","spo2","hrv"}
    if data_source=="manual": device_fields=set()
    device_name = str(data.get("deviceName","MAX30101 + MAX32664 PPG Sensor")).strip()
    manufacturer = str(data.get("manufacturer","Competition Prototype")).strip()
    model = str(data.get("modelNumber","MAX30101/MAX32664")).strip()
    serial_port = str(data.get("serialPort","")).strip()

    score_components = []
    for key,val in scores.items():
        score_components.append({"code":{"text":CONSTITUTION_LABELS[key]},"valueInteger":val})

    resources: list[dict[str,Any]] = [
        {"resourceType":"Organization","id":"org001","active":True,"name":"TCM PPG FHIR Competition Demo Clinic"},
        {"resourceType":"Patient","id":"001","identifier":[{"system":"https://example.org/patient-id","value":"001"}],
         "name":[{"family":family,"given":[given]}],"gender":gender,"birthDate":birth_date,
         "managingOrganization":{"reference":"Organization/org001"}},
        {"resourceType":"Person","id":"person-patient-001","name":[{"family":family,"given":[given]}],
         "link":[{"target":{"reference":"Patient/001"},"assurance":"level3"}]},
        {"resourceType":"Practitioner","id":"practitioner-001","active":True,"name":[{"text":"示範醫護人員"}]},
        *([{"resourceType":"Device","id":"ppg001","status":"active","deviceName":[{"name":device_name,"type":"user-friendly-name"}],
         "manufacturer":manufacturer,"modelNumber":model,"patient":{"reference":"Patient/001"},
         **({"identifier":[{"system":"https://example.org/serial-port","value":serial_port}]} if serial_port else {})}] if data_source in {"device","mixed"} else []),
        {"resourceType":"Device","id":"mic001","status":"active","deviceName":[{"name":"Browser Microphone","type":"user-friendly-name"}],
         "manufacturer":"Client device","modelNumber":"Web Audio API","patient":{"reference":"Patient/001"}},
        {"resourceType":"Encounter","id":"enc001","status":"finished","class":{"system":"http://terminology.hl7.org/CodeSystem/v3-ActCode","code":"AMB","display":"ambulatory"},
         "type":[{"text":"中醫數位四診輔助評估"}],"subject":{"reference":"Patient/001"},"period":{"start":now.isoformat(),"end":issued.isoformat()}},
        build_constitution_questionnaire(), build_odor_questionnaire(),
        {"resourceType":"QuestionnaireResponse","id":"tcm-response-001","status":"completed","questionnaire":"Questionnaire/tcm-body-constitution-q",
         "subject":{"reference":"Patient/001"},"authored":now.isoformat(),"item":questionnaire_answers},
        {"resourceType":"Observation","id":"hr001","status":"final","category":[{"coding":[{"system":"http://terminology.hl7.org/CodeSystem/observation-category","code":"vital-signs"}]}],
         "code":{"coding":[{"system":"http://loinc.org","code":"8867-4","display":"Heart rate"}],"text":"心率"},"subject":{"reference":"Patient/001"},
         "effectiveDateTime":measured.isoformat(),"valueQuantity":{"value":heart_rate,"unit":"beats/minute","system":"http://unitsofmeasure.org","code":"/min"},
         **({"device":{"reference":"Device/ppg001"}} if "heartRate" in device_fields else {"method":{"text":"使用者手動輸入"}}),
         "note":[{"text":("PPG 載具讀取之切診輔助量化資料，不等同完整中醫脈診。" if "heartRate" in device_fields else "使用者手動輸入之切診輔助資料；該欄位未由載具提供。") }]},
        {"resourceType":"Observation","id":"spo2-001","status":"final","category":[{"coding":[{"system":"http://terminology.hl7.org/CodeSystem/observation-category","code":"vital-signs"}]}],
         "code":{"coding":[{"system":"http://loinc.org","code":"59408-5","display":"Oxygen saturation by pulse oximetry"}],"text":"血氧飽和度"},"subject":{"reference":"Patient/001"},
         "effectiveDateTime":measured.isoformat(),"valueQuantity":{"value":spo2,"unit":"%","system":"http://unitsofmeasure.org","code":"%"},
         **({"device":{"reference":"Device/ppg001"}} if "spo2" in device_fields else {"method":{"text":"使用者手動輸入"}})},
        {"resourceType":"Observation","id":"hrv-rmssd-001","status":"final","code":{"text":"HRV RMSSD"},"subject":{"reference":"Patient/001"},
         "effectiveDateTime":measured.isoformat(),"valueQuantity":{"value":hrv,"unit":"ms","system":"http://unitsofmeasure.org","code":"ms"},
         **({"device":{"reference":"Device/ppg001"}} if "hrv" in device_fields else {"method":{"text":"使用者手動輸入"}})},
        {"resourceType":"Observation","id":"tcm-constitution-scores-001","status":"final","code":{"text":"中醫九大體質問卷分數"},"subject":{"reference":"Patient/001"},
         "effectiveDateTime":measured.isoformat(),"component":score_components,
         "interpretation":[{"text":f"最高分：{label}"}],"note":[{"text":"分數僅由九大體質問卷計算，PPG 不參與體質加權。"}]},
        {"resourceType":"ClinicalImpression","id":"tcm-impression-001","status":"completed","subject":{"reference":"Patient/001"},"date":issued.isoformat(),
         "assessor":{"reference":"Practitioner/practitioner-001"},"description":"中醫體質初步健康評估",
         "summary":f"問卷最高分體質：{label}。{advice} 本結果僅供健康紀錄與教學展示，不可取代專業醫療診斷。",
         "finding":[{"itemCodeableConcept":{"text":label},"basis":f"QuestionnaireResponse/tcm-response-001；九大體質分數 {scores}"}]},
        {"resourceType":"Schedule","id":"schedule-001","active":True,"actor":[{"reference":"Practitioner/practitioner-001"}],"planningHorizon":{"start":now.isoformat(),"end":(now+timedelta(days=30)).isoformat()}},
        {"resourceType":"Slot","id":"slot-001","schedule":{"reference":"Schedule/schedule-001"},"status":"free","start":(now+timedelta(days=1)).isoformat(),"end":(now+timedelta(days=1,minutes=30)).isoformat()},
    ]
    return resources


def generate_samples() -> list[dict[str,Any]]:
    # 固定示範身分，確保登入帳號、FHIR Patient 與醫護端顯示名稱永遠一致。
    data={"family":"王","given":"小明","gender":"male","birthDate":"2000-01-01","heartRate":72,"spo2":98,"hrv":42}
    for q in questions: data[f"q{q['id']}"]=3
    return generate_samples_from_input(data)


def replace_local_demo(samples: list[dict[str,Any]]) -> None:
    # 保留其他病患資料，只 upsert 固定 demo IDs，避免多病患系統被示範資料整批清空。
    from app import save_resource, validate_resource
    for item in samples: save_resource(item["resourceType"], validate_resource(item["resourceType"], item))

def seed_demo_if_empty() -> bool:
    from app import search_local
    if search_local("Patient"):
        return False
    replace_local_demo(generate_samples())
    return True

if __name__ == "__main__":
    from app import init_db
    init_db()
    created=seed_demo_if_empty()
    print("Demo data ready." if created else "Existing patient data found; demo seed skipped.")

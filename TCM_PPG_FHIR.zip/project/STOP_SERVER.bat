@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

if not exist ".server.pid" (
  echo No background server PID file was found.
  echo If the site still responds, it may have been started with START_DEBUG.bat.
  pause
  exit /b 0
)

set /p SERVER_PID=<.server.pid
if not defined SERVER_PID (
  del /q ".server.pid" >nul 2>nul
  echo Invalid PID file removed.
  pause
  exit /b 0
)

tasklist /FI "PID eq %SERVER_PID%" 2>nul | find "%SERVER_PID%" >nul
if errorlevel 1 (
  echo Server process PID %SERVER_PID% is not running.
  del /q ".server.pid" >nul 2>nul
  pause
  exit /b 0
)

echo Stopping website server ^(PID %SERVER_PID%^)...
taskkill /PID %SERVER_PID% /T /F >nul 2>nul
if errorlevel 1 (
  echo Failed to stop the server.
  pause
  exit /b 1
)

del /q ".server.pid" >nul 2>nul
echo Website server stopped.
timeout /t 1 /nobreak >nul
exit /b 0

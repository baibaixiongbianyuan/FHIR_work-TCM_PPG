from __future__ import annotations
import copy, os, uuid, re
from datetime import datetime, timezone
from typing import Any
import requests

DEFAULT_HAPI_BASE_URL="https://hapi.fhir.org/baseR4"
FHIR_HEADERS={"Accept":"application/fhir+json","Content-Type":"application/fhir+json"}
class HapiFhirError(RuntimeError): pass

def get_base_url(): return os.getenv("HAPI_FHIR_BASE_URL",DEFAULT_HAPI_BASE_URL).rstrip("/")
def _request(method,url,**kwargs):
    try:
        r=requests.request(method,url,headers=FHIR_HEADERS,timeout=int(os.getenv("HAPI_TIMEOUT_SECONDS","30")),**kwargs)
    except requests.RequestException as exc:
        raise HapiFhirError(f"無法連線 HAPI FHIR Server：{exc}") from exc
    if not r.ok:
        detail=""
        try:
            body=r.json()
            if isinstance(body,dict) and body.get("resourceType")=="OperationOutcome":
                issues=body.get("issue") or []
                msgs=[]
                for issue in issues:
                    if isinstance(issue,dict):
                        msg=issue.get("diagnostics") or ((issue.get("details") or {}).get("text"))
                        if msg: msgs.append(str(msg))
                detail="；".join(msgs)
        except Exception:
            pass
        if not detail:
            detail=(r.text or "").strip()[:800]
        raise HapiFhirError(f"HAPI 回傳 HTTP {r.status_code}：{detail}")
    return r
def server_metadata(): return _request("GET",f"{get_base_url()}/metadata").json()
def create_resource(resource):
    rt=resource.get("resourceType")
    if not rt: raise ValueError("缺少 resourceType")
    payload=copy.deepcopy(resource); payload.pop("id",None)
    return _request("POST",f"{get_base_url()}/{rt}",json=payload).json()

def update_resource(resource_type, resource_id, resource):
    payload=copy.deepcopy(resource)
    payload["resourceType"]=resource_type
    payload["id"]=resource_id
    return _request("PUT",f"{get_base_url()}/{resource_type}/{resource_id}",json=payload).json()

def read_resource(rt,rid): return _request("GET",f"{get_base_url()}/{rt}/{rid}").json()
def search_resources(rt,**params): return _request("GET",f"{get_base_url()}/{rt}",params=params).json()

def _first_bundle_resource(bundle):
    if not isinstance(bundle,dict): return None
    for entry in bundle.get("entry") or []:
        r=entry.get("resource") if isinstance(entry,dict) else None
        if isinstance(r,dict) and r.get("id"): return r
    return None

def _duplicate_remote_ref(exc):
    # Public HAPI can return: "Can not create resource duplicating existing resource: Practitioner/123"
    m=re.search(r"duplicating existing resource:\s*([A-Za-z]+)/([A-Za-z0-9.\-]+)",str(exc),re.I)
    return (m.group(1),m.group(2)) if m else (None,None)

def upload_ppg_demo(resources):
    """Upload local FHIR resources with reusable master-resource semantics.

    Master resources are upserted/reused instead of blindly POSTed every run.
    Event/record resources remain POST-only so each assessment can preserve history.
    """
    run_id=uuid.uuid4().hex
    run_time=datetime.now(timezone.utc).isoformat()
    master_types={"Organization","Patient","Practitioner","Questionnaire","Device","Schedule","Slot"}
    by_type={}
    for src in resources:
        r=copy.deepcopy(src)
        rt=r["resourceType"]
        by_type.setdefault(rt,[]).append(r)

    created=[]; updated=[]; reused=[]; read_back=[]; id_map={}

    def rewrite_ref(ref): return id_map.get(ref,ref)

    def rewrite_resource(r):
        """Rewrite every local FHIR reference to its HAPI-side reference.

        References can occur deeply nested (for example Observation.device,
        Appointment.participant.actor, Person.link.target, DiagnosticReport.result).
        A recursive pass is safer than maintaining a partial field allow-list.
        """
        r=copy.deepcopy(r)

        def walk(obj):
            if isinstance(obj,dict):
                for key,value in list(obj.items()):
                    if key=="reference" and isinstance(value,str):
                        obj[key]=rewrite_ref(value)
                    elif key=="questionnaire" and isinstance(value,str):
                        # QuestionnaireResponse.questionnaire is a canonical/reference-like string.
                        obj[key]=rewrite_ref(value)
                    else:
                        walk(value)
            elif isinstance(obj,list):
                for item in obj:
                    walk(item)

        walk(r)
        return r

    def local_identifier(rt, local_id):
        return {"system":f"https://example.org/fhir-local-id/{rt}","value":str(local_id)}

    def add_stable_identifier(r):
        r=copy.deepcopy(r)
        rt=r.get("resourceType"); local_id=r.get("id")
        if rt not in master_types or not local_id:
            return r, None
        ident=local_identifier(rt,local_id)
        identifiers=list(r.get("identifier") or [])
        if not any(isinstance(x,dict) and x.get("system")==ident["system"] and str(x.get("value"))==ident["value"] for x in identifiers):
            identifiers.append(ident)
        r["identifier"]=identifiers
        return r, ident

    def find_existing(rt, ident):
        if not ident: return None
        try:
            bundle=search_resources(rt,identifier=f'{ident["system"]}|{ident["value"]}')
            return _first_bundle_resource(bundle)
        except HapiFhirError:
            return None

    def upsert_or_create(r):
        local=f"{r['resourceType']}/{r.get('id','')}"
        rr=rewrite_resource(r)
        rt=rr["resourceType"]

        if rt in master_types:
            rr, ident=add_stable_identifier(rr)
            existing=find_existing(rt,ident)
            if existing and existing.get("id"):
                remote_id=existing["id"]
                out=update_resource(rt,remote_id,rr)
                id_map[local]=f"{rt}/{remote_id}"
                updated.append(out)
                return out

            try:
                out=create_resource(rr)
                if out.get("id"):
                    id_map[local]=f"{rt}/{out['id']}"
                created.append(out)
                return out
            except HapiFhirError as exc:
                dup_rt,dup_id=_duplicate_remote_ref(exc)
                if dup_rt==rt and dup_id:
                    # First run after upgrading may encounter an older remote resource that had no stable identifier.
                    # Update that existing resource once, adding the stable identifier for future searches.
                    out=update_resource(rt,dup_id,rr)
                    id_map[local]=f"{rt}/{dup_id}"
                    updated.append(out)
                    return out
                raise

        # Event/history resources intentionally create a new server record each upload.
        out=create_resource(rr)
        if out.get("id"):
            id_map[local]=f"{rt}/{out['id']}"
        created.append(out)
        return out

    order=["Organization","Patient","Person","Practitioner","Questionnaire","Device","Encounter","QuestionnaireResponse","Observation","ClinicalImpression","DiagnosticReport","Schedule","Slot","Appointment"]
    processed=[]
    for rt in order:
        for r in by_type.get(rt,[]): processed.append(upsert_or_create(r))
    for rt,items in by_type.items():
        if rt not in order:
            for r in items: processed.append(upsert_or_create(r))

    # Read back both newly-created and updated/reused master resources.
    seen=set()
    for local,remote in id_map.items():
        if remote in seen or "/" not in remote: continue
        seen.add(remote)
        rt,rid=remote.split("/",1)
        read_back.append(read_resource(rt,rid))
    # Event resources without a local id-map entry are still read back from their POST response ids.
    for r in created:
        ref=f"{r.get('resourceType')}/{r.get('id')}"
        if r.get('id') and ref not in seen:
            seen.add(ref); read_back.append(read_resource(r["resourceType"],r["id"]))

    return {
        "server":get_base_url(),
        "createdCount":len(created),
        "updatedCount":len(updated),
        "reusedCount":len(reused),
        "processedCount":len(processed),
        "idMap":id_map,
        "created":created,
        "updated":updated,
        "readBack":read_back,
        "run":run_time,
        "masterStrategy":"upsert-or-reuse",
        "historyStrategy":"create-new"
    }


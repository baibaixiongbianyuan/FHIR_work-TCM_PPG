questions = [

    # Constitution category
    {
    "id":1,
    "type":"pinghe",
    "question":"我平常精力充沛。"
    },

    {
    "id":2,
    "type":"pinghe",
    "question":"我每天的睡眠品質通常良好。"
    },

    {
    "id":3,
    "type":"pinghe",
    "question":"我很少生病或感冒。"
    },

    {
    "id":4,
    "type":"pinghe",
    "question":"我運動後恢復得很快。"
    },

    {
    "id":5,
    "type":"pinghe",
    "question":"我的情緒通常很穩定。"
    },


    # Constitution category
    {
    "id":6,
    "type":"qixu",
    "question":"我經常感到疲倦。"
    },

    {
    "id":7,
    "type":"qixu",
    "question":"稍微活動就容易喘。"
    },

    {
    "id":8,
    "type":"qixu",
    "question":"我的聲音常感到無力。"
    },

    {
    "id":9,
    "type":"qixu",
    "question":"我很容易感冒。"
    },

    {
    "id":10,
    "type":"qixu",
    "question":"我很容易出汗。"
    },


    # Constitution category
    {
    "id":11,
    "type":"yangxu",
    "question":"我很怕冷。"
    },

    {
    "id":12,
    "type":"yangxu",
    "question":"我的手腳經常冰冷。"
    },

    {
    "id":13,
    "type":"yangxu",
    "question":"我比較喜歡喝熱飲。"
    },

    {
    "id":14,
    "type":"yangxu",
    "question":"冬天時我比別人更怕冷。"
    },

    {
    "id":15,
    "type":"yangxu",
    "question":"吹冷氣常讓我感到不舒服。"
    },


    # Constitution category
    {
    "id":16,
    "type":"yinxu",
    "question":"我經常口乾或喉嚨乾。"
    },

    {
    "id":17,
    "type":"yinxu",
    "question":"我經常盜汗。"
    },

    {
    "id":18,
    "type":"yinxu",
    "question":"我有入睡或睡眠困難。"
    },

    {
    "id":19,
    "type":"yinxu",
    "question":"我常覺得身體內部燥熱。"
    },

    {
    "id":20,
    "type":"yinxu",
    "question":"我比較喜歡喝冷水。"
    },

    # Constitution category
    {
    "id":21,
    "type":"tanshi",
    "question":"我的身體常感到沉重。"
    },

    {
    "id":22,
    "type":"tanshi",
    "question":"我很容易疲累。"
    },

    {
    "id":23,
    "type":"tanshi",
    "question":"我很容易增加體重。"
    },

    {
    "id":24,
    "type":"tanshi",
    "question":"我的身體容易水腫。"
    },

    {
    "id":25,
    "type":"tanshi",
    "question":"我經常有較多痰。"
    },

    # Constitution category
    {
    "id":26,
    "type":"shire",
    "question":"我很容易長痘痘。"
    },

    {
    "id":27,
    "type":"shire",
    "question":"我經常覺得嘴巴苦。"
    },

    {
    "id":28,
    "type":"shire",
    "question":"我經常有口氣問題。"
    },

    {
    "id":29,
    "type":"shire",
    "question":"我容易便祕。"
    },

    {
    "id":30,
    "type":"shire",
    "question":"我常覺得身體燥熱。"
    },

    # Constitution category
    {
    "id":31,
    "type":"xueyu",
    "question":"我很容易出現瘀青。"
    },

    {
    "id":32,
    "type":"xueyu",
    "question":"我的疼痛常固定在同一位置。"
    },

    {
    "id":33,
    "type":"xueyu",
    "question":"我的手腳容易麻木。"
    },

    {
    "id":34,
    "type":"xueyu",
    "question":"我的臉色常顯得暗沉。"
    },

    {
    "id":35,
    "type":"xueyu",
    "question":"我的嘴唇顏色常偏暗。"
    },

    # Constitution category
    {
    "id":36,
    "type":"qiyu",
    "question":"我最近感到很大的壓力。"
    },

    {
    "id":37,
    "type":"qiyu",
    "question":"我的情緒很容易低落。"
    },

    {
    "id":38,
    "type":"qiyu",
    "question":"我經常感到焦慮。"
    },

    {
    "id":39,
    "type":"qiyu",
    "question":"我經常感到胸悶。"
    },

    {
    "id":40,
    "type":"qiyu",
    "question":"我常在不自覺中嘆氣。"
    },

    # Constitution category
    {
    "id":41,
    "type":"tebing",
    "question":"我有鼻子過敏。"
    },

    {
    "id":42,
    "type":"tebing",
    "question":"我有食物過敏。"
    },

    {
    "id":43,
    "type":"tebing",
    "question":"我有藥物過敏。"
    },

    {
    "id":44,
    "type":"tebing",
    "question":"我的皮膚容易過敏或發癢。"
    },

    {
    "id":45,
    "type":"tebing",
    "question":"我有氣喘或呼吸道過敏。"
    },

    ]


if __name__ == "__main__":
    print(questions)
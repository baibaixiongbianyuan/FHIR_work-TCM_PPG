# 病人註冊與多病患管理

## 1. 病人自助註冊
登入頁選擇「病人註冊」，填寫帳號、密碼、姓名、性別、生日。系統建立：
- users 本機登入帳號（role=patient）
- FHIR Person
- FHIR Patient
- Person.link → Patient

公開註冊不允許建立 clinician/admin。

## 2. 醫護新增病患
醫護端可建立 Patient 基本資料。Patient ID 可留空讓系統自動產生。
若病人需要登入，可同時填寫入口帳號與密碼；若不需要，可只建立 FHIR Patient。

## 3. 從 HAPI 匯入病患
醫護端輸入 HAPI Patient ID，後端對目前設定的 HAPI FHIR Server 執行：
GET /Patient/{id}

成功後將 Patient 存入本機 FHIR resource store。
為避免權限問題，匯入外部 Patient 時不會自動建立登入帳號。

## 4. 多病患資料隔離
病人送出評估時，以 session 中綁定的 patient_id 為主，不再固定 Patient/001。
所有病人專屬的 Device、Encounter、QuestionnaireResponse、Observation、ClinicalImpression、DiagnosticReport 會產生病人專屬 ID，避免不同病人互相覆蓋。

## 5. 醫護工作流程
病人自己註冊 → 自動出現在醫護病人清單
或
醫護新增 Patient → 病人可選擇是否取得登入帳號
或
HAPI 已有 Patient → 醫護從 HAPI 匯入 → 出現在本機病人清單

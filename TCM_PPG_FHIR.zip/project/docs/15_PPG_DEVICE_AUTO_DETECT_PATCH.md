# PPG 載具自動偵測＋手動回退補丁

## 目的
病人端不再固定要求手動填寫心率、SpO₂、HRV。系統會先掃描本機序列埠，優先尋找 Arduino / Nano / SparkFun / USB Serial 類裝置；若找到，可由使用者按「從載具讀取」取得資料。沒有裝置、連線失敗或裝置未提供某項數值時，對應欄位自動保留為手動輸入。

## 資料來源邏輯
1. `GET /device/ppg/detect`：只掃描序列埠，不主動占用裝置。
2. `POST /device/ppg/read`：實際開啟選定序列埠，預設 115200 baud，收集最多 3 筆有效資料。
3. 支援三種 Serial 輸出：
   - JSON：`{"heartRate":72,"oxygen":98,"confidence":95}`
   - key=value：`heartRate=72 oxygen=98 hrv=42`
   - CSV：`72,98,42`（第三欄 HRV 可省略）
4. 若只讀到 HR/SpO₂ 而沒有 HRV，HR/SpO₂ 標記為「載具」，HRV 仍可手動輸入。
5. 若完全讀取失敗，三個欄位全部恢復手動輸入。

## FHIR 表達
- 真正由 PPG 載具提供的 Observation：使用 `Observation.device -> Device/ppg001`。
- 手動輸入的 Observation：不建立假的 Device reference，改用 `Observation.method.text = 使用者手動輸入`。
- 混合來源時，每個 Observation 分別記錄自己的來源。例如 HR、SpO₂ 來自 Device，但 HRV 可是手動輸入。
- 只有實際有載具資料時才建立 `Device/ppg001`；純手動輸入不建立假的 PPG Device。

## MAX30101 + MAX32664 注意事項
目前 SparkFun Bio Sensor Hub 常用 `readBpm()` 可直接取得 heartRate、oxygen、confidence 等欄位，但不應把 confidence 當成 HRV。若韌體沒有輸出 RR interval / IBI 或已計算的 RMSSD，本系統會保留 HRV 為手動輸入，不自行捏造數值。

## Windows 使用方式
1. 接上 Arduino Nano 33 IoT 與 PPG 模組。
2. 將 `arduino/PPG_FHIR_SERIAL_BRIDGE.ino` 上傳到 Nano 33 IoT。
3. 關閉 Arduino Serial Monitor，避免 COM Port 被占用。
4. 執行 `START.bat`；requirements 會安裝 `pyserial`。
5. 病人登入後系統自動掃描載具。
6. 按「從載具讀取」；若成功，資料自動填入。
7. 未取得的欄位自行輸入，再儲存完整評估。

## 安全與資料品質
這個功能是設備資料擷取與 FHIR 展示，不代表醫療器材校正或臨床驗證。若 confidence 太低，可在未來版本加入門檻判斷；目前 API 會一併回傳 confidence 供後續擴充。

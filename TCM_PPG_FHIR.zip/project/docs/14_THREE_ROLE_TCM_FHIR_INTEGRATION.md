# 三角色中醫數位四診輔助 × FHIR 整合說明

## 系統角色
### 病人 Patient Portal
- 登入後只讀寫自己的病人資料。
- 完成九大體質 45 題、PPG、聞診聲音與氣味自述。
- 可查看自己的 FHIR 紀錄與建立 Appointment。

### 醫護 Clinician Portal
- 使用 Practitioner 身分。
- 查詢病人 EMR 集合。
- 檢視 QuestionnaireResponse、PPG/聲音 Observation、體質 Observation 與 ClinicalImpression。
- 可加入專業 ClinicalImpression 註記。
- 可執行 HAPI FHIR POST + GET read-back。

### 管理員 Admin Portal
- 管理本機使用者與角色。
- 查看 audit log。
- 維護與測試 HAPI 連線。

## 四診資料定位
| 四診 | 本系統實作 | FHIR |
|---|---|---|
| 望 | 本版未宣稱已完成影像診斷 | 後續可視需求加入 Media/DocumentReference/Observation |
| 聞 | 麥克風聲音特徵＋氣味自述 | Device、Observation、QuestionnaireResponse |
| 問 | 九大體質 45 題教學版 | Questionnaire、QuestionnaireResponse、Observation |
| 切 | PPG HR / SpO₂ / HRV 輔助量化 | Device、Observation |

## 資料語意修正
- 體質傾向不是疾病診斷，因此不再用 Condition。
- 九大體質分數使用 Observation.component。
- 體質初步摘要與醫護註記使用 ClinicalImpression。
- PPG 不參與問卷體質分數加權。
- 氣味資料是主觀回答，不是假裝成感測器 Observation。
- 聲音特徵為瀏覽器簡易估測，僅做數位聞診展示。

## 歷史資料
每次新評估會以時間戳建立新的 Encounter、QuestionnaireResponse、Observation、ClinicalImpression、DiagnosticReport，不刪除前一次紀錄；Patient、Questionnaire、Device 等主檔則更新/沿用。

## FHIR 身分與帳號
FHIR Person/Patient/Practitioner 用於醫療交換語意；密碼與角色存在本機 users table，不把密碼寫入 FHIR。

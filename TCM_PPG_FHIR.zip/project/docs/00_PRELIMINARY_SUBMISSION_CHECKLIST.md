# 00 PRELIMINARY SUBMISSION CHECKLIST

This file is part of the English-only competition package. Review and customize the content before submission. Do not include real patient identifiers.

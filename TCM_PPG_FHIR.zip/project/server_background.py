from __future__ import annotations

import os
import runpy
import sys
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
LOG_PATH = BASE_DIR / "server.log"

# The launcher opens the browser only after the health check succeeds.
os.environ["AUTO_OPEN_BROWSER"] = "0"

# Keep background startup errors visible even though there is no console window.
log = LOG_PATH.open("a", encoding="utf-8", buffering=1)
sys.stdout = log
sys.stderr = log

print("\n" + "=" * 72)
print(f"Background server start: {datetime.now().isoformat(timespec='seconds')}")
print(f"Python: {sys.executable}")
print(f"Working directory: {BASE_DIR}")
print("=" * 72)

os.chdir(BASE_DIR)
try:
    runpy.run_path(str(BASE_DIR / "app.py"), run_name="__main__")
except BaseException:
    import traceback
    traceback.print_exc()
    raise

from __future__ import annotations

import json, os, re, sqlite3, threading, webbrowser, uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Iterable

from flask import Flask, jsonify, make_response, render_template, request, session, redirect, send_file
from werkzeug.security import check_password_hash, generate_password_hash

from hapi_client import HapiFhirError, get_base_url, server_metadata, upload_ppg_demo

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=Path(os.getenv("FHIR_DB_PATH",BASE_DIR/"database.db"))
VOICE_DIR=BASE_DIR/"voice_recordings"
VOICE_DIR.mkdir(exist_ok=True)
app=Flask(__name__)
app.secret_key=os.getenv("SECRET_KEY","tcm-fhir-demo-change-me")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

RESOURCE_TYPES={"Organization","Person","Patient","Practitioner","Device","Encounter","Observation","ClinicalImpression","DiagnosticReport","Questionnaire","QuestionnaireResponse","Schedule","Slot","Appointment"}
PATIENT_SCOPED={"Device","Encounter","Observation","ClinicalImpression","DiagnosticReport","QuestionnaireResponse","Appointment"}
ID_RE=re.compile(r"^[A-Za-z0-9\-.]{1,64}$")
TZ_TAIPEI=timezone(timedelta(hours=8))


def now_iso(): return datetime.now(TZ_TAIPEI).replace(microsecond=0).isoformat()

def roc_birthday_password(birth_date: str) -> str:
    """將 YYYY-MM-DD 轉成民國生日密碼：民國年(不補零)+MMDD，例如 2006-12-30 -> 951230。"""
    try:
        dt=datetime.strptime(str(birth_date).strip(), "%Y-%m-%d")
    except (TypeError, ValueError):
        raise ValueError("建立登入帳號時必須填寫有效生日，初始密碼會使用民國生日")
    roc_year=dt.year-1911
    if roc_year <= 0:
        raise ValueError("生日必須為民國元年（1912）之後")
    return f"{roc_year}{dt.month:02d}{dt.day:02d}"

@contextmanager
def get_db():
    conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row; conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn; conn.commit()
    except Exception:
        conn.rollback(); raise
    finally: conn.close()


def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS resources(
          resource_type TEXT NOT NULL,id TEXT NOT NULL,patient_id TEXT,code TEXT,status TEXT,effective_date TEXT,
          resource_json TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(resource_type,id));
        CREATE INDEX IF NOT EXISTS idx_resources_patient ON resources(patient_id);
        CREATE INDEX IF NOT EXISTS idx_resources_type_patient ON resources(resource_type,patient_id);
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,
          display_name TEXT NOT NULL,person_id TEXT,patient_id TEXT,practitioner_id TEXT,active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS audit_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,username TEXT,role TEXT,action TEXT NOT NULL,target TEXT,detail TEXT);
        CREATE TABLE IF NOT EXISTS app_settings(
          key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS fhir_identity_map(
          patient_id TEXT PRIMARY KEY,
          pseudonym TEXT UNIQUE NOT NULL,
          last_remote_patient_id TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_fhir_identity_pseudonym ON fhir_identity_map(pseudonym);
        CREATE INDEX IF NOT EXISTS idx_fhir_identity_remote ON fhir_identity_map(last_remote_patient_id);
        CREATE TABLE IF NOT EXISTS voice_recordings(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          patient_id TEXT NOT NULL,
          assessment_suffix TEXT,
          filename TEXT NOT NULL UNIQUE,
          original_mime TEXT,
          duration REAL,
          created_at TEXT NOT NULL,
          updated_at TEXT);
        CREATE INDEX IF NOT EXISTS idx_voice_recordings_patient ON voice_recordings(patient_id,created_at);
        CREATE TABLE IF NOT EXISTS assessment_sessions(
          patient_id TEXT PRIMARY KEY,
          assessment_suffix TEXT NOT NULL,
          started_at TEXT NOT NULL,
          last_saved_at TEXT NOT NULL);

        """)
        # Schema migration for password reset / first-login password change.
        cols={r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
        if "must_change_password" not in cols:
            conn.execute("ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0")
        voice_cols={r[1] for r in conn.execute("PRAGMA table_info(voice_recordings)").fetchall()}
        if "assessment_suffix" not in voice_cols:
            conn.execute("ALTER TABLE voice_recordings ADD COLUMN assessment_suffix TEXT")
        if "updated_at" not in voice_cols:
            conn.execute("ALTER TABLE voice_recordings ADD COLUMN updated_at TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_voice_recordings_assessment ON voice_recordings(patient_id,assessment_suffix)")
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("national_id_validation_mode","demo",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("assessment_refresh_window_minutes","5",now_iso()))
        existing=conn.execute("SELECT COUNT(*) c FROM users").fetchone()[0]
        if not existing:
            # 競賽展示首次啟動：預設建立三種角色的測試帳號。
            # 所有帳號皆為虛構測試號，不代表真實身分證字號。
            demo_password=generate_password_hash("Test1234!")
            conn.executemany(
                "INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,practitioner_id,must_change_password) VALUES(?,?,?,?,?,?,?,0)",
                [
                    ("A000000001", demo_password, "admin", "測試系統管理員", None, None, None),
                    ("B000000002", demo_password, "clinician", "測試醫護人員", "person-clinician-demo", None, "practitioner-001"),
                    ("C000000003", demo_password, "patient", "測試病人", "person-patient-demo", "demo-patient-001", None),
                ]
            )
            demo_resources=[
                {"resourceType":"Person","id":"person-clinician-demo","active":True,"name":[{"text":"測試醫護人員"}]},
                {"resourceType":"Practitioner","id":"practitioner-001","active":True,"name":[{"text":"測試醫護人員"}]},
                {"resourceType":"Person","id":"person-patient-demo","active":True,"name":[{"text":"測試病人"}]},
                {"resourceType":"Patient","id":"demo-patient-001","active":True,"name":[{"family":"測試","given":["病人"],"text":"測試病人"}],"gender":"unknown","birthDate":"2000-01-01"},
            ]
            for resource in demo_resources:
                rt=resource["resourceType"]
                pid=resource["id"] if rt=="Patient" else None
                conn.execute(
                    "INSERT OR REPLACE INTO resources(resource_type,id,patient_id,code,status,effective_date,resource_json,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                    (rt,resource["id"],pid,None,None,None,json.dumps(resource,ensure_ascii=False),now_iso())
                )


def audit(action,target="",detail=""):
    try:
        with get_db() as conn:
            conn.execute("INSERT INTO audit_log(at,username,role,action,target,detail) VALUES(?,?,?,?,?,?)",
                         (now_iso(),session.get("username"),session.get("role"),action,target,detail))
    except Exception: pass


def outcome(diagnostics,status=400,code="invalid",severity="error"):
    return jsonify({"resourceType":"OperationOutcome","issue":[{"severity":severity,"code":code,"diagnostics":diagnostics}]}),status


def normalize_reference(value:Any,expected_type="Patient"):
    if isinstance(value,dict): value=value.get("reference")
    if not isinstance(value,str) or not value.strip(): raise ValueError(f"缺少 {expected_type} reference")
    value=value.strip().rstrip("/"); prefix,rid=(value.rsplit("/",1) if "/" in value else (expected_type,value))
    if prefix!=expected_type or not ID_RE.fullmatch(rid): raise ValueError(f"reference 必須為 {expected_type}/<id>")
    return rid


def validate_id(data):
    rid=data.get("id")
    if not isinstance(rid,str) or not ID_RE.fullmatch(rid): raise ValueError("FHIR id 僅可含英數、-、.，長度 1–64")
    return rid


def require(data,*fields):
    missing=[f for f in fields if data.get(f) in (None,"",[],{})]
    if missing: raise ValueError("缺少必要欄位："+", ".join(missing))


def coding_code(codeable):
    if not isinstance(codeable,dict): return None
    coding=codeable.get("coding") or []
    if coding and isinstance(coding[0],dict) and coding[0].get("code"): return str(coding[0]["code"])
    return str(codeable.get("text")) if codeable.get("text") else None


def extract_patient_id(rt,data):
    if rt=="Patient": return data.get("id")
    if rt=="Device": ref=data.get("patient")
    elif rt in {"Questionnaire","Organization","Person","Practitioner","Schedule","Slot"}: return None
    elif rt=="Appointment":
        for p in data.get("participant",[]):
            ref=((p or {}).get("actor") or {}).get("reference","")
            if ref.startswith("Patient/"): return ref.split("/",1)[1]
        return None
    else: ref=data.get("subject")
    try: return normalize_reference(ref) if ref else None
    except ValueError: return None


def validate_resource(rt,data):
    if not isinstance(data,dict): raise ValueError("Request body 必須是 JSON object")
    if data.get("resourceType") not in (None,rt): raise ValueError(f"resourceType 必須為 {rt}")
    data=json.loads(json.dumps(data,ensure_ascii=False)); data["resourceType"]=rt; validate_id(data)
    if rt=="Patient": require(data,"name")
    elif rt=="Organization": require(data,"name")
    elif rt=="Person": require(data,"name")
    elif rt=="Practitioner": require(data,"name")
    elif rt=="Device": require(data,"status","deviceName")
    elif rt=="Encounter": require(data,"status","class","subject","period")
    elif rt=="Observation":
        require(data,"status","code","subject","effectiveDateTime")
        if not any(k in data for k in ("valueQuantity","valueCodeableConcept","valueString","valueInteger","component")): raise ValueError("Observation 必須包含 value[x] 或 component")
    elif rt=="Questionnaire": require(data,"status","title","item")
    elif rt=="QuestionnaireResponse": require(data,"status","questionnaire","subject","authored","item")
    elif rt=="ClinicalImpression": require(data,"status","subject","date","summary")
    elif rt=="DiagnosticReport": require(data,"status","code","subject","issued")
    elif rt=="Schedule": require(data,"actor")
    elif rt=="Slot": require(data,"schedule","status","start","end")
    elif rt=="Appointment": require(data,"status","start","end","participant")
    return data


def save_resource(rt,data):
    patient_id=extract_patient_id(rt,data); code=coding_code(data.get("code")); status=data.get("status")
    effective=data.get("effectiveDateTime") or data.get("issued") or data.get("authored") or data.get("date") or data.get("start")
    with get_db() as conn:
        conn.execute("INSERT OR REPLACE INTO resources(resource_type,id,patient_id,code,status,effective_date,resource_json,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                     (rt,data["id"],patient_id,code,status,effective,json.dumps(data,ensure_ascii=False),now_iso()))


def load_resource(rt,rid):
    with get_db() as conn: row=conn.execute("SELECT resource_json FROM resources WHERE resource_type=? AND id=?",(rt,rid)).fetchone()
    return json.loads(row[0]) if row else None


def search_local(rt,patient_id=None):
    sql="SELECT resource_json FROM resources WHERE resource_type=?"; params=[rt]
    if patient_id is not None: sql+=" AND patient_id=?"; params.append(patient_id)
    sql+=" ORDER BY effective_date DESC,id"
    with get_db() as conn: rows=conn.execute(sql,params).fetchall()
    return [json.loads(r[0]) for r in rows]


def bundle(resources:Iterable[dict],bundle_type="searchset"):
    resources=list(resources); return {"resourceType":"Bundle","type":bundle_type,"total":len(resources),"entry":[{"fullUrl":f"{r['resourceType']}/{r['id']}","resource":r} for r in resources]}


def current_user():
    if not session.get("username"): return None
    return {k:session.get(k) for k in ("username","role","display_name","person_id","patient_id","practitioner_id","must_change_password")}


def login_required(fn):
    @wraps(fn)
    def wrapper(*a,**kw):
        if not session.get("username"): return outcome("請先登入",401,"login")
        return fn(*a,**kw)
    return wrapper


def roles_required(*roles):
    def dec(fn):
        @wraps(fn)
        def wrapper(*a,**kw):
            if not session.get("username"): return outcome("請先登入",401,"login")
            if session.get("role") not in roles: return outcome("權限不足",403,"forbidden")
            return fn(*a,**kw)
        return wrapper
    return dec


def new_fhir_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"[:64]

def clean_username(value: str) -> str:
    value=str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", value):
        raise ValueError("帳號需為 3–40 字元，只能使用英數、_、-、.")
    return value

TAIWAN_ID_MAP={c:10+i for i,c in enumerate("ABCDEFGHJKLMNPQRSTUVXYWZIO")}
def get_setting(key: str, default: str="") -> str:
    with get_db() as conn:
        row=conn.execute("SELECT value FROM app_settings WHERE key=?",(key,)).fetchone()
    return str(row[0]) if row else default

def set_setting(key: str, value: str):
    with get_db() as conn:
        conn.execute("INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                     (key,value,now_iso()))

def strict_taiwan_id_check_enabled() -> bool:
    return get_setting("national_id_validation_mode","demo") == "strict"

def clean_national_id(value: str) -> str:
    value=str(value or "").strip().upper().replace(" ","")
    # 競賽 / Demo 預設只檢查 1 個英文字母 + 9 個數字，方便使用虛構測試帳號。
    if not re.fullmatch(r"[A-Z]\d{9}", value):
        raise ValueError("身分證字號格式需為 1 個英文字母＋9 個數字，例如 R123456789")
    if not strict_taiwan_id_check_enabled():
        return value
    # 正式檢核模式由管理員後台的 app_settings 控制。
    if not re.fullmatch(r"[A-Z][12]\d{8}", value):
        raise ValueError("正式模式下，身分證字號第 2 碼須為 1 或 2")
    n=TAIWAN_ID_MAP.get(value[0])
    if n is None:
        raise ValueError("身分證字號首字母不正確")
    digits=[n//10,n%10]+[int(x) for x in value[1:]]
    weights=[1,9,8,7,6,5,4,3,2,1,1]
    if sum(d*w for d,w in zip(digits,weights))%10!=0:
        raise ValueError("身分證字號檢核碼不正確")
    return value

PSEUDONYM_SYSTEM="https://example.org/fhir-pseudonym"

def fhir_pseudonym_for_patient(patient_id: str) -> str:
    """取得或建立穩定的 FHIR 假名識別碼。此值不包含身分證字號，也不由身分證推導。"""
    patient_id=str(patient_id or "").strip()
    if not patient_id:
        raise ValueError("缺少 patient_id")
    with get_db() as conn:
        row=conn.execute("SELECT pseudonym FROM fhir_identity_map WHERE patient_id=?",(patient_id,)).fetchone()
        if row:
            return str(row[0])
        pseudonym="FHIRP-"+uuid.uuid4().hex.upper()
        conn.execute("INSERT INTO fhir_identity_map(patient_id,pseudonym,created_at,updated_at) VALUES(?,?,?,?)",
                     (patient_id,pseudonym,now_iso(),now_iso()))
        return pseudonym

def local_patient_id_from_pseudonym(pseudonym: str) -> str | None:
    with get_db() as conn:
        row=conn.execute("SELECT patient_id FROM fhir_identity_map WHERE pseudonym=?",(str(pseudonym or "").strip(),)).fetchone()
    return str(row[0]) if row else None

def local_patient_id_from_remote(remote_patient_id: str) -> str | None:
    with get_db() as conn:
        row=conn.execute("SELECT patient_id FROM fhir_identity_map WHERE last_remote_patient_id=?",(str(remote_patient_id or "").strip(),)).fetchone()
    return str(row[0]) if row else None

def remember_remote_patient_id(local_patient_id: str, remote_patient_id: str):
    pseudonym=fhir_pseudonym_for_patient(local_patient_id)
    with get_db() as conn:
        conn.execute("UPDATE fhir_identity_map SET last_remote_patient_id=?,updated_at=? WHERE patient_id=?",
                     (remote_patient_id,now_iso(),local_patient_id))
    return pseudonym

def pseudonym_from_fhir_patient(patient: dict) -> str | None:
    for ident in (patient or {}).get("identifier") or []:
        if isinstance(ident,dict) and ident.get("system")==PSEUDONYM_SYSTEM and ident.get("value"):
            return str(ident.get("value"))
    return None

def pseudonymize_resources_for_hapi(resources: list[dict]) -> tuple[list[dict],dict[str,str]]:
    """只修改準備上傳 HAPI 的複本；本機可視化病人資料保持原樣。"""
    out=json.loads(json.dumps(resources,ensure_ascii=False))
    aliases={}
    patient_ids={r.get("id") for r in out if r.get("resourceType")=="Patient" and r.get("id")}
    for pid in patient_ids:
        aliases[pid]=fhir_pseudonym_for_patient(pid)
    for r in out:
        rt=r.get("resourceType")
        if rt=="Patient" and r.get("id") in aliases:
            pseudo=aliases[r["id"]]
            # 公開/外部 FHIR 不帶登入身分證與真實姓名。保留一個不可逆隨機假名識別碼供本機重新對應。
            r["identifier"]=[{"system":PSEUDONYM_SYSTEM,"value":pseudo}]
            r["name"]=[{"text":f"匿名病人 {pseudo[-8:]}"}]
            # 生日屬可重新識別資訊；競賽 HAPI 上傳預設移除。
            r.pop("birthDate",None)
            r.pop("telecom",None); r.pop("address",None); r.pop("photo",None)
        elif rt=="Person":
            linked_pid=None
            for link in r.get("link") or []:
                ref=((link or {}).get("target") or {}).get("reference","")
                if ref.startswith("Patient/"):
                    linked_pid=ref.split("/",1)[1]; break
            if linked_pid in aliases:
                pseudo=aliases[linked_pid]
                r["name"]=[{"text":f"匿名病人 {pseudo[-8:]}"}]
                r.pop("telecom",None); r.pop("address",None); r.pop("birthDate",None); r.pop("photo",None)
    return out,aliases

def build_patient_identity(data: dict, patient_id: str | None=None, person_id: str | None=None):
    patient_id=patient_id or new_fhir_id("patient")
    person_id=person_id or new_fhir_id("person")
    family=str(data.get("family","")).strip()
    given=str(data.get("given","")).strip()
    if not family or not given:
        raise ValueError("請填寫姓與名")
    gender=str(data.get("gender","unknown"))
    if gender not in {"male","female","other","unknown"}:
        raise ValueError("性別格式不正確")
    birth_date=str(data.get("birthDate","")).strip()
    if birth_date:
        birth_date=birth_date.replace("/","-")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", birth_date):
            raise ValueError("生日格式需為 yyyy/mm/dd")
        try:
            datetime.strptime(birth_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("生日日期不正確")
    patient={"resourceType":"Patient","id":patient_id,
             "identifier":[{"system":"https://example.org/patient-id","value":patient_id}],
             "name":[{"family":family,"given":[given]}],"gender":gender,
             "managingOrganization":{"reference":"Organization/org001"}}
    if birth_date: patient["birthDate"]=birth_date
    person={"resourceType":"Person","id":person_id,
            "name":[{"family":family,"given":[given]}],
            "link":[{"target":{"reference":f"Patient/{patient_id}"},"assurance":"level3"}]}
    return patient,person

def fhir_human_name(resource: dict | None, fallback="") -> str:
    if not isinstance(resource,dict): return fallback
    names=resource.get("name") or []
    if not names or not isinstance(names[0],dict): return fallback
    n=names[0]
    if n.get("text"): return str(n.get("text")).strip() or fallback
    family=str(n.get("family") or "").strip()
    given="".join(str(x) for x in (n.get("given") or [])).strip()
    return (family+given).strip() or fallback

def patient_national_id(patient: dict | None, account: dict | None=None) -> str:
    """取得病人的台灣身分證字號；優先使用登入帳號，其次讀 Patient.identifier。"""
    if account and account.get("username"):
        value=str(account.get("username") or "").strip().upper()
        if re.fullmatch(r"[A-Z][12]\d{8}", value):
            return value
    if isinstance(patient, dict):
        for ident in patient.get("identifier") or []:
            if not isinstance(ident, dict):
                continue
            system=str(ident.get("system") or "")
            value=str(ident.get("value") or "").strip().upper()
            if system in {"https://example.org/tw-national-id","urn:oid:2.16.886.101.20003.20007"} and re.fullmatch(r"[A-Z][12]\d{8}", value):
                return value
    return ""

def set_patient_national_id(patient: dict, national_id: str) -> dict:
    ids=[x for x in (patient.get("identifier") or []) if isinstance(x,dict) and x.get("system")!="https://example.org/tw-national-id"]
    ids.append({"system":"https://example.org/tw-national-id","value":national_id})
    patient["identifier"]=ids
    return patient

def person_id_for_patient(patient_id: str) -> str | None:
    for person in search_local("Person"):
        for link in person.get("link") or []:
            ref=((link or {}).get("target") or {}).get("reference","")
            if ref==f"Patient/{patient_id}": return person.get("id")
    return None

def can_access_patient(patient_id):
    role=session.get("role")
    if role=="patient": return session.get("patient_id")==patient_id
    return role in {"clinician","admin"}

@app.get("/")
def home(): return render_template("index.html")

@app.get("/demo-start")
def demo_start():
    """競賽啟動入口：只在 START.bat 主動開啟時清除舊登入 Session。

    一般重新整理 / 不會登出；只有重新由啟動器開啟 /demo-start 才會回到登入頁。
    """
    session.clear()
    resp=make_response(redirect("/"))
    resp.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"
    return resp

@app.get("/report")
def report(): return render_template("report.html")

@app.post("/auth/login")
def auth_login():
    data=request.get_json(silent=True) or {}; username=str(data.get("username","")).strip(); password=str(data.get("password",""))
    with get_db() as conn: row=conn.execute("SELECT * FROM users WHERE username=? AND active=1",(username,)).fetchone()
    if not row or not check_password_hash(row["password_hash"],password): return outcome("帳號或密碼錯誤",401,"login")
    session.clear()
    for k in ("username","role","display_name","person_id","patient_id","practitioner_id"):
        session[k]=row[k]
    session["must_change_password"]=bool(row["must_change_password"])
    audit("login",username); return jsonify({"ok":True,"user":current_user()})

@app.post("/auth/logout")
def auth_logout():
    audit("logout",session.get("username",'')); session.clear(); return jsonify({"ok":True})
@app.get("/auth/me")
def auth_me(): return jsonify({"user":current_user()})

@app.post("/auth/change-password")
@login_required
def auth_change_password():
    d=request.get_json(silent=True) or {}
    current_password=str(d.get("current_password", ""))
    new_password=str(d.get("new_password", ""))
    confirm_password=str(d.get("confirm_password", ""))
    if len(new_password)<8:
        return outcome("新密碼至少 8 個字元",400,"invalid")
    if new_password!=confirm_password:
        return outcome("兩次輸入的新密碼不一致",400,"invalid")
    if new_password==current_password:
        return outcome("新密碼不可與目前密碼相同",400,"invalid")
    with get_db() as conn:
        row=conn.execute("SELECT * FROM users WHERE username=? AND active=1",(session.get("username"),)).fetchone()
        if not row or not check_password_hash(row["password_hash"],current_password):
            return outcome("目前密碼驗證失敗",403,"forbidden")
        conn.execute("UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?",(generate_password_hash(new_password),row["id"]))
    session["must_change_password"]=False
    audit("change-password",session.get("username",""),"user changed password")
    return jsonify({"ok":True,"message":"密碼已更新"})

@app.get("/auth/national-id-policy")
def national_id_policy():
    mode=get_setting("national_id_validation_mode","demo")
    return jsonify({
        "mode":mode,
        "strict":mode=="strict",
        "label":"正式檢核模式" if mode=="strict" else "Demo／測試模式",
        "message":("目前啟用正式台灣身分證檢核：將檢查格式、第 2 碼與 checksum。"
                   if mode=="strict" else
                   "目前為競賽 Demo／測試模式：只檢查 1 個英文字母＋9 個數字。請使用虛構測試資料，勿輸入真實個資。")
    })

@app.post("/auth/register")
def auth_register():
    """病人自助註冊：建立本機登入帳號，同時建立 FHIR Person + Patient。"""
    d=request.get_json(silent=True) or {}
    try:
        username=clean_national_id(d.get("national_id") or d.get("username"))
        password=str(d.get("password",""))
        if len(password)<6: raise ValueError("密碼至少 6 個字元")
        patient,person=build_patient_identity(d)
        set_patient_national_id(patient, username)
        display_name=str(d.get("display_name") or f"{patient['name'][0]['family']}{patient['name'][0]['given'][0]}").strip()
        with get_db() as conn:
            if conn.execute("SELECT 1 FROM users WHERE username=?",(username,)).fetchone():
                return outcome("此身分證字號已註冊",409,"duplicate")
            conn.execute("INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,active) VALUES(?,?,?,?,?,?,1)",
                         (username,generate_password_hash(password),"patient",display_name,person["id"],patient["id"]))
        # 病人自助註冊的登入帳號已在上方完成驗證與建立。
        # 不再重複使用 username 欄位檢查，避免前端送 national_id 時誤判為缺少帳號。
        # 接著建立對應的本機 FHIR Person / Patient。
        if not load_resource("Organization","org001"):
            save_resource("Organization",{"resourceType":"Organization","id":"org001","active":True,"name":"TCM PPG FHIR Competition Demo Clinic"})
        save_resource("Patient",validate_resource("Patient",patient))
        save_resource("Person",validate_resource("Person",person))
        fhir_pseudonym_for_patient(patient["id"])
        audit("self-register",f"Patient/{patient['id']}",username)
        return jsonify({"ok":True,"message":"註冊成功，請使用新帳號登入","patient_id":patient["id"],"person_id":person["id"]}),201
    except ValueError as exc:
        return outcome(str(exc))
    except sqlite3.IntegrityError:
        return outcome("帳號建立失敗：此身分證字號可能已註冊",409,"duplicate")
    except Exception as exc:
        # API 一律回 JSON OperationOutcome，避免前端收到 Flask HTML 錯誤頁後出現 Unexpected token '<'。
        app.logger.exception("patient self-register failed")
        return outcome(f"註冊失敗：{exc}",500,"exception")

@app.get("/metadata")
def metadata():
    return jsonify({"resourceType":"CapabilityStatement","status":"active","kind":"instance","fhirVersion":"4.0.1","format":["json"],"rest":[{"mode":"server","resource":[{"type":t,"interaction":[{"code":"read"},{"code":"create"},{"code":"search-type"}]} for t in sorted(RESOURCE_TYPES)]}]})

@app.route("/<resource_type>",methods=["GET","POST"])
@login_required
def collection(resource_type):
    if resource_type not in RESOURCE_TYPES: return outcome("不支援的 resourceType",404,"not-found")
    if request.method=="POST":
        if session.get("role")=="patient" and resource_type not in {"QuestionnaireResponse","Observation","Appointment"}: return outcome("病人端不可建立此資源",403,"forbidden")
        try: data=validate_resource(resource_type,request.get_json(silent=True))
        except ValueError as exc: return outcome(str(exc))
        pid=extract_patient_id(resource_type,data)
        if pid and not can_access_patient(pid): return outcome("不可寫入其他病人的資料",403,"forbidden")
        save_resource(resource_type,data); audit("create",f"{resource_type}/{data['id']}")
        resp=make_response(jsonify(data),201); resp.headers["Location"]=f"/{resource_type}/{data['id']}"; return resp
    patient=request.args.get("patient") or request.args.get("subject")
    if session.get("role")=="patient": patient=session.get("patient_id") if resource_type in PATIENT_SCOPED or resource_type=="Patient" else patient
    if patient and not can_access_patient(patient): return outcome("不可查看其他病人的資料",403,"forbidden")
    if resource_type=="Patient" and session.get("role")=="patient":
        p=load_resource("Patient",session.get("patient_id")); return jsonify(bundle([p] if p else []))
    return jsonify(bundle(search_local(resource_type,patient)))

@app.get("/<resource_type>/<rid>")
@login_required
def read_resource(resource_type,rid):
    if resource_type not in RESOURCE_TYPES: return outcome("不支援的 resourceType",404,"not-found")
    r=load_resource(resource_type,rid)
    if not r: return outcome("找不到資源",404,"not-found")
    pid=extract_patient_id(resource_type,r)
    if pid and not can_access_patient(pid): return outcome("不可查看其他病人的資料",403,"forbidden")
    audit("read",f"{resource_type}/{rid}"); return jsonify(r)

@app.get("/patient/profile")
@roles_required("patient")
def patient_profile():
    """回傳目前病人帳號實際綁定的 Patient 主檔，供病人頁初始化基本資料。"""
    patient_id=session.get("patient_id")
    if not patient_id:
        return outcome("此病人帳號尚未綁定 Patient",404,"not-found")
    patient=load_resource("Patient",patient_id)
    if not patient:
        return outcome("找不到此帳號對應的 Patient 主檔",404,"not-found")
    return jsonify({"ok":True,"patient":patient})

@app.get("/EMR/Patient/<patient_id>")
@login_required
def patient_emr(patient_id):
    if not can_access_patient(patient_id): return outcome("不可查看其他病人的資料",403,"forbidden")
    p=load_resource("Patient",patient_id)
    if not p: return outcome("找不到病人",404,"not-found")
    resources=[p]
    for rt in ("Device","Encounter","Observation","QuestionnaireResponse","ClinicalImpression","DiagnosticReport","Appointment"):
        resources.extend(search_local(rt,patient_id))
    for rt in ("Questionnaire",): resources.extend(search_local(rt))
    audit("read-emr",f"Patient/{patient_id}"); return jsonify(bundle(resources,"collection"))



@app.post("/patient/voice-recording")
@roles_required("patient")
def patient_voice_recording_upload():
    patient_id=session.get("patient_id")
    if not patient_id or not load_resource("Patient",patient_id):
        return outcome("找不到目前病人資料",404,"not-found")
    f=request.files.get("audio")
    if not f or not f.filename:
        return outcome("缺少錄音檔",400,"required")
    raw=f.read()
    if not raw:
        return outcome("錄音檔內容為空",400,"invalid")
    if len(raw)>15*1024*1024:
        return outcome("錄音檔超過 15 MB",413,"too-costly")
    mime=(f.mimetype or "audio/webm").lower()
    ext=".webm"
    if "ogg" in mime: ext=".ogg"
    elif "wav" in mime: ext=".wav"
    elif "mp4" in mime or "m4a" in mime: ext=".m4a"
    try: duration=float(request.form.get("duration") or 0)
    except ValueError: duration=0
    assessment_suffix=str(request.form.get("assessment_id") or "").strip()
    created=now_iso()

    # 錄音與完整評估綁定：同一 assessment（預設 5 分鐘刷新視窗內）只保留最新一份錄音。
    # 超過刷新視窗後，/patient/assessment 會建立新的 assessment_id，因此自然形成新的歷史錄音。
    old_filename=None
    with get_db() as conn:
        existing=None
        if assessment_suffix:
            existing=conn.execute(
                "SELECT id,filename,created_at FROM voice_recordings WHERE patient_id=? AND assessment_suffix=? ORDER BY id DESC LIMIT 1",
                (patient_id,assessment_suffix)
            ).fetchone()
        filename=f"voice-{uuid.uuid4().hex}{ext}"
        (VOICE_DIR/filename).write_bytes(raw)
        if existing:
            old_filename=existing["filename"]
            rid=existing["id"]
            conn.execute(
                "UPDATE voice_recordings SET filename=?,original_mime=?,duration=?,updated_at=? WHERE id=?",
                (filename,mime,duration,created,rid)
            )
            action="voice-recording-refresh"
        else:
            cur=conn.execute(
                "INSERT INTO voice_recordings(patient_id,assessment_suffix,filename,original_mime,duration,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                (patient_id,assessment_suffix or None,filename,mime,duration,created,created)
            )
            rid=cur.lastrowid
            action="voice-recording-upload"
    if old_filename and old_filename!=filename:
        try:
            old_path=VOICE_DIR/old_filename
            if old_path.exists(): old_path.unlink()
        except OSError:
            pass
    audit(action,f"Patient/{patient_id}",f"recording_id={rid}; assessment={assessment_suffix or '-'}")
    return jsonify({"ok":True,"id":rid,"created_at":created,"duration":duration,"assessment_id":assessment_suffix or None,"refreshed":bool(old_filename)})

@app.get("/voice-recordings")
@login_required
def voice_recordings_list():
    patient_id=str(request.args.get("patient_id") or session.get("patient_id") or "").strip()
    if not patient_id or not can_access_patient(patient_id):
        return outcome("不可查看此病人的錄音",403,"forbidden")
    with get_db() as conn:
        rows=conn.execute("SELECT id,assessment_suffix,duration,created_at,updated_at,original_mime FROM voice_recordings WHERE patient_id=? ORDER BY COALESCE(updated_at,created_at) DESC,id DESC",(patient_id,)).fetchall()
    return jsonify({"patient_id":patient_id,"recordings":[{"id":r["id"],"assessment_id":r["assessment_suffix"],"duration":r["duration"],"created_at":r["created_at"],"updated_at":r["updated_at"],"mime":r["original_mime"],"url":f"/voice-recordings/{r['id']}/audio"} for r in rows]})

@app.get("/voice-recordings/<int:recording_id>/audio")
@login_required
def voice_recording_audio(recording_id):
    with get_db() as conn:
        row=conn.execute("SELECT * FROM voice_recordings WHERE id=?",(recording_id,)).fetchone()
    if not row: return outcome("找不到錄音檔",404,"not-found")
    if not can_access_patient(row["patient_id"]): return outcome("不可播放此病人的錄音",403,"forbidden")
    path=VOICE_DIR/row["filename"]
    if not path.exists(): return outcome("錄音檔已不存在",404,"not-found")
    audit("voice-recording-play",f"Patient/{row['patient_id']}",f"recording_id={recording_id}")
    return send_file(path,mimetype=row["original_mime"] or "audio/webm",conditional=True)

@app.get("/device/ppg/detect")
@roles_required("patient","clinician","admin")
def device_ppg_detect():
    from ppg_device import detect_ppg_device
    result=detect_ppg_device(); audit("ppg-detect", result.get("selected",{}).get("device","") if result.get("selected") else "", result.get("reason","")); return jsonify(result)

@app.post("/device/ppg/read")
@roles_required("patient","clinician","admin")
def device_ppg_read():
    from ppg_device import read_ppg_sample
    d=request.get_json(silent=True) or {}
    try:
        result=read_ppg_sample(port=(str(d.get("port") or "").strip() or None), baudrate=int(d.get("baudrate",115200)), timeout_seconds=float(d.get("timeout",8)))
    except (RuntimeError,ValueError) as exc:
        audit("ppg-read-failed", str(d.get("port") or "auto"), str(exc)); return outcome(str(exc),422,"processing")
    audit("ppg-read", result.get("port",{}).get("device",""), f"samples={result.get('samplesUsed',0)} missing={result.get('missing',[])}")
    return jsonify(result)

@app.get("/questionnaire-schema")
def questionnaire_schema():
    from questions import questions
    return jsonify({"title":"中醫九大體質問卷（教學版）","scale":[{"code":str(i),"display":x} for i,x in [(1,"從不"),(2,"很少"),(3,"有時"),(4,"經常"),(5,"總是")]],"items":[{"linkId":str(q["id"]),"text":q["question"],"type":q["type"]} for q in questions]})

@app.get("/odor-questionnaire-schema")
def odor_schema():
    from seed_demo import ODOR_QUESTIONS
    return jsonify({"title":"聞診氣味自述問卷","notice":"氣味資料由使用者主觀填寫，並非感測器直接量測。","items":[{"linkId":i,"text":t} for i,t in ODOR_QUESTIONS]})

@app.post("/demo/manual")
@roles_required("patient","clinician","admin")
def create_manual_demo():
    from seed_demo import generate_samples_from_input, replace_local_demo
    try: resources=generate_samples_from_input(request.get_json(silent=True) or {}); replace_local_demo(resources); audit("regenerate-demo","Patient/001"); return jsonify({"ok":True,"resources":len(resources)})
    except ValueError as exc: return outcome(str(exc))

@app.post("/patient/assessment")
@roles_required("patient","clinician")
def patient_assessment():
    from seed_demo import generate_samples_from_input
    data=request.get_json(silent=True) or {}
    # 問卷必須完整作答，避免直接呼叫 API 時由 seed_demo 的預設值代填。
    missing=[str(i) for i in range(1,46) if f"q{i}" not in data]
    invalid=[str(i) for i in range(1,46) if f"q{i}" in data and str(data.get(f"q{i}")) not in {"1","2","3","4","5"}]
    if missing: return outcome("九大體質問卷尚未完成，缺少題號："+", ".join(missing),400,"incomplete")
    if invalid: return outcome("九大體質問卷答案格式錯誤，題號："+", ".join(invalid),400,"invalid")
    # patient 使用自己的 patient_id；醫護代填時必須明確指定 patient_id。
    pid=session.get("patient_id") if session.get("role")=="patient" else str(data.get("patient_id","")).strip()
    if not pid or not load_resource("Patient",pid): return outcome("找不到目前病人資料",404,"not-found")
    try: resources=generate_samples_from_input(data)
    except ValueError as exc: return outcome(str(exc))
    # seed_demo 以 001 為範例模板；在儲存前將所有 Patient/001 與病人專屬資源 ID 轉為目前病人。
    patient_specific_types={"Patient","Person","Device","Encounter","QuestionnaireResponse","Observation","ClinicalImpression","DiagnosticReport"}
    id_map={"Patient/001":f"Patient/{pid}","Person/person-patient-001":f"Person/person-{pid}"}
    for r in resources:
        rt=r.get("resourceType"); old_id=r.get("id","")
        if rt=="Patient":
            r["id"]=pid
        elif rt=="Person" and old_id=="person-patient-001":
            r["id"]=f"person-{pid}"[:64]
        elif rt in patient_specific_types and rt not in {"Patient","Person"}:
            # 避免不同病人共用 ppg001、mic001、hr001 等 id 而互相覆蓋。
            r["id"]=f"{old_id}-{pid}"[:64]
        if old_id and r.get("id")!=old_id: id_map[f"{rt}/{old_id}"]=f"{rt}/{r['id']}"
    def rewrite_refs(obj):
        if isinstance(obj,dict):
            for k,v in list(obj.items()):
                if k=="reference" and isinstance(v,str): obj[k]=id_map.get(v,v.replace("Patient/001",f"Patient/{pid}"))
                elif k=="questionnaire" and isinstance(v,str): obj[k]=id_map.get(v,v)
                else: rewrite_refs(v)
        elif isinstance(obj,list):
            for v in obj: rewrite_refs(v)
    for r in resources: rewrite_refs(r)
    # 使用註冊/匯入後的 Patient 主檔資料，避免評估表單覆寫身份資料。
    resources=[r for r in resources if r.get("resourceType")!="Patient"]
    # 評估歷史策略：同一病人在管理員設定的時間窗內重複儲存，視為刷新同一次評估；超過時間窗才建立新的歷史評估。
    try:
        refresh_minutes=max(1,min(1440,int(get_setting("assessment_refresh_window_minutes","5"))))
    except (TypeError,ValueError):
        refresh_minutes=5
    now_dt=datetime.now(TZ_TAIPEI)
    suffix=None
    with get_db() as conn:
        row=conn.execute("SELECT assessment_suffix,started_at,last_saved_at FROM assessment_sessions WHERE patient_id=?",(pid,)).fetchone()
        if row:
            try:
                last_dt=datetime.fromisoformat(str(row["last_saved_at"]))
                if last_dt.tzinfo is None: last_dt=last_dt.replace(tzinfo=TZ_TAIPEI)
                if now_dt-last_dt <= timedelta(minutes=refresh_minutes): suffix=str(row["assessment_suffix"])
            except Exception:
                suffix=None
        if not suffix:
            suffix=now_dt.strftime("%Y%m%d%H%M%S%f")[:17]
            conn.execute("INSERT INTO assessment_sessions(patient_id,assessment_suffix,started_at,last_saved_at) VALUES(?,?,?,?) "
                         "ON CONFLICT(patient_id) DO UPDATE SET assessment_suffix=excluded.assessment_suffix,started_at=excluded.started_at,last_saved_at=excluded.last_saved_at",
                         (pid,suffix,now_dt.replace(microsecond=0).isoformat(),now_dt.replace(microsecond=0).isoformat()))
        else:
            conn.execute("UPDATE assessment_sessions SET last_saved_at=? WHERE patient_id=?",(now_dt.replace(microsecond=0).isoformat(),pid))
    historical={"Encounter","QuestionnaireResponse","Observation","ClinicalImpression","DiagnosticReport"}
    id_map={}
    for r in resources:
        if r["resourceType"] in historical:
            old_id=r["id"]; r["id"]=f"{old_id}-{suffix}"[:64]; id_map[f"{r['resourceType']}/{old_id}"]=f"{r['resourceType']}/{r['id']}"
    for r in resources:
        if isinstance(r.get("questionnaire"),str): r["questionnaire"]=id_map.get(r["questionnaire"],r["questionnaire"])
        for field in ("subject","patient","assessor"):
            ref=r.get(field);
            if isinstance(ref,dict) and ref.get("reference") in id_map: ref["reference"]=id_map[ref["reference"]]
        for item in r.get("result",[]):
            if isinstance(item,dict) and item.get("reference") in id_map: item["reference"]=id_map[item["reference"]]
        save_resource(r["resourceType"],validate_resource(r["resourceType"],r))
    # append odor QR and voice observations if supplied
    authored=now_iso()
    odor_items=[]
    for i in range(1,6):
        key=f"odor{i}"; val=bool(data.get(key,False)); odor_items.append({"linkId":f"odor-{i}","answer":[{"valueBoolean":val}]})
    odor_qr={"resourceType":"QuestionnaireResponse","id":f"odor-response-{suffix}","status":"completed","questionnaire":"Questionnaire/tcm-odor-q","subject":{"reference":f"Patient/{pid}"},"authored":authored,"item":odor_items}
    save_resource("QuestionnaireResponse",validate_resource("QuestionnaireResponse",odor_qr))
    voice_fields=[("voiceRmsDb",f"voice-rms-{suffix}","語音平均強度 dBFS","dBFS"),("voicePitchHz",f"voice-pitch-{suffix}","語音基本頻率估計","Hz"),("voiceDuration",f"voice-duration-{suffix}","錄音長度","s"),("breathRate",f"breath-rate-{suffix}","自述/輔助呼吸頻率","/min")]
    for key,rid,label,unit in voice_fields:
        if data.get(key) not in (None,""):
            try: val=float(data[key])
            except (TypeError,ValueError): continue
            obs={"resourceType":"Observation","id":rid,"status":"final","code":{"text":label},"subject":{"reference":f"Patient/{pid}"},"effectiveDateTime":authored,
                 "valueQuantity":({"value":round(val,2),"unit":unit,"code":unit} if unit=="dBFS" else {"value":round(val,2),"unit":unit,"system":"http://unitsofmeasure.org","code":unit}),"device":{"reference":f"Device/mic001-{pid}"[:64]},
                 "note":[{"text":"聞診聲音輔助特徵；瀏覽器估測值僅供競賽展示，不作疾病診斷。"}]}
            save_resource("Observation",validate_resource("Observation",obs))
    audit("submit-assessment",f"Patient/{pid}",f"assessment={suffix}; refresh_window={refresh_minutes}min"); return jsonify({"ok":True,"message":"評估資料已儲存","resources":len(search_local("Observation",pid)),"assessment_id":suffix,"refresh_window_minutes":refresh_minutes})

@app.get("/clinician/patients")
@roles_required("clinician","admin")
def clinician_patients():
    q=str(request.args.get("q","")).strip().lower()
    with get_db() as conn:
        accounts={r["patient_id"]:dict(r) for r in conn.execute("SELECT id,username,display_name,patient_id,active FROM users WHERE role='patient' AND patient_id IS NOT NULL").fetchall()}
    rows=[]
    for patient in search_local("Patient"):
        acc=accounts.get(patient.get("id"))
        national_id=patient_national_id(patient,acc)
        rows.append({
            "id":patient.get("id"),
            "name":fhir_human_name(patient, acc.get("display_name") if acc else "未命名病人"),
            "national_id":national_id,
            "fhir_pseudonym":fhir_pseudonym_for_patient(patient.get("id")),
            "gender":patient.get("gender","unknown"),
            "birthDate":patient.get("birthDate",""),
            "person_id":person_id_for_patient(patient.get("id")),
            "account":({"id":acc.get("id"),"username":acc.get("username"),"active":bool(acc.get("active"))} if acc else None)
        })
    if q:
        rows=[r for r in rows if q in " ".join(str(r.get(k) or "").lower() for k in ("id","name","national_id","birthDate"))]
    rows.sort(key=lambda x:(x["name"],x["id"]))
    return jsonify({"patients":rows,"query":q,"total":len(rows)})

@app.post("/clinician/patients")
@roles_required("clinician","admin")
def clinician_create_patient():
    """醫護/管理員手動建立病人；可選擇同時建立病人入口帳號。"""
    d=request.get_json(silent=True) or {}
    try:
        requested_pid=str(d.get("patient_id","")).strip() or None
        if requested_pid and not ID_RE.fullmatch(requested_pid):
            raise ValueError("patient FHIR id 格式不正確")
        patient,person=build_patient_identity(d,requested_pid)
        if load_resource("Patient",patient["id"]):
            return outcome("Patient id 已存在",409,"duplicate")
        if not load_resource("Organization","org001"):
            save_resource("Organization",{"resourceType":"Organization","id":"org001","active":True,"name":"TCM PPG FHIR Competition Demo Clinic"})
        save_resource("Patient",validate_resource("Patient",patient))
        save_resource("Person",validate_resource("Person",person))
        fhir_pseudonym_for_patient(patient["id"])
        username=str(d.get("username","")).strip()
        account_created=False
        initial_password=None
        if username:
            username=clean_national_id(username)
            set_patient_national_id(patient, username)
            save_resource("Patient",validate_resource("Patient",patient))
            initial_password=roc_birthday_password(patient.get("birthDate", ""))
            with get_db() as conn:
                if conn.execute("SELECT 1 FROM users WHERE username=?",(username,)).fetchone():
                    raise ValueError("此身分證字號已存在登入帳號")
                conn.execute("INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,active,must_change_password) VALUES(?,?,?,?,?,?,1,1)",
                             (username,generate_password_hash(initial_password),"patient",
                              d.get("display_name") or fhir_human_name(patient,"病人"),
                              person["id"],patient["id"]))
            account_created=True
        audit("clinician-create-patient",f"Patient/{patient['id']}",f"portal_account={account_created}; initial_password=ROC-birthday")
        resp=make_response(jsonify({"ok":True,"patient":patient,"person":person,"portal_account_created":account_created,
                        "initial_password":initial_password,"temporary_password_one_time":bool(initial_password)}),201)
        # 回應中的暫時密碼只供建立當下顯示，不寫入資料庫明文，也避免瀏覽器/代理快取。
        resp.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"]="no-cache"
        return resp
    except ValueError as exc: return outcome(str(exc))
    except sqlite3.IntegrityError: return outcome("病人身分證字號已存在",409,"duplicate")

@app.post("/clinician/patients/import-hapi")
@roles_required("clinician","admin")
def clinician_import_hapi_patient():
    """醫護以本機病人身分證帳號查詢；系統自動處理 pseudonym 與遠端 HAPI Patient ID。"""
    import requests
    d=request.get_json(silent=True) or {}
    national_id=str(d.get("national_id","")).strip().upper()
    if not national_id:
        return outcome("請輸入病人身分證字號")
    with get_db() as conn:
        acc=conn.execute("SELECT username,display_name,patient_id,active FROM users WHERE role='patient' AND UPPER(username)=? AND active=1",(national_id,)).fetchone()
    if not acc or not acc["patient_id"]:
        return outcome("本機找不到此病人帳號，請先確認身分證字號或建立病人資料",404,"not-found")
    local_pid=str(acc["patient_id"])
    local_patient=load_resource("Patient",local_pid)
    if not local_patient:
        return outcome("此帳號尚未綁定有效 Patient 主檔",404,"not-found")
    pseudo=fhir_pseudonym_for_patient(local_pid)
    remote_id=None
    with get_db() as conn:
        row=conn.execute("SELECT last_remote_patient_id FROM fhir_identity_map WHERE patient_id=?",(local_pid,)).fetchone()
        if row and row[0]: remote_id=str(row[0])
    try:
        base=get_base_url().rstrip('/')
        remote=None
        if remote_id:
            r=requests.get(f"{base}/Patient/{remote_id}",headers={"Accept":"application/fhir+json"},timeout=12)
            if r.ok: remote=r.json()
            elif r.status_code==404: remote_id=None
            else: r.raise_for_status()
        if remote is None:
            r=requests.get(f"{base}/Patient",params={"identifier":f"{PSEUDONYM_SYSTEM}|{pseudo}"},headers={"Accept":"application/fhir+json"},timeout=12)
            r.raise_for_status(); result=r.json(); entries=result.get("entry") or []
            if entries:
                remote=(entries[0] or {}).get("resource") or {}
                remote_id=str(remote.get("id") or "") or None
                if remote_id: remember_remote_patient_id(local_pid,remote_id)
        if remote is None:
            audit("resolve-hapi-patient-miss",f"Patient/{local_pid}",f"pseudonym={pseudo}")
            return jsonify({"ok":True,"matched":False,"message":"本機病人已找到，但 HAPI 尚無對應 Patient；請先上傳此病人的 FHIR 資料。","patient":local_patient,"national_id":national_id,"pseudonym":pseudo})
        remote_pseudo=pseudonym_from_fhir_patient(remote)
        if remote_pseudo and remote_pseudo!=pseudo:
            return outcome("HAPI Patient 的假名識別碼與本機病人不一致",409,"conflict")
        audit("resolve-hapi-patient",f"Patient/{local_pid}",f"remote={remote_id}; pseudonym={pseudo}")
        return jsonify({"ok":True,"matched":True,"message":"已由本機病人自動對應到 HAPI 假名化 Patient","remote_patient_id":remote_id,"pseudonym":pseudo,"patient":local_patient,"national_id":national_id,"account":dict(acc),"remote_patient":remote})
    except requests.RequestException as exc:
        return outcome(f"HAPI 查詢失敗：{exc}",502,"exception")

def verify_current_clinician_password(password: str) -> bool:
    if not password: return False
    with get_db() as conn:
        row=conn.execute("SELECT password_hash FROM users WHERE username=? AND role='clinician' AND active=1",(session.get("username"),)).fetchone()
    return bool(row and check_password_hash(row["password_hash"],password))

@app.post("/clinician/note/<patient_id>")
@roles_required("clinician")
def clinician_note(patient_id):
    if not load_resource("Patient",patient_id): return outcome("找不到病人",404,"not-found")
    text=str((request.get_json(silent=True) or {}).get("note","")).strip()
    if not text: return outcome("請輸入醫護註記")
    ci={"resourceType":"ClinicalImpression","id":f"clinician-note-{datetime.now().strftime('%Y%m%d%H%M%S')}","status":"completed","subject":{"reference":f"Patient/{patient_id}"},"date":now_iso(),"assessor":{"reference":f"Practitioner/{session.get('practitioner_id') or 'practitioner-001'}"},"description":"醫護人員評估註記","summary":text}
    save_resource("ClinicalImpression",validate_resource("ClinicalImpression",ci)); audit("clinician-note",f"Patient/{patient_id}"); return jsonify(ci)

@app.put("/clinician/note/<patient_id>/<note_id>")
@roles_required("clinician")
def clinician_update_note(patient_id,note_id):
    d=request.get_json(silent=True) or {}
    if not verify_current_clinician_password(str(d.get("password", ""))):
        return outcome("醫護帳號密碼驗證失敗，未執行修改",403,"forbidden")
    ci=load_resource("ClinicalImpression",note_id)
    if not ci or extract_patient_id("ClinicalImpression",ci)!=patient_id:
        return outcome("找不到指定醫護註記",404,"not-found")
    expected=f"Practitioner/{session.get('practitioner_id') or ''}"
    if ci.get("description")!="醫護人員評估註記" or (ci.get("assessor") or {}).get("reference")!=expected:
        return outcome("只能修改自己建立的醫護專業註記",403,"forbidden")
    text=str(d.get("note","")).strip()
    if not text: return outcome("註記內容不可空白")
    ci["summary"]=text; ci["date"]=now_iso()
    save_resource("ClinicalImpression",validate_resource("ClinicalImpression",ci))
    audit("clinician-note-update",f"ClinicalImpression/{note_id}",f"Patient/{patient_id}")
    return jsonify({"ok":True,"message":"醫護專業註記已修改","resource":ci})

@app.delete("/clinician/note/<patient_id>/<note_id>")
@roles_required("clinician")
def clinician_delete_note(patient_id,note_id):
    d=request.get_json(silent=True) or {}
    if not verify_current_clinician_password(str(d.get("password", ""))):
        return outcome("醫護帳號密碼驗證失敗，未執行刪除",403,"forbidden")
    ci=load_resource("ClinicalImpression",note_id)
    if not ci or extract_patient_id("ClinicalImpression",ci)!=patient_id:
        return outcome("找不到指定醫護註記",404,"not-found")
    expected=f"Practitioner/{session.get('practitioner_id') or ''}"
    if ci.get("description")!="醫護人員評估註記" or (ci.get("assessor") or {}).get("reference")!=expected:
        return outcome("只能刪除自己建立的醫護專業註記",403,"forbidden")
    with get_db() as conn:
        conn.execute("DELETE FROM resources WHERE resource_type='ClinicalImpression' AND id=? AND patient_id=?",(note_id,patient_id))
    audit("clinician-note-delete",f"ClinicalImpression/{note_id}",f"Patient/{patient_id}")
    return jsonify({"ok":True,"message":"醫護專業註記已刪除；操作已寫入 Audit log"})

@app.get("/admin/people")
@roles_required("admin")
def admin_people():
    """統一人員主檔：把登入帳號與 FHIR Patient/Person/Practitioner 視為同一組資料呈現。"""
    q=str(request.args.get("q","")).strip().lower()
    with get_db() as conn:
        users=[dict(r) for r in conn.execute("SELECT id,username,role,display_name,person_id,patient_id,practitioner_id,active,must_change_password FROM users ORDER BY id").fetchall()]
    by_patient={u.get("patient_id"):u for u in users if u.get("patient_id")}
    by_pract={u.get("practitioner_id"):u for u in users if u.get("practitioner_id")}
    records=[]; consumed=set()
    for patient in search_local("Patient"):
        pid=patient.get("id"); u=by_patient.get(pid); person_id=(u or {}).get("person_id") or person_id_for_patient(pid)
        rec={"record_type":"patient","role":"patient","name":fhir_human_name(patient,(u or {}).get("display_name") or "未命名病人"),
             "user_id":(u or {}).get("id"),"username":(u or {}).get("username"),"active":bool((u or {}).get("active")) if u else None,
             "account_status":(("需首次修改密碼" if u.get("must_change_password") else "已建立登入帳號") if u else "尚未建立登入帳號"),"must_change_password":bool((u or {}).get("must_change_password")) if u else None,"person_id":person_id,"patient_id":pid,"practitioner_id":None,
             "gender":patient.get("gender","unknown"),"birthDate":patient.get("birthDate",""),
             "fhir_pseudonym":fhir_pseudonym_for_patient(pid)}
        records.append(rec)
        if u: consumed.add(u["id"])
    for practitioner in search_local("Practitioner"):
        rid=practitioner.get("id"); u=by_pract.get(rid)
        rec={"record_type":"clinician","role":"clinician","name":fhir_human_name(practitioner,(u or {}).get("display_name") or "未命名醫護"),
             "user_id":(u or {}).get("id"),"username":(u or {}).get("username"),"active":bool((u or {}).get("active")) if u else None,
             "account_status":(("需首次修改密碼" if u.get("must_change_password") else "已建立登入帳號") if u else "尚未建立登入帳號"),"must_change_password":bool((u or {}).get("must_change_password")) if u else None,"person_id":(u or {}).get("person_id"),"patient_id":None,"practitioner_id":rid}
        records.append(rec)
        if u: consumed.add(u["id"])
    for u in users:
        if u["id"] in consumed: continue
        records.append({"record_type":"account","role":u.get("role"),"name":u.get("display_name"),"user_id":u.get("id"),"username":u.get("username"),
                        "active":bool(u.get("active")),"account_status":"需首次修改密碼" if u.get("must_change_password") else "已建立登入帳號","must_change_password":bool(u.get("must_change_password")),"person_id":u.get("person_id"),"patient_id":u.get("patient_id"),"practitioner_id":u.get("practitioner_id")})
    if q:
        def match(r):
            return q in " ".join(str(r.get(k) or "").lower() for k in ("username","name","role","patient_id","person_id","practitioner_id","account_status"))
        records=[r for r in records if match(r)]
    records.sort(key=lambda r:(r.get("role") or "",r.get("name") or "",r.get("patient_id") or r.get("practitioner_id") or ""))
    return jsonify({"people":records,"query":q,"total":len(records)})

@app.get("/admin/users")
@roles_required("admin")
def admin_users():
    q=str(request.args.get("q","")).strip()
    sql="SELECT id,username,role,display_name,person_id,patient_id,practitioner_id,active FROM users"
    params=[]
    if q:
        sql+=" WHERE username LIKE ? OR display_name LIKE ? OR role LIKE ?"
        like=f"%{q}%"; params=[like,like,like]
    sql+=" ORDER BY display_name COLLATE NOCASE, id"
    with get_db() as conn: rows=conn.execute(sql,params).fetchall()
    return jsonify({"users":[dict(r) for r in rows],"query":q,"total":len(rows)})

@app.post("/admin/users")
@roles_required("admin")
def admin_create_user():
    d=request.get_json(silent=True) or {}; role=d.get("role")
    if role not in {"patient","clinician","admin"}: return outcome("role 必須是 patient/clinician/admin")
    try:
        username=clean_national_id(d.get("username")) if role=="patient" else clean_username(d.get("username"))
        password=str(d.get("password", ""))
        if len(password)<6: raise ValueError("密碼至少 6 個字元")
        with get_db() as conn: conn.execute("INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,practitioner_id) VALUES(?,?,?,?,?,?,?)",
            (username,generate_password_hash(password),role,d.get("display_name") or username,d.get("person_id"),d.get("patient_id"),d.get("practitioner_id")))
    except ValueError as exc: return outcome(str(exc))
    except (KeyError,sqlite3.IntegrityError): return outcome("帳號資料不完整或帳號重複",409,"duplicate")
    audit("create-user",username); return jsonify({"ok":True}),201

@app.post("/admin/users/<int:user_id>/reset-password")
@roles_required("admin")
def admin_reset_user_password(user_id):
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    if not admin_password:
        return outcome("請輸入目前管理員密碼以確認重設",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，未執行重設",403,"forbidden")
        target=conn.execute("SELECT * FROM users WHERE id=? AND active=1",(user_id,)).fetchone()
        if not target:
            return outcome("找不到指定帳號",404,"not-found")
        if target["role"]!="patient" or not target["patient_id"]:
            return outcome("目前僅支援病人帳號以民國生日重設密碼",400,"invalid")
        patient=load_resource("Patient",target["patient_id"])
        birth_date=(patient or {}).get("birthDate","")
        try:
            temporary_password=roc_birthday_password(birth_date)
        except ValueError as exc:
            return outcome(str(exc),400,"invalid")
        conn.execute("UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?",(generate_password_hash(temporary_password),user_id))
        info={"id":target["id"],"username":target["username"],"display_name":target["display_name"],"patient_id":target["patient_id"]}
    audit("reset-password",target["username"],json.dumps(info,ensure_ascii=False))
    resp=make_response(jsonify({"ok":True,"message":"密碼已重設為民國生日；病人下次登入後必須立即修改密碼",
                                "temporary_password":temporary_password,"temporary_password_one_time":True,"target":info}))
    # 暫時密碼僅在本次重設成功回應中出現；資料庫只保存 password_hash。
    resp.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"]="no-cache"
    return resp

@app.delete("/admin/users/<int:user_id>")
@roles_required("admin")
def admin_delete_user(user_id):
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    if not admin_password: return outcome("請輸入目前管理員密碼以確認刪除",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，未執行刪除",403,"forbidden")
        target=conn.execute("SELECT * FROM users WHERE id=?",(user_id,)).fetchone()
        if not target: return outcome("找不到指定帳號",404,"not-found")
        if target["username"]==session.get("username"):
            return outcome("為避免目前工作階段失效，不能刪除正在登入的管理員帳號",409,"conflict")
        if target["role"]=="admin":
            admins=conn.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]
            if admins<=1: return outcome("系統至少必須保留一個可用管理員帳號",409,"conflict")
        info={"id":target["id"],"username":target["username"],"display_name":target["display_name"],"role":target["role"],"patient_id":target["patient_id"],"practitioner_id":target["practitioner_id"]}
        conn.execute("DELETE FROM users WHERE id=?",(user_id,))
    audit("delete-user",target["username"],json.dumps(info,ensure_ascii=False))
    return jsonify({"ok":True,"message":"帳號已刪除；FHIR/病歷資料未連帶刪除","deleted":info})

@app.get("/admin/settings/national-id-validation")
@roles_required("admin")
def admin_get_national_id_validation():
    mode=get_setting("national_id_validation_mode","demo")
    return jsonify({"mode":mode,"strict":mode=="strict"})

@app.post("/admin/settings/national-id-validation")
@roles_required("admin")
def admin_set_national_id_validation():
    d=request.get_json(silent=True) or {}
    mode=str(d.get("mode","")).strip().lower()
    admin_password=str(d.get("admin_password", ""))
    if mode not in {"demo","strict"}:
        return outcome("驗證模式必須是 demo 或 strict")
    if not admin_password:
        return outcome("請輸入目前管理員密碼以確認變更",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，設定未變更",403,"forbidden")
    old=get_setting("national_id_validation_mode","demo")
    set_setting("national_id_validation_mode",mode)
    audit("change-national-id-validation","system-setting",json.dumps({"from":old,"to":mode},ensure_ascii=False))
    return jsonify({"ok":True,"mode":mode,"strict":mode=="strict",
                    "message":"身分證驗證已切換為正式檢核模式" if mode=="strict" else "身分證驗證已切換為 Demo／測試模式"})

@app.get("/admin/settings/assessment-refresh-window")
@roles_required("admin")
def admin_get_assessment_refresh_window():
    try: minutes=max(1,min(1440,int(get_setting("assessment_refresh_window_minutes","5"))))
    except (TypeError,ValueError): minutes=5
    return jsonify({"minutes":minutes})

@app.post("/admin/settings/assessment-refresh-window")
@roles_required("admin")
def admin_set_assessment_refresh_window():
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    try: minutes=int(d.get("minutes",5))
    except (TypeError,ValueError): return outcome("刷新時間必須是整數分鐘")
    if minutes < 1 or minutes > 1440: return outcome("刷新時間需介於 1～1440 分鐘")
    if not admin_password: return outcome("請輸入目前管理員密碼以確認變更",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，設定未變更",403,"forbidden")
    old=get_setting("assessment_refresh_window_minutes","5")
    set_setting("assessment_refresh_window_minutes",str(minutes))
    audit("change-assessment-refresh-window","system-setting",json.dumps({"from":old,"to":minutes},ensure_ascii=False))
    return jsonify({"ok":True,"minutes":minutes,"message":f"短時間重複評估刷新視窗已設為 {minutes} 分鐘"})

@app.get("/admin/audit")
@roles_required("admin")
def admin_audit():
    with get_db() as conn: rows=conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify({"audit":[dict(r) for r in rows]})

@app.post("/appointment")
@roles_required("patient","clinician")
def create_appointment():
    d=request.get_json(silent=True) or {}; pid=session.get("patient_id") if session.get("role")=="patient" else str(d.get("patient_id") or "001")
    if not load_resource("Patient",pid): return outcome("找不到病人",404,"not-found")
    start=str(d.get("start") or (datetime.now(TZ_TAIPEI)+timedelta(days=1)).replace(microsecond=0).isoformat())
    end=str(d.get("end") or (datetime.now(TZ_TAIPEI)+timedelta(days=1,minutes=30)).replace(microsecond=0).isoformat())
    rid=f"appointment-{datetime.now().strftime('%Y%m%d%H%M%S')}"
    ap={"resourceType":"Appointment","id":rid,"status":"booked","start":start,"end":end,"description":"中醫數位健康評估預約",
        "participant":[{"actor":{"reference":f"Patient/{pid}"},"status":"accepted"},{"actor":{"reference":"Practitioner/practitioner-001"},"status":"accepted"}]}
    save_resource("Appointment",validate_resource("Appointment",ap)); audit("appointment",rid); return jsonify(ap),201

@app.get("/hapi/status")
@login_required
def hapi_status():
    try:
        m=server_metadata(); return jsonify({"ok":True,"server":get_base_url(),"fhirVersion":m.get("fhirVersion"),"software":m.get("software")})
    except HapiFhirError as exc: return outcome(str(exc),502,"exception")


def _upload(resources,filename):
    try:
        upload_resources,pseudonyms=pseudonymize_resources_for_hapi(resources)
        # Person 是本機帳號身分與 Patient 的橋接資源；公開 HAPI Demo 不需要上傳。
        # 公開 HAPI 的 Person 端點可能啟用重複資源檢查，重複 Demo 上傳會回 HTTP 412。
        # 因此對外交換保留 Patient / Practitioner / Observation 等醫療資料，Person 僅留本機。
        skipped_person_count=sum(1 for r in upload_resources if r.get("resourceType")=="Person")
        upload_resources=[r for r in upload_resources if r.get("resourceType")!="Person"]
        result=upload_ppg_demo(upload_resources)
        result["skippedLocalPersonResources"]=skipped_person_count
        # HAPI 會配置自己的 Patient id；把最後一次遠端 id 記回本機 mapping，之後 GET 可直接還原。
        for local_pid,pseudo in pseudonyms.items():
            remote_ref=(result.get("idMap") or {}).get(f"Patient/{local_pid}")
            if isinstance(remote_ref,str) and remote_ref.startswith("Patient/"):
                remember_remote_patient_id(local_pid,remote_ref.split("/",1)[1])
        result["privacyMode"]="pseudonymized"
        result["pseudonymizedPatients"]=len(pseudonyms)
        result["privacyNote"]="HAPI Patient 不包含本機登入身分證與真實姓名；本機以隨機 pseudonym 對照。"
        outdir=BASE_DIR/"hapi_results"; outdir.mkdir(exist_ok=True); path=outdir/filename
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8"); result["savedResultFile"]=str(path.relative_to(BASE_DIR)); return jsonify(result)
    except (HapiFhirError,ValueError,KeyError,OSError) as exc: return outcome(str(exc),502,"exception")

@app.post("/hapi/upload-demo")
@roles_required("clinician","admin")
def hapi_upload_demo():
    resources=[]
    for rt in RESOURCE_TYPES: resources.extend(search_local(rt))
    audit("hapi-upload","all-local-resources"); return _upload(resources,"latest_upload_and_readback.json")

@app.post("/hapi/upload-manual")
@roles_required("clinician","admin")
def hapi_upload_manual():
    from seed_demo import generate_samples_from_input, replace_local_demo
    try: resources=generate_samples_from_input(request.get_json(silent=True) or {}); replace_local_demo(resources)
    except ValueError as exc: return outcome(str(exc))
    return _upload(resources,"latest_manual_upload_and_readback.json")

@app.get("/hapi/latest-result")
@login_required
def latest_result():
    files=list((BASE_DIR/"hapi_results").glob("latest*_readback.json")) if (BASE_DIR/"hapi_results").exists() else []
    if not files: return outcome("尚無 HAPI 上傳結果",404,"not-found")
    latest=max(files,key=lambda p:p.stat().st_mtime); payload=json.loads(latest.read_text(encoding="utf-8")); payload["resultFile"]=str(latest.relative_to(BASE_DIR)); return jsonify(payload)

if __name__=="__main__":
    init_db()
    # 首次啟動會由 init_db() 建立三種角色的競賽測試帳號與必要 FHIR 身分。
    port=int(os.getenv("PORT","5000"))
    if os.getenv("AUTO_OPEN_BROWSER","1")=="1": threading.Timer(1.2,lambda:webbrowser.open_new(f"http://127.0.0.1:{port}/demo-start")).start()
    app.run(host="0.0.0.0",port=port,debug=os.getenv("FLASK_DEBUG")=="1",use_reloader=False)

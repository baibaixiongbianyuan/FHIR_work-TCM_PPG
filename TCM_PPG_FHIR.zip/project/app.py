from __future__ import annotations

import json, os, re, sqlite3, threading, webbrowser, uuid
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Iterable

from flask import Flask, jsonify, make_response, render_template, request, session, redirect, send_file
from werkzeug.security import check_password_hash, generate_password_hash

from hapi_client import HapiFhirError, get_base_url, server_metadata, upload_ppg_demo

BASE_DIR=Path(__file__).resolve().parent
DB_PATH=Path(os.getenv("FHIR_DB_PATH",BASE_DIR/"database.db"))
VOICE_DIR=BASE_DIR/"voice_recordings"
VOICE_DIR.mkdir(exist_ok=True)
app=Flask(__name__)
app.secret_key=os.getenv("SECRET_KEY","tcm-fhir-demo-change-me")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

RESOURCE_TYPES={"Organization","Person","Patient","Practitioner","Device","Encounter","Observation","ClinicalImpression","Questionnaire","QuestionnaireResponse"}
# 對外 HAPI 僅同步「以病人健康資料為核心」的 Resource。
# 預約／排班使用獨立 SQLite 本機資料表，不屬於 FHIR Resource；Encounter、Organization、Person 不列入 HAPI 核心同步；DiagnosticReport 已移除。
HAPI_SYNC_RESOURCE_TYPES={"Patient","Practitioner","Device","Observation","ClinicalImpression","Questionnaire","QuestionnaireResponse"}
HAPI_HISTORY_RESOURCE_TYPES={"Observation","ClinicalImpression","QuestionnaireResponse"}
HAPI_PUBLIC_ASSESSMENT_LIMIT=10
PATIENT_SCOPED={"Device","Encounter","Observation","ClinicalImpression","QuestionnaireResponse"}
ID_RE=re.compile(r"^[A-Za-z0-9\-.]{1,64}$")
TZ_TAIPEI=timezone(timedelta(hours=8))

ASSESSMENT_TAG_SYSTEM="https://example.org/fhir/assessment-id"
ASSESSMENT_SUFFIX_RE=re.compile(r"(\d{17})$")

def resource_time_value(r:dict)->str:
    return str(r.get("effectiveDateTime") or r.get("issued") or r.get("authored") or r.get("date") or r.get("start") or ((r.get("period") or {}).get("start")) or ((r.get("meta") or {}).get("lastUpdated")) or "")

def assessment_id_from_resource(r:dict)->str|None:
    for tag in ((r.get("meta") or {}).get("tag") or []):
        if isinstance(tag,dict) and tag.get("system")==ASSESSMENT_TAG_SYSTEM and tag.get("code"):
            return str(tag["code"])
    rid=str(r.get("id") or "")
    m=ASSESSMENT_SUFFIX_RE.search(rid)
    return m.group(1) if m else None

def attach_assessment_tag(r:dict,assessment_id:str)->None:
    meta=r.setdefault("meta",{})
    tags=meta.setdefault("tag",[])
    if not any(isinstance(t,dict) and t.get("system")==ASSESSMENT_TAG_SYSTEM and t.get("code")==assessment_id for t in tags):
        tags.append({"system":ASSESSMENT_TAG_SYSTEM,"code":assessment_id,"display":"Health assessment session"})

def code_label(r:dict)->str:
    c=r.get("code") or {}
    if isinstance(c,dict):
        if c.get("text"): return str(c["text"])
        for item in c.get("coding") or []:
            if isinstance(item,dict) and (item.get("display") or item.get("code")):
                return str(item.get("display") or item.get("code"))
    return ""

def summarize_assessment_resources(resources:list[dict],recordings:list[dict])->dict:
    obs=[r for r in resources if r.get("resourceType")=="Observation"]
    def metric(match):
        items=[o for o in obs if match(code_label(o).lower())]
        items.sort(key=resource_time_value,reverse=True)
        if not items:return None
        q=items[0].get("valueQuantity") or {}
        return {"value":q.get("value"),"unit":q.get("unit") or q.get("code") or "","time":resource_time_value(items[0])}
    heart=metric(lambda t:("heart" in t or "心率" in t or "8867-4" in t))
    spo2=metric(lambda t:("spo2" in t or "oxygen" in t or "血氧" in t or "59408-5" in t))
    hrv=metric(lambda t:("hrv" in t or "rmssd" in t))
    voice_duration=metric(lambda t:("錄音長度" in t or "voice duration" in t))
    voice_pitch=metric(lambda t:("基本頻率" in t or "pitch" in t))
    voice_db=metric(lambda t:("平均強度" in t or "dBFS".lower() in t or "rms" in t))
    score_obs=[o for o in obs if isinstance(o.get("component"),list) and len(o.get("component"))>=9]
    constitution=[]
    if score_obs:
        score_obs.sort(key=resource_time_value,reverse=True)
        for c in score_obs[0].get("component") or []:
            name=code_label({"code":c.get("code") or {}}) or str((c.get("code") or {}).get("text") or "體質")
            val=(c.get("valueQuantity") or {}).get("value")
            if val is None: val=c.get("valueInteger",c.get("valueDecimal"))
            constitution.append({"name":name,"value":val})
        constitution.sort(key=lambda x:float(x["value"] or 0),reverse=True)
    qrs=[r for r in resources if r.get("resourceType")=="QuestionnaireResponse"]
    tcm_qr=[r for r in qrs if "odor" not in str(r.get("questionnaire") or r.get("id") or "").lower()]
    odor_qr=[r for r in qrs if "odor" in str(r.get("questionnaire") or r.get("id") or "").lower()]
    cis=[r for r in resources if r.get("resourceType")=="ClinicalImpression"]
    times=[resource_time_value(r) for r in resources if resource_time_value(r)] + [str(x.get("updated_at") or x.get("created_at") or "") for x in recordings]
    return {
        "time":max(times) if times else "",
        "metrics":{"heart_rate":heart,"spo2":spo2,"hrv":hrv,"voice_duration":voice_duration,"voice_pitch":voice_pitch,"voice_db":voice_db},
        "constitution":constitution,
        "questionnaire_count":len(tcm_qr),
        "odor_count":len(odor_qr),
        "questionnaire_items":[
            {
                "linkId":it.get("linkId"),
                "text":it.get("text"),
                "answer":questionnaire_answer_display((it.get("answer") or [{}])[0])
            }
            for it in ((tcm_qr[0].get("item") or []) if tcm_qr else [])[:45]
        ],
        "odor_items":[
            {
                "linkId":it.get("linkId"),
                "text":it.get("text") or odor_question_text(it.get("linkId")),
                "answer":odor_answer_display((it.get("answer") or [{}])[0])
            }
            for it in ((odor_qr[0].get("item") or []) if odor_qr else [])
        ],
        "clinical_impressions":[{"id":x.get("id"),"description":x.get("description"),"summary":x.get("summary"),"date":x.get("date") or resource_time_value(x),"assessor_reference":((x.get("assessor") or {}).get("reference"))} for x in cis],
        "recordings":recordings,
        "resource_count":len(resources)
    }


def questionnaire_answer_display(answer:dict):
    """Return the saved 1-5 questionnaire answer in a human-readable form.

    Supports both current valueCoding storage and legacy integer/string forms so
    historical assessments do not appear blank after schema changes.
    """
    if not isinstance(answer,dict): return None
    scale={"1":"從不","2":"很少","3":"有時","4":"經常","5":"總是"}
    coding=answer.get("valueCoding") or {}
    if isinstance(coding,dict):
        code=str(coding.get("code") or "").strip()
        display=str(coding.get("display") or scale.get(code) or "").strip()
        if code and display: return f"{code} {display}"
        if display: return display
        if code: return code
    for key in ("valueInteger","valueDecimal"):
        if answer.get(key) is not None:
            code=str(answer.get(key)).strip()
            return f"{code} {scale[code]}" if code in scale else code
    if answer.get("valueString") is not None:
        text=str(answer.get("valueString")).strip()
        reverse={v:k for k,v in scale.items()}
        if text in reverse: return f"{reverse[text]} {text}"
        if text in scale: return f"{text} {scale[text]}"
        return text
    return None

def odor_answer_display(answer:dict):
    if not isinstance(answer,dict): return None
    if answer.get("valueBoolean") is not None:
        return "是" if bool(answer.get("valueBoolean")) else "否"
    if answer.get("valueString") is not None:
        return str(answer.get("valueString"))
    coding=answer.get("valueCoding") or {}
    if isinstance(coding,dict):
        return coding.get("display") or coding.get("code")
    return None

def odor_question_text(link_id):
    try:
        from seed_demo import ODOR_QUESTIONS
        raw=str(link_id or "")
        idx=int(raw.split("-")[-1]) if "-" in raw else int(raw)
        if 1 <= idx <= len(ODOR_QUESTIONS): return ODOR_QUESTIONS[idx-1]
    except Exception:
        pass
    return str(link_id or "氣味自述")

def now_iso(): return datetime.now(TZ_TAIPEI).replace(microsecond=0).isoformat()

def roc_birthday_password(birth_date: str) -> str:
    """將 YYYY-MM-DD 轉成民國生日密碼：民國年(不補零)+MMDD，例如 2006-12-30 -> 951230。"""
    try:
        dt=datetime.strptime(str(birth_date).strip(), "%Y-%m-%d")
    except (TypeError, ValueError):
        raise ValueError("建立登入帳號時必須填寫有效生日，初始密碼會使用民國生日")
    roc_year=dt.year-1911
    if roc_year <= 0:
        raise ValueError("生日必須為民國元年（1912）之後")
    return f"{roc_year}{dt.month:02d}{dt.day:02d}"

@contextmanager
def get_db():
    conn=sqlite3.connect(DB_PATH); conn.row_factory=sqlite3.Row; conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn; conn.commit()
    except Exception:
        conn.rollback(); raise
    finally: conn.close()


def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS resources(
          resource_type TEXT NOT NULL,id TEXT NOT NULL,patient_id TEXT,code TEXT,status TEXT,effective_date TEXT,
          resource_json TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(resource_type,id));
        CREATE INDEX IF NOT EXISTS idx_resources_patient ON resources(patient_id);
        CREATE INDEX IF NOT EXISTS idx_resources_type_patient ON resources(resource_type,patient_id);
        CREATE TABLE IF NOT EXISTS users(
          id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,
          display_name TEXT NOT NULL,person_id TEXT,patient_id TEXT,practitioner_id TEXT,active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS audit_log(
          id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,username TEXT,role TEXT,action TEXT NOT NULL,target TEXT,detail TEXT);
        CREATE TABLE IF NOT EXISTS app_settings(
          key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS fhir_identity_map(
          patient_id TEXT PRIMARY KEY,
          pseudonym TEXT UNIQUE NOT NULL,
          last_remote_patient_id TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_fhir_identity_pseudonym ON fhir_identity_map(pseudonym);
        CREATE INDEX IF NOT EXISTS idx_fhir_identity_remote ON fhir_identity_map(last_remote_patient_id);
        CREATE TABLE IF NOT EXISTS voice_recordings(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          patient_id TEXT NOT NULL,
          assessment_suffix TEXT,
          filename TEXT NOT NULL UNIQUE,
          original_mime TEXT,
          duration REAL,
          created_at TEXT NOT NULL,
          updated_at TEXT);
        CREATE INDEX IF NOT EXISTS idx_voice_recordings_patient ON voice_recordings(patient_id,created_at);
        CREATE TABLE IF NOT EXISTS assessment_sessions(
          patient_id TEXT PRIMARY KEY,
          assessment_suffix TEXT NOT NULL,
          started_at TEXT NOT NULL,
          last_saved_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS fhir_sync_state(
          local_ref TEXT PRIMARY KEY,
          remote_ref TEXT NOT NULL,
          last_synced_updated_at TEXT,
          last_sync_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_fhir_sync_remote ON fhir_sync_state(remote_ref);
        CREATE TABLE IF NOT EXISTS consultation_duration_preferences(
          patient_id TEXT NOT NULL,
          practitioner_id TEXT NOT NULL,
          estimated_duration_minutes INTEGER NOT NULL DEFAULT 30,
          last_actual_duration_minutes INTEGER,
          updated_at TEXT NOT NULL,
          PRIMARY KEY(patient_id,practitioner_id));
        CREATE INDEX IF NOT EXISTS idx_consult_duration_practitioner ON consultation_duration_preferences(practitioner_id,patient_id);

        -- 本機排班／預約資料：刻意不採 FHIR Resource 結構，也不進 HAPI。
        CREATE TABLE IF NOT EXISTS booking_availability(
          id TEXT PRIMARY KEY, practitioner_id TEXT NOT NULL, start_at TEXT NOT NULL, end_at TEXT NOT NULL,
          interval_minutes INTEGER NOT NULL, default_duration_minutes INTEGER NOT NULL,
          active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_booking_availability_practitioner ON booking_availability(practitioner_id,start_at,end_at);
        CREATE TABLE IF NOT EXISTS booking_slots(
          id TEXT PRIMARY KEY, availability_id TEXT NOT NULL, practitioner_id TEXT NOT NULL,
          start_at TEXT NOT NULL, end_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'free', booking_id TEXT,
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          FOREIGN KEY(availability_id) REFERENCES booking_availability(id));
        CREATE INDEX IF NOT EXISTS idx_booking_slots_practitioner_time ON booking_slots(practitioner_id,start_at,end_at);
        CREATE INDEX IF NOT EXISTS idx_booking_slots_booking ON booking_slots(booking_id);
        CREATE TABLE IF NOT EXISTS bookings(
          id TEXT PRIMARY KEY, patient_id TEXT NOT NULL, practitioner_id TEXT NOT NULL,
          start_at TEXT NOT NULL, end_at TEXT NOT NULL, estimated_duration_minutes INTEGER NOT NULL,
          status TEXT NOT NULL DEFAULT 'booked', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
          cancelled_at TEXT, cancelled_by_role TEXT);
        CREATE INDEX IF NOT EXISTS idx_bookings_patient ON bookings(patient_id,start_at);
        CREATE INDEX IF NOT EXISTS idx_bookings_practitioner ON bookings(practitioner_id,start_at);
        CREATE TABLE IF NOT EXISTS booking_slot_links(
          booking_id TEXT NOT NULL, slot_id TEXT NOT NULL, PRIMARY KEY(booking_id,slot_id));

        -- 醫護專業註記版本歷史：僅本機保存，用於顯示新增／修改／刪除歷程。
        CREATE TABLE IF NOT EXISTS clinician_note_history(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          note_id TEXT NOT NULL,
          patient_id TEXT NOT NULL,
          assessment_id TEXT,
          practitioner_id TEXT,
          practitioner_name TEXT,
          action TEXT NOT NULL,
          content TEXT NOT NULL,
          at TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS idx_clinician_note_history_patient ON clinician_note_history(patient_id,assessment_id,at);
        CREATE INDEX IF NOT EXISTS idx_clinician_note_history_note ON clinician_note_history(note_id,at);

        """)
        # Local booking lifecycle fields. These are SQLite-only and never synced to HAPI.
        booking_cols={r[1] for r in conn.execute("PRAGMA table_info(bookings)").fetchall()}
        for col,ddl in {
            "actual_start_at":"TEXT",
            "actual_end_at":"TEXT",
            "actual_duration_minutes":"INTEGER",
            "completed_at":"TEXT"
        }.items():
            if col not in booking_cols:
                conn.execute(f"ALTER TABLE bookings ADD COLUMN {col} {ddl}")
        # DiagnosticReport was removed from this project: legacy local rows are deleted on startup.
        conn.execute("DELETE FROM resources WHERE resource_type='DiagnosticReport'")
        conn.execute("DELETE FROM fhir_sync_state WHERE local_ref LIKE 'DiagnosticReport/%'")

        # 舊版曾以 FHIR-like Schedule/Slot/Appointment 儲存本機排班。首次開啟新版時自動搬到純 SQLite 排班表。
        legacy_rows=conn.execute("SELECT resource_type,id,resource_json,updated_at FROM resources WHERE resource_type IN ('Schedule','Slot','Appointment') ORDER BY CASE resource_type WHEN 'Schedule' THEN 1 WHEN 'Slot' THEN 2 ELSE 3 END").fetchall()
        if legacy_rows:
            legacy_schedules={}
            for row in legacy_rows:
                try: data=json.loads(row['resource_json'])
                except Exception: continue
                if row['resource_type']=='Schedule':
                    pref=next((str((a or {}).get('reference') or '') for a in data.get('actor',[]) if str((a or {}).get('reference') or '').startswith('Practitioner/')), '')
                    practitioner_id=pref.split('/',1)[1] if '/' in pref else ''
                    horizon=data.get('planningHorizon') or {}
                    ext={str(x.get('url','')).rsplit('/',1)[-1]:x for x in (data.get('extension') or []) if isinstance(x,dict)}
                    interval=int((ext.get('slot-interval-minutes') or {}).get('valueInteger') or 15)
                    default_duration=int((ext.get('default-consultation-duration-minutes') or {}).get('valueInteger') or 30)
                    created=(ext.get('availability-created-at') or {}).get('valueDateTime') or row['updated_at'] or now_iso()
                    if practitioner_id and horizon.get('start') and horizon.get('end'):
                        conn.execute("INSERT OR IGNORE INTO booking_availability(id,practitioner_id,start_at,end_at,interval_minutes,default_duration_minutes,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                                     (row['id'],practitioner_id,horizon['start'],horizon['end'],interval,default_duration,1 if data.get('active',True) is not False else 0,created,row['updated_at'] or created))
                        legacy_schedules[row['id']]=practitioner_id
            for row in legacy_rows:
                if row['resource_type']!='Slot': continue
                try: data=json.loads(row['resource_json'])
                except Exception: continue
                ref=str(((data.get('schedule') or {}).get('reference')) or '')
                aid=ref.split('/',1)[1] if ref.startswith('Schedule/') else ''
                practitioner_id=legacy_schedules.get(aid,'')
                if aid and practitioner_id and data.get('start') and data.get('end'):
                    st='free' if data.get('status')=='free' else ('unavailable' if data.get('status')=='busy-unavailable' else 'busy')
                    conn.execute("INSERT OR IGNORE INTO booking_slots(id,availability_id,practitioner_id,start_at,end_at,status,booking_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                                 (row['id'],aid,practitioner_id,data['start'],data['end'],st,None,row['updated_at'] or now_iso(),row['updated_at'] or now_iso()))
            for row in legacy_rows:
                if row['resource_type']!='Appointment': continue
                try: data=json.loads(row['resource_json'])
                except Exception: continue
                refs=[str((((x or {}).get('actor') or {}).get('reference')) or '') for x in (data.get('participant') or []) if isinstance(x,dict)]
                patient_ref=next((x for x in refs if x.startswith('Patient/')),''); practitioner_ref=next((x for x in refs if x.startswith('Practitioner/')),'')
                pid=patient_ref.split('/',1)[1] if '/' in patient_ref else ''; prid=practitioner_ref.split('/',1)[1] if '/' in practitioner_ref else ''
                ext={str(x.get('url','')).rsplit('/',1)[-1]:x for x in (data.get('extension') or []) if isinstance(x,dict)}
                duration=int((ext.get('estimated-consultation-duration-minutes') or {}).get('valueInteger') or 30)
                created=(ext.get('booking-created-at') or {}).get('valueDateTime') or row['updated_at'] or now_iso()
                cancelled=(ext.get('cancelled-at') or {}).get('valueDateTime'); cancelled_by=(ext.get('cancelled-by-role') or {}).get('valueString')
                if pid and prid and data.get('start') and data.get('end'):
                    conn.execute("INSERT OR IGNORE INTO bookings(id,patient_id,practitioner_id,start_at,end_at,estimated_duration_minutes,status,created_at,updated_at,cancelled_at,cancelled_by_role) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                                 (row['id'],pid,prid,data['start'],data['end'],duration,data.get('status') or 'booked',created,row['updated_at'] or created,cancelled,cancelled_by))
                    for it in data.get('slot',[]) or []:
                        ref=str((it or {}).get('reference') or '') if isinstance(it,dict) else ''
                        if ref.startswith('Slot/'):
                            sid=ref.split('/',1)[1]
                            conn.execute("INSERT OR IGNORE INTO booking_slot_links(booking_id,slot_id) VALUES(?,?)",(row['id'],sid))
                            conn.execute("UPDATE booking_slots SET booking_id=?,status=? WHERE id=?",(row['id'],'busy' if data.get('status')=='booked' else 'free',sid))
            conn.execute("DELETE FROM resources WHERE resource_type IN ('Schedule','Slot','Appointment')")
            conn.execute("DELETE FROM fhir_sync_state WHERE local_ref LIKE 'Schedule/%' OR local_ref LIKE 'Slot/%' OR local_ref LIKE 'Appointment/%'")

        # Schema migration for password reset / first-login password change.
        cols={r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
        if "must_change_password" not in cols:
            conn.execute("ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0")
        voice_cols={r[1] for r in conn.execute("PRAGMA table_info(voice_recordings)").fetchall()}
        if "assessment_suffix" not in voice_cols:
            conn.execute("ALTER TABLE voice_recordings ADD COLUMN assessment_suffix TEXT")
        if "updated_at" not in voice_cols:
            conn.execute("ALTER TABLE voice_recordings ADD COLUMN updated_at TEXT")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_voice_recordings_assessment ON voice_recordings(patient_id,assessment_suffix)")
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("national_id_validation_mode","demo",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("assessment_refresh_window_minutes","5",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("booking_base_interval_minutes","5",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("fhir_auto_sync_enabled","1",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("fhir_auto_sync_interval_minutes","60",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("fhir_auto_sync_last_attempt","",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("fhir_auto_sync_last_success","",now_iso()))
        conn.execute("INSERT OR IGNORE INTO app_settings(key,value,updated_at) VALUES(?,?,?)",
                     ("fhir_auto_sync_last_error","",now_iso()))
        existing=conn.execute("SELECT COUNT(*) c FROM users").fetchone()[0]
        if not existing:
            # 競賽展示首次啟動：預設建立三種角色的測試帳號。
            # 所有帳號皆為虛構測試號，不代表真實身分證字號。
            demo_password=generate_password_hash("Test1234!")
            conn.executemany(
                "INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,practitioner_id,must_change_password) VALUES(?,?,?,?,?,?,?,0)",
                [
                    ("A000000001", demo_password, "admin", "測試系統管理員", None, None, None),
                    ("B000000002", demo_password, "clinician", "測試醫護人員", "person-clinician-demo", None, "practitioner-001"),
                    ("C000000003", demo_password, "patient", "測試病人", "person-patient-demo", "demo-patient-001", None),
                ]
            )
            demo_resources=[
                {"resourceType":"Person","id":"person-clinician-demo","active":True,"name":[{"text":"測試醫護人員"}]},
                {"resourceType":"Practitioner","id":"practitioner-001","active":True,"name":[{"text":"測試醫護人員"}]},
                {"resourceType":"Person","id":"person-patient-demo","active":True,"name":[{"text":"測試病人"}]},
                {"resourceType":"Patient","id":"demo-patient-001","active":True,"name":[{"family":"測試","given":["病人"],"text":"測試病人"}],"gender":"unknown","birthDate":"2000-01-01"},
            ]
            for resource in demo_resources:
                rt=resource["resourceType"]
                pid=resource["id"] if rt=="Patient" else None
                conn.execute(
                    "INSERT OR REPLACE INTO resources(resource_type,id,patient_id,code,status,effective_date,resource_json,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                    (rt,resource["id"],pid,None,None,None,json.dumps(resource,ensure_ascii=False),now_iso())
                )


def audit(action,target="",detail=""):
    try:
        with get_db() as conn:
            conn.execute("INSERT INTO audit_log(at,username,role,action,target,detail) VALUES(?,?,?,?,?,?)",
                         (now_iso(),session.get("username"),session.get("role"),action,target,detail))
    except Exception: pass


def outcome(diagnostics,status=400,code="invalid",severity="error"):
    return jsonify({"resourceType":"OperationOutcome","issue":[{"severity":severity,"code":code,"diagnostics":diagnostics}]}),status


def normalize_reference(value:Any,expected_type="Patient"):
    if isinstance(value,dict): value=value.get("reference")
    if not isinstance(value,str) or not value.strip(): raise ValueError(f"缺少 {expected_type} reference")
    value=value.strip().rstrip("/"); prefix,rid=(value.rsplit("/",1) if "/" in value else (expected_type,value))
    if prefix!=expected_type or not ID_RE.fullmatch(rid): raise ValueError(f"reference 必須為 {expected_type}/<id>")
    return rid


def validate_id(data):
    rid=data.get("id")
    if not isinstance(rid,str) or not ID_RE.fullmatch(rid): raise ValueError("FHIR id 僅可含英數、-、.，長度 1–64")
    return rid


def require(data,*fields):
    missing=[f for f in fields if data.get(f) in (None,"",[],{})]
    if missing: raise ValueError("缺少必要欄位："+", ".join(missing))


def coding_code(codeable):
    if not isinstance(codeable,dict): return None
    coding=codeable.get("coding") or []
    if coding and isinstance(coding[0],dict) and coding[0].get("code"): return str(coding[0]["code"])
    return str(codeable.get("text")) if codeable.get("text") else None


def extract_patient_id(rt,data):
    if rt=="Patient": return data.get("id")
    if rt=="Device": ref=data.get("patient")
    elif rt in {"Questionnaire","Organization","Person","Practitioner"}: return None
    elif rt=="Appointment":
        for p in data.get("participant",[]):
            ref=((p or {}).get("actor") or {}).get("reference","")
            if ref.startswith("Patient/"): return ref.split("/",1)[1]
        return None
    else: ref=data.get("subject")
    try: return normalize_reference(ref) if ref else None
    except ValueError: return None


def validate_resource(rt,data):
    if not isinstance(data,dict): raise ValueError("Request body 必須是 JSON object")
    if data.get("resourceType") not in (None,rt): raise ValueError(f"resourceType 必須為 {rt}")
    data=json.loads(json.dumps(data,ensure_ascii=False)); data["resourceType"]=rt; validate_id(data)
    if rt=="Patient": require(data,"name")
    elif rt=="Organization": require(data,"name")
    elif rt=="Person": require(data,"name")
    elif rt=="Practitioner": require(data,"name")
    elif rt=="Device": require(data,"status","deviceName")
    elif rt=="Encounter": require(data,"status","class","subject","period")
    elif rt=="Observation":
        require(data,"status","code","subject","effectiveDateTime")
        if not any(k in data for k in ("valueQuantity","valueCodeableConcept","valueString","valueInteger","component")): raise ValueError("Observation 必須包含 value[x] 或 component")
    elif rt=="Questionnaire": require(data,"status","title","item")
    elif rt=="QuestionnaireResponse": require(data,"status","questionnaire","subject","authored","item")
    elif rt=="ClinicalImpression": require(data,"status","subject","date","summary")
    return data


def save_resource(rt,data):
    patient_id=extract_patient_id(rt,data); code=coding_code(data.get("code")); status=data.get("status")
    effective=data.get("effectiveDateTime") or data.get("issued") or data.get("authored") or data.get("date") or data.get("start")
    with get_db() as conn:
        conn.execute("INSERT OR REPLACE INTO resources(resource_type,id,patient_id,code,status,effective_date,resource_json,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                     (rt,data["id"],patient_id,code,status,effective,json.dumps(data,ensure_ascii=False),now_iso()))


def load_resource(rt,rid):
    with get_db() as conn: row=conn.execute("SELECT resource_json FROM resources WHERE resource_type=? AND id=?",(rt,rid)).fetchone()
    return json.loads(row[0]) if row else None


def search_local(rt,patient_id=None):
    sql="SELECT resource_json FROM resources WHERE resource_type=?"; params=[rt]
    if patient_id is not None: sql+=" AND patient_id=?"; params.append(patient_id)
    sql+=" ORDER BY effective_date DESC,id"
    with get_db() as conn: rows=conn.execute(sql,params).fetchall()
    return [json.loads(r[0]) for r in rows]


def bundle(resources:Iterable[dict],bundle_type="searchset"):
    resources=list(resources); return {"resourceType":"Bundle","type":bundle_type,"total":len(resources),"entry":[{"fullUrl":f"{r['resourceType']}/{r['id']}","resource":r} for r in resources]}


def current_user():
    if not session.get("username"): return None
    return {k:session.get(k) for k in ("username","role","display_name","person_id","patient_id","practitioner_id","must_change_password")}


def login_required(fn):
    @wraps(fn)
    def wrapper(*a,**kw):
        if not session.get("username"): return outcome("請先登入",401,"login")
        return fn(*a,**kw)
    return wrapper


def roles_required(*roles):
    def dec(fn):
        @wraps(fn)
        def wrapper(*a,**kw):
            if not session.get("username"): return outcome("請先登入",401,"login")
            if session.get("role") not in roles: return outcome("權限不足",403,"forbidden")
            return fn(*a,**kw)
        return wrapper
    return dec


def new_fhir_id(prefix: str) -> str:
    return f"{prefix}-{uuid.uuid4().hex[:12]}"[:64]

def clean_username(value: str) -> str:
    value=str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9_.-]{3,40}", value):
        raise ValueError("帳號需為 3–40 字元，只能使用英數、_、-、.")
    return value

TAIWAN_ID_MAP={c:10+i for i,c in enumerate("ABCDEFGHJKLMNPQRSTUVXYWZIO")}
def get_setting(key: str, default: str="") -> str:
    with get_db() as conn:
        row=conn.execute("SELECT value FROM app_settings WHERE key=?",(key,)).fetchone()
    return str(row[0]) if row else default

def set_setting(key: str, value: str):
    with get_db() as conn:
        conn.execute("INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                     (key,value,now_iso()))

def strict_taiwan_id_check_enabled() -> bool:
    return get_setting("national_id_validation_mode","demo") == "strict"

def clean_national_id(value: str) -> str:
    value=str(value or "").strip().upper().replace(" ","")
    # 競賽 / Demo 預設只檢查 1 個英文字母 + 9 個數字，方便使用虛構測試帳號。
    if not re.fullmatch(r"[A-Z]\d{9}", value):
        raise ValueError("身分證字號格式需為 1 個英文字母＋9 個數字，例如 R123456789")
    if not strict_taiwan_id_check_enabled():
        return value
    # 正式檢核模式由管理員後台的 app_settings 控制。
    if not re.fullmatch(r"[A-Z][12]\d{8}", value):
        raise ValueError("正式模式下，身分證字號第 2 碼須為 1 或 2")
    n=TAIWAN_ID_MAP.get(value[0])
    if n is None:
        raise ValueError("身分證字號首字母不正確")
    digits=[n//10,n%10]+[int(x) for x in value[1:]]
    weights=[1,9,8,7,6,5,4,3,2,1,1]
    if sum(d*w for d,w in zip(digits,weights))%10!=0:
        raise ValueError("身分證字號檢核碼不正確")
    return value

PSEUDONYM_SYSTEM="https://example.org/fhir-pseudonym"

def fhir_pseudonym_for_patient(patient_id: str) -> str:
    """取得或建立穩定的 FHIR 假名識別碼。此值不包含身分證字號，也不由身分證推導。"""
    patient_id=str(patient_id or "").strip()
    if not patient_id:
        raise ValueError("缺少 patient_id")
    with get_db() as conn:
        row=conn.execute("SELECT pseudonym FROM fhir_identity_map WHERE patient_id=?",(patient_id,)).fetchone()
        if row:
            return str(row[0])
        pseudonym="FHIRP-"+uuid.uuid4().hex.upper()
        conn.execute("INSERT INTO fhir_identity_map(patient_id,pseudonym,created_at,updated_at) VALUES(?,?,?,?)",
                     (patient_id,pseudonym,now_iso(),now_iso()))
        return pseudonym

def local_patient_id_from_pseudonym(pseudonym: str) -> str | None:
    with get_db() as conn:
        row=conn.execute("SELECT patient_id FROM fhir_identity_map WHERE pseudonym=?",(str(pseudonym or "").strip(),)).fetchone()
    return str(row[0]) if row else None

def local_patient_id_from_remote(remote_patient_id: str) -> str | None:
    with get_db() as conn:
        row=conn.execute("SELECT patient_id FROM fhir_identity_map WHERE last_remote_patient_id=?",(str(remote_patient_id or "").strip(),)).fetchone()
    return str(row[0]) if row else None

def remember_remote_patient_id(local_patient_id: str, remote_patient_id: str):
    pseudonym=fhir_pseudonym_for_patient(local_patient_id)
    with get_db() as conn:
        conn.execute("UPDATE fhir_identity_map SET last_remote_patient_id=?,updated_at=? WHERE patient_id=?",
                     (remote_patient_id,now_iso(),local_patient_id))
    return pseudonym

def pseudonym_from_fhir_patient(patient: dict) -> str | None:
    for ident in (patient or {}).get("identifier") or []:
        if isinstance(ident,dict) and ident.get("system")==PSEUDONYM_SYSTEM and ident.get("value"):
            return str(ident.get("value"))
    return None

def pseudonymize_resources_for_hapi(resources: list[dict]) -> tuple[list[dict],dict[str,str]]:
    """只修改準備上傳 HAPI 的複本；本機可視化病人資料保持原樣。"""
    out=json.loads(json.dumps(resources,ensure_ascii=False))
    aliases={}
    patient_ids={r.get("id") for r in out if r.get("resourceType")=="Patient" and r.get("id")}
    for pid in patient_ids:
        aliases[pid]=fhir_pseudonym_for_patient(pid)
    for r in out:
        rt=r.get("resourceType")
        if rt=="Patient" and r.get("id") in aliases:
            pseudo=aliases[r["id"]]
            # 公開/外部 FHIR 不帶登入身分證與真實姓名。保留一個不可逆隨機假名識別碼供本機重新對應。
            r["identifier"]=[{"system":PSEUDONYM_SYSTEM,"value":pseudo}]
            r["name"]=[{"text":f"匿名病人 {pseudo[-8:]}"}]
            # 生日屬可重新識別資訊；競賽 HAPI 上傳預設移除。
            r.pop("birthDate",None)
            r.pop("telecom",None); r.pop("address",None); r.pop("photo",None)
        elif rt=="Person":
            linked_pid=None
            for link in r.get("link") or []:
                ref=((link or {}).get("target") or {}).get("reference","")
                if ref.startswith("Patient/"):
                    linked_pid=ref.split("/",1)[1]; break
            if linked_pid in aliases:
                pseudo=aliases[linked_pid]
                r["name"]=[{"text":f"匿名病人 {pseudo[-8:]}"}]
                r.pop("telecom",None); r.pop("address",None); r.pop("birthDate",None); r.pop("photo",None)
    return out,aliases

def build_patient_identity(data: dict, patient_id: str | None=None, person_id: str | None=None):
    patient_id=patient_id or new_fhir_id("patient")
    person_id=person_id or new_fhir_id("person")
    family=str(data.get("family","")).strip()
    given=str(data.get("given","")).strip()
    if not family or not given:
        raise ValueError("請填寫姓與名")
    gender=str(data.get("gender","unknown"))
    if gender not in {"male","female","other","unknown"}:
        raise ValueError("性別格式不正確")
    birth_date=str(data.get("birthDate","")).strip()
    if birth_date:
        birth_date=birth_date.replace("/","-")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", birth_date):
            raise ValueError("生日格式需為 yyyy/mm/dd")
        try:
            datetime.strptime(birth_date, "%Y-%m-%d")
        except ValueError:
            raise ValueError("生日日期不正確")
    patient={"resourceType":"Patient","id":patient_id,
             "identifier":[{"system":"https://example.org/patient-id","value":patient_id}],
             "name":[{"family":family,"given":[given]}],"gender":gender,
             "managingOrganization":{"reference":"Organization/org001"}}
    if birth_date: patient["birthDate"]=birth_date
    person={"resourceType":"Person","id":person_id,
            "name":[{"family":family,"given":[given]}],
            "link":[{"target":{"reference":f"Patient/{patient_id}"},"assurance":"level3"}]}
    return patient,person

def fhir_human_name(resource: dict | None, fallback="") -> str:
    if not isinstance(resource,dict): return fallback
    names=resource.get("name") or []
    if not names or not isinstance(names[0],dict): return fallback
    n=names[0]
    if n.get("text"): return str(n.get("text")).strip() or fallback
    family=str(n.get("family") or "").strip()
    given="".join(str(x) for x in (n.get("given") or [])).strip()
    return (family+given).strip() or fallback

def patient_national_id(patient: dict | None, account: dict | None=None) -> str:
    """取得病人的台灣身分證字號；優先使用登入帳號，其次讀 Patient.identifier。"""
    if account and account.get("username"):
        value=str(account.get("username") or "").strip().upper()
        if re.fullmatch(r"[A-Z][12]\d{8}", value):
            return value
    if isinstance(patient, dict):
        for ident in patient.get("identifier") or []:
            if not isinstance(ident, dict):
                continue
            system=str(ident.get("system") or "")
            value=str(ident.get("value") or "").strip().upper()
            if system in {"https://example.org/tw-national-id","urn:oid:2.16.886.101.20003.20007"} and re.fullmatch(r"[A-Z][12]\d{8}", value):
                return value
    return ""

def set_patient_national_id(patient: dict, national_id: str) -> dict:
    ids=[x for x in (patient.get("identifier") or []) if isinstance(x,dict) and x.get("system")!="https://example.org/tw-national-id"]
    ids.append({"system":"https://example.org/tw-national-id","value":national_id})
    patient["identifier"]=ids
    return patient

def person_id_for_patient(patient_id: str) -> str | None:
    for person in search_local("Person"):
        for link in person.get("link") or []:
            ref=((link or {}).get("target") or {}).get("reference","")
            if ref==f"Patient/{patient_id}": return person.get("id")
    return None

def can_access_patient(patient_id):
    role=session.get("role")
    if role=="patient": return session.get("patient_id")==patient_id
    return role in {"clinician","admin"}

@app.get("/")
def home(): return render_template("index.html")

@app.get("/demo-start")
def demo_start():
    """競賽啟動入口：只在 START.bat 主動開啟時清除舊登入 Session。

    一般重新整理 / 不會登出；只有重新由啟動器開啟 /demo-start 才會回到登入頁。
    """
    session.clear()
    resp=make_response(redirect("/"))
    resp.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"
    return resp

@app.get("/report")
def report(): return render_template("report.html")

@app.post("/auth/login")
def auth_login():
    data=request.get_json(silent=True) or {}; username=str(data.get("username","")).strip(); password=str(data.get("password","")); requested_role=str(data.get("requested_role") or "").strip()
    with get_db() as conn: row=conn.execute("SELECT * FROM users WHERE username=? AND active=1",(username,)).fetchone()
    if not row or not check_password_hash(row["password_hash"],password): return outcome("帳號或密碼錯誤",401,"login")
    if requested_role in {"patient","clinician","admin"} and str(row["role"])!=requested_role:
        return outcome("此帳號不屬於目前選擇的登入身分，請切換正確身分後再登入",403,"role-mismatch")
    session.clear()
    for k in ("username","role","display_name","person_id","patient_id","practitioner_id"):
        session[k]=row[k]
    session["must_change_password"]=bool(row["must_change_password"])
    audit("login",username); return jsonify({"ok":True,"user":current_user()})

@app.post("/auth/logout")
def auth_logout():
    audit("logout",session.get("username",'')); session.clear(); return jsonify({"ok":True})
@app.get("/auth/me")
def auth_me(): return jsonify({"user":current_user()})

@app.post("/auth/change-password")
@login_required
def auth_change_password():
    d=request.get_json(silent=True) or {}
    current_password=str(d.get("current_password", ""))
    new_password=str(d.get("new_password", ""))
    confirm_password=str(d.get("confirm_password", ""))
    if len(new_password)<8:
        return outcome("新密碼至少 8 個字元",400,"invalid")
    if new_password!=confirm_password:
        return outcome("兩次輸入的新密碼不一致",400,"invalid")
    if new_password==current_password:
        return outcome("新密碼不可與目前密碼相同",400,"invalid")
    with get_db() as conn:
        row=conn.execute("SELECT * FROM users WHERE username=? AND active=1",(session.get("username"),)).fetchone()
        if not row or not check_password_hash(row["password_hash"],current_password):
            return outcome("目前密碼驗證失敗",403,"forbidden")
        conn.execute("UPDATE users SET password_hash=?, must_change_password=0 WHERE id=?",(generate_password_hash(new_password),row["id"]))
    session["must_change_password"]=False
    audit("change-password",session.get("username",""),"user changed password")
    return jsonify({"ok":True,"message":"密碼已更新"})

@app.get("/auth/national-id-policy")
def national_id_policy():
    mode=get_setting("national_id_validation_mode","demo")
    return jsonify({
        "mode":mode,
        "strict":mode=="strict",
        "label":"正式檢核模式" if mode=="strict" else "Demo／測試模式",
        "message":("目前啟用正式台灣身分證檢核：將檢查格式、第 2 碼與 checksum。"
                   if mode=="strict" else
                   "目前為競賽 Demo／測試模式：只檢查 1 個英文字母＋9 個數字。請使用虛構測試資料，勿輸入真實個資。")
    })

@app.post("/auth/register")
def auth_register():
    """病人自助註冊：建立本機登入帳號，同時建立 FHIR Person + Patient。"""
    d=request.get_json(silent=True) or {}
    try:
        username=clean_national_id(d.get("national_id") or d.get("username"))
        password=str(d.get("password",""))
        if len(password)<6: raise ValueError("密碼至少 6 個字元")
        patient,person=build_patient_identity(d)
        set_patient_national_id(patient, username)
        display_name=str(d.get("display_name") or f"{patient['name'][0]['family']}{patient['name'][0]['given'][0]}").strip()
        with get_db() as conn:
            if conn.execute("SELECT 1 FROM users WHERE username=?",(username,)).fetchone():
                return outcome("此身分證字號已註冊",409,"duplicate")
            conn.execute("INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,active) VALUES(?,?,?,?,?,?,1)",
                         (username,generate_password_hash(password),"patient",display_name,person["id"],patient["id"]))
        # 病人自助註冊的登入帳號已在上方完成驗證與建立。
        # 不再重複使用 username 欄位檢查，避免前端送 national_id 時誤判為缺少帳號。
        # 接著建立對應的本機 FHIR Person / Patient。
        if not load_resource("Organization","org001"):
            save_resource("Organization",{"resourceType":"Organization","id":"org001","active":True,"name":"TCM PPG FHIR Competition Demo Clinic"})
        save_resource("Patient",validate_resource("Patient",patient))
        save_resource("Person",validate_resource("Person",person))
        fhir_pseudonym_for_patient(patient["id"])
        audit("self-register",f"Patient/{patient['id']}",username)
        return jsonify({"ok":True,"message":"註冊成功，請使用新帳號登入","patient_id":patient["id"],"person_id":person["id"]}),201
    except ValueError as exc:
        return outcome(str(exc))
    except sqlite3.IntegrityError:
        return outcome("帳號建立失敗：此身分證字號可能已註冊",409,"duplicate")
    except Exception as exc:
        # API 一律回 JSON OperationOutcome，避免前端收到 Flask HTML 錯誤頁後出現 Unexpected token '<'。
        app.logger.exception("patient self-register failed")
        return outcome(f"註冊失敗：{exc}",500,"exception")

@app.get("/metadata")
def metadata():
    return jsonify({"resourceType":"CapabilityStatement","status":"active","kind":"instance","fhirVersion":"4.0.1","format":["json"],"rest":[{"mode":"server","resource":[{"type":t,"interaction":[{"code":"read"},{"code":"create"},{"code":"search-type"}]} for t in sorted(RESOURCE_TYPES)]}]})

@app.route("/<resource_type>",methods=["GET","POST"])
@login_required
def collection(resource_type):
    if resource_type not in RESOURCE_TYPES: return outcome("不支援的 resourceType",404,"not-found")
    if request.method=="POST":
        if session.get("role")=="patient" and resource_type not in {"QuestionnaireResponse","Observation"}: return outcome("病人端不可建立此資源",403,"forbidden")
        try: data=validate_resource(resource_type,request.get_json(silent=True))
        except ValueError as exc: return outcome(str(exc))
        pid=extract_patient_id(resource_type,data)
        if pid and not can_access_patient(pid): return outcome("不可寫入其他病人的資料",403,"forbidden")
        save_resource(resource_type,data); audit("create",f"{resource_type}/{data['id']}")
        resp=make_response(jsonify(data),201); resp.headers["Location"]=f"/{resource_type}/{data['id']}"; return resp
    patient=request.args.get("patient") or request.args.get("subject")
    if session.get("role")=="patient": patient=session.get("patient_id") if resource_type in PATIENT_SCOPED or resource_type=="Patient" else patient
    if patient and not can_access_patient(patient): return outcome("不可查看其他病人的資料",403,"forbidden")
    if resource_type=="Patient" and session.get("role")=="patient":
        p=load_resource("Patient",session.get("patient_id")); return jsonify(bundle([p] if p else []))
    return jsonify(bundle(search_local(resource_type,patient)))

@app.get("/<resource_type>/<rid>")
@login_required
def read_resource(resource_type,rid):
    if resource_type not in RESOURCE_TYPES: return outcome("不支援的 resourceType",404,"not-found")
    r=load_resource(resource_type,rid)
    if not r: return outcome("找不到資源",404,"not-found")
    pid=extract_patient_id(resource_type,r)
    if pid and not can_access_patient(pid): return outcome("不可查看其他病人的資料",403,"forbidden")
    audit("read",f"{resource_type}/{rid}"); return jsonify(r)

@app.get("/patient/profile")
@roles_required("patient")
def patient_profile():
    """回傳目前病人帳號實際綁定的 Patient 主檔，供病人頁初始化基本資料。"""
    patient_id=session.get("patient_id")
    if not patient_id:
        return outcome("此病人帳號尚未綁定 Patient",404,"not-found")
    patient=load_resource("Patient",patient_id)
    if not patient:
        return outcome("找不到此帳號對應的 Patient 主檔",404,"not-found")
    return jsonify({"ok":True,"patient":patient})

@app.get("/EMR/Patient/<patient_id>")
@login_required
def patient_emr(patient_id):
    if not can_access_patient(patient_id): return outcome("不可查看其他病人的資料",403,"forbidden")
    p=load_resource("Patient",patient_id)
    if not p: return outcome("找不到病人",404,"not-found")
    resources=[p]
    for rt in ("Device","Encounter","Observation","QuestionnaireResponse","ClinicalImpression"):
        resources.extend(search_local(rt,patient_id))
    for rt in ("Questionnaire",): resources.extend(search_local(rt))
    audit("read-emr",f"Patient/{patient_id}"); return jsonify(bundle(resources,"collection"))



@app.post("/patient/voice-recording")
@roles_required("patient")
def patient_voice_recording_upload():
    patient_id=session.get("patient_id")
    if not patient_id or not load_resource("Patient",patient_id):
        return outcome("找不到目前病人資料",404,"not-found")
    f=request.files.get("audio")
    if not f or not f.filename:
        return outcome("缺少錄音檔",400,"required")
    raw=f.read()
    if not raw:
        return outcome("錄音檔內容為空",400,"invalid")
    if len(raw)>15*1024*1024:
        return outcome("錄音檔超過 15 MB",413,"too-costly")
    mime=(f.mimetype or "audio/webm").lower()
    ext=".webm"
    if "ogg" in mime: ext=".ogg"
    elif "wav" in mime: ext=".wav"
    elif "mp4" in mime or "m4a" in mime: ext=".m4a"
    try: duration=float(request.form.get("duration") or 0)
    except ValueError: duration=0
    assessment_suffix=str(request.form.get("assessment_id") or "").strip()
    created=now_iso()

    # 錄音與完整評估綁定：同一 assessment（預設 5 分鐘刷新視窗內）只保留最新一份錄音。
    # 超過刷新視窗後，/patient/assessment 會建立新的 assessment_id，因此自然形成新的歷史錄音。
    old_filename=None
    with get_db() as conn:
        existing=None
        if assessment_suffix:
            existing=conn.execute(
                "SELECT id,filename,created_at FROM voice_recordings WHERE patient_id=? AND assessment_suffix=? ORDER BY id DESC LIMIT 1",
                (patient_id,assessment_suffix)
            ).fetchone()
        filename=f"voice-{uuid.uuid4().hex}{ext}"
        (VOICE_DIR/filename).write_bytes(raw)
        if existing:
            old_filename=existing["filename"]
            rid=existing["id"]
            conn.execute(
                "UPDATE voice_recordings SET filename=?,original_mime=?,duration=?,updated_at=? WHERE id=?",
                (filename,mime,duration,created,rid)
            )
            action="voice-recording-refresh"
        else:
            cur=conn.execute(
                "INSERT INTO voice_recordings(patient_id,assessment_suffix,filename,original_mime,duration,created_at,updated_at) VALUES(?,?,?,?,?,?,?)",
                (patient_id,assessment_suffix or None,filename,mime,duration,created,created)
            )
            rid=cur.lastrowid
            action="voice-recording-upload"
    if old_filename and old_filename!=filename:
        try:
            old_path=VOICE_DIR/old_filename
            if old_path.exists(): old_path.unlink()
        except OSError:
            pass
    audit(action,f"Patient/{patient_id}",f"recording_id={rid}; assessment={assessment_suffix or '-'}")
    return jsonify({"ok":True,"id":rid,"created_at":created,"duration":duration,"assessment_id":assessment_suffix or None,"refreshed":bool(old_filename)})

@app.get("/voice-recordings")
@login_required
def voice_recordings_list():
    patient_id=str(request.args.get("patient_id") or session.get("patient_id") or "").strip()
    if not patient_id or not can_access_patient(patient_id):
        return outcome("不可查看此病人的錄音",403,"forbidden")
    with get_db() as conn:
        rows=conn.execute("SELECT id,assessment_suffix,duration,created_at,updated_at,original_mime FROM voice_recordings WHERE patient_id=? ORDER BY COALESCE(updated_at,created_at) DESC,id DESC",(patient_id,)).fetchall()
    return jsonify({"patient_id":patient_id,"recordings":[{"id":r["id"],"assessment_id":r["assessment_suffix"],"duration":r["duration"],"created_at":r["created_at"],"updated_at":r["updated_at"],"mime":r["original_mime"],"url":f"/voice-recordings/{r['id']}/audio"} for r in rows]})

@app.get("/voice-recordings/<int:recording_id>/audio")
@login_required
def voice_recording_audio(recording_id):
    with get_db() as conn:
        row=conn.execute("SELECT * FROM voice_recordings WHERE id=?",(recording_id,)).fetchone()
    if not row: return outcome("找不到錄音檔",404,"not-found")
    if not can_access_patient(row["patient_id"]): return outcome("不可播放此病人的錄音",403,"forbidden")
    path=VOICE_DIR/row["filename"]
    if not path.exists(): return outcome("錄音檔已不存在",404,"not-found")
    audit("voice-recording-play",f"Patient/{row['patient_id']}",f"recording_id={recording_id}")
    return send_file(path,mimetype=row["original_mime"] or "audio/webm",conditional=True)

@app.get("/device/ppg/detect")
@roles_required("patient","clinician","admin")
def device_ppg_detect():
    from ppg_device import detect_ppg_device
    result=detect_ppg_device(); audit("ppg-detect", result.get("selected",{}).get("device","") if result.get("selected") else "", result.get("reason","")); return jsonify(result)

@app.post("/device/ppg/read")
@roles_required("patient","clinician","admin")
def device_ppg_read():
    from ppg_device import read_ppg_sample
    d=request.get_json(silent=True) or {}
    try:
        result=read_ppg_sample(port=(str(d.get("port") or "").strip() or None), baudrate=int(d.get("baudrate",115200)), timeout_seconds=float(d.get("timeout",8)))
    except (RuntimeError,ValueError) as exc:
        audit("ppg-read-failed", str(d.get("port") or "auto"), str(exc)); return outcome(str(exc),422,"processing")
    audit("ppg-read", result.get("port",{}).get("device",""), f"samples={result.get('samplesUsed',0)} missing={result.get('missing',[])}")
    return jsonify(result)

@app.get("/questionnaire-schema")
def questionnaire_schema():
    from questions import questions
    return jsonify({"title":"中醫九大體質問卷（教學版）","scale":[{"code":str(i),"display":x} for i,x in [(1,"從不"),(2,"很少"),(3,"有時"),(4,"經常"),(5,"總是")]],"items":[{"linkId":str(q["id"]),"text":q["question"],"type":q["type"]} for q in questions]})

@app.get("/odor-questionnaire-schema")
def odor_schema():
    from seed_demo import ODOR_QUESTIONS
    return jsonify({"title":"聞診氣味自述問卷","notice":"氣味資料由使用者主觀填寫，並非感測器直接量測。","items":[{"linkId":i,"text":t} for i,t in ODOR_QUESTIONS]})

@app.post("/demo/manual")
@roles_required("patient","clinician","admin")
def create_manual_demo():
    from seed_demo import generate_samples_from_input, replace_local_demo
    try: resources=generate_samples_from_input(request.get_json(silent=True) or {}); replace_local_demo(resources); audit("regenerate-demo","Patient/001"); return jsonify({"ok":True,"resources":len(resources)})
    except ValueError as exc: return outcome(str(exc))

@app.post("/patient/assessment")
@roles_required("patient","clinician")
def patient_assessment():
    from seed_demo import generate_samples_from_input
    data=request.get_json(silent=True) or {}
    # 問卷必須完整作答，避免直接呼叫 API 時由 seed_demo 的預設值代填。
    missing=[str(i) for i in range(1,46) if f"q{i}" not in data]
    invalid=[str(i) for i in range(1,46) if f"q{i}" in data and str(data.get(f"q{i}")) not in {"1","2","3","4","5"}]
    if missing: return outcome("九大體質問卷尚未完成，缺少題號："+", ".join(missing),400,"incomplete")
    if invalid: return outcome("九大體質問卷答案格式錯誤，題號："+", ".join(invalid),400,"invalid")
    # patient 使用自己的 patient_id；醫護代填時必須明確指定 patient_id。
    pid=session.get("patient_id") if session.get("role")=="patient" else str(data.get("patient_id","")).strip()
    if not pid or not load_resource("Patient",pid): return outcome("找不到目前病人資料",404,"not-found")
    try: resources=generate_samples_from_input(data)
    except ValueError as exc: return outcome(str(exc))
    # seed_demo 以 001 為範例模板；在儲存前將所有 Patient/001 與病人專屬資源 ID 轉為目前病人。
    patient_specific_types={"Patient","Person","Device","Encounter","QuestionnaireResponse","Observation","ClinicalImpression"}
    id_map={"Patient/001":f"Patient/{pid}","Person/person-patient-001":f"Person/person-{pid}"}
    for r in resources:
        rt=r.get("resourceType"); old_id=r.get("id","")
        if rt=="Patient":
            r["id"]=pid
        elif rt=="Person" and old_id=="person-patient-001":
            r["id"]=f"person-{pid}"[:64]
        elif rt in patient_specific_types and rt not in {"Patient","Person"}:
            # 避免不同病人共用 ppg001、mic001、hr001 等 id 而互相覆蓋。
            r["id"]=f"{old_id}-{pid}"[:64]
        if old_id and r.get("id")!=old_id: id_map[f"{rt}/{old_id}"]=f"{rt}/{r['id']}"
    def rewrite_refs(obj):
        if isinstance(obj,dict):
            for k,v in list(obj.items()):
                if k=="reference" and isinstance(v,str): obj[k]=id_map.get(v,v.replace("Patient/001",f"Patient/{pid}"))
                elif k=="questionnaire" and isinstance(v,str): obj[k]=id_map.get(v,v)
                else: rewrite_refs(v)
        elif isinstance(obj,list):
            for v in obj: rewrite_refs(v)
    for r in resources: rewrite_refs(r)
    # 使用註冊/匯入後的 Patient 主檔資料，避免評估表單覆寫身份資料。
    resources=[r for r in resources if r.get("resourceType")!="Patient"]
    # 評估歷史策略：同一病人在管理員設定的時間窗內重複儲存，視為刷新同一次評估；超過時間窗才建立新的歷史評估。
    try:
        refresh_minutes=max(1,min(1440,int(get_setting("assessment_refresh_window_minutes","5"))))
    except (TypeError,ValueError):
        refresh_minutes=5
    now_dt=datetime.now(TZ_TAIPEI)
    suffix=None
    with get_db() as conn:
        row=conn.execute("SELECT assessment_suffix,started_at,last_saved_at FROM assessment_sessions WHERE patient_id=?",(pid,)).fetchone()
        if row:
            try:
                last_dt=datetime.fromisoformat(str(row["last_saved_at"]))
                if last_dt.tzinfo is None: last_dt=last_dt.replace(tzinfo=TZ_TAIPEI)
                if now_dt-last_dt <= timedelta(minutes=refresh_minutes): suffix=str(row["assessment_suffix"])
            except Exception:
                suffix=None
        if not suffix:
            suffix=now_dt.strftime("%Y%m%d%H%M%S%f")[:17]
            conn.execute("INSERT INTO assessment_sessions(patient_id,assessment_suffix,started_at,last_saved_at) VALUES(?,?,?,?) "
                         "ON CONFLICT(patient_id) DO UPDATE SET assessment_suffix=excluded.assessment_suffix,started_at=excluded.started_at,last_saved_at=excluded.last_saved_at",
                         (pid,suffix,now_dt.replace(microsecond=0).isoformat(),now_dt.replace(microsecond=0).isoformat()))
        else:
            conn.execute("UPDATE assessment_sessions SET last_saved_at=? WHERE patient_id=?",(now_dt.replace(microsecond=0).isoformat(),pid))
    historical={"Encounter","QuestionnaireResponse","Observation","ClinicalImpression"}

    # 真正的 Assessment refresh：同一 assessment_id 在刷新視窗內再次儲存時，
    # 先移除上一版由「病人完整評估」產生的同 Assessment FHIR 資源，再寫入最新一組。
    # 這可避免同一 Assessment 內同時殘留舊 HR/SpO2/HRV/聲音/問卷等資料。
    # 醫護手動建立的專業註記目前不帶 assessment tag，因此不受此清理影響。
    with get_db() as conn:
        rows=conn.execute("SELECT resource_type,id,resource_json FROM resources WHERE patient_id=? AND resource_type IN ('Encounter','QuestionnaireResponse','Observation','ClinicalImpression')",(pid,)).fetchall()
        stale=[]
        for row in rows:
            try:
                existing=json.loads(row["resource_json"])
            except Exception:
                continue
            if assessment_id_from_resource(existing)==suffix:
                stale.append((row["resource_type"],row["id"]))
        for rt,rid in stale:
            conn.execute("DELETE FROM resources WHERE resource_type=? AND id=?",(rt,rid))

    # Every genuinely new Assessment receives a new suffix/local Resource id.
    # This is the boundary between "refresh the same assessment" and "create a new time-series history point".
    # Each clinical event also carries an explicit event time so HAPI can preserve longitudinal history.
    assessment_time=now_dt.replace(microsecond=0).isoformat()
    id_map={}
    for r in resources:
        if r["resourceType"] in historical:
            old_id=r["id"]; r["id"]=f"{old_id}-{suffix}"[:64]; id_map[f"{r['resourceType']}/{old_id}"]=f"{r['resourceType']}/{r['id']}"
    for r in resources:
        if r.get("resourceType") in historical:
            attach_assessment_tag(r,suffix)
            rt=r.get("resourceType")
            if rt=="Observation":
                r["effectiveDateTime"]=assessment_time
            elif rt=="QuestionnaireResponse":
                r["authored"]=assessment_time
            elif rt=="ClinicalImpression":
                r["date"]=assessment_time
            elif rt=="Encounter":
                period=dict(r.get("period") or {})
                period.setdefault("start",assessment_time)
                period.setdefault("end",assessment_time)
                r["period"]=period
        if isinstance(r.get("questionnaire"),str): r["questionnaire"]=id_map.get(r["questionnaire"],r["questionnaire"])
        for field in ("subject","patient","assessor"):
            ref=r.get(field);
            if isinstance(ref,dict) and ref.get("reference") in id_map: ref["reference"]=id_map[ref["reference"]]
        save_resource(r["resourceType"],validate_resource(r["resourceType"],r))
    # append odor QR and voice observations if supplied
    authored=assessment_time
    odor_items=[]
    try:
        from seed_demo import ODOR_QUESTIONS
    except Exception:
        ODOR_QUESTIONS=[]
    for i in range(1,6):
        key=f"odor{i}"; val=bool(data.get(key,False))
        text=ODOR_QUESTIONS[i-1] if i-1 < len(ODOR_QUESTIONS) else f"氣味自述 {i}"
        odor_items.append({"linkId":f"odor-{i}","text":text,"answer":[{"valueBoolean":val}]})
    odor_qr={"resourceType":"QuestionnaireResponse","id":f"odor-response-{suffix}","status":"completed","questionnaire":"Questionnaire/tcm-odor-q","subject":{"reference":f"Patient/{pid}"},"authored":authored,"item":odor_items}
    attach_assessment_tag(odor_qr,suffix)
    save_resource("QuestionnaireResponse",validate_resource("QuestionnaireResponse",odor_qr))
    voice_fields=[("voiceRmsDb",f"voice-rms-{suffix}","語音平均強度 dBFS","dBFS"),("voicePitchHz",f"voice-pitch-{suffix}","語音基本頻率估計","Hz"),("voiceDuration",f"voice-duration-{suffix}","錄音長度","s"),("breathRate",f"breath-rate-{suffix}","自述/輔助呼吸頻率","/min")]
    for key,rid,label,unit in voice_fields:
        if data.get(key) not in (None,""):
            try: val=float(data[key])
            except (TypeError,ValueError): continue
            obs={"resourceType":"Observation","id":rid,"status":"final","code":{"text":label},"subject":{"reference":f"Patient/{pid}"},"effectiveDateTime":authored,
                 "valueQuantity":({"value":round(val,2),"unit":unit,"code":unit} if unit=="dBFS" else {"value":round(val,2),"unit":unit,"system":"http://unitsofmeasure.org","code":unit}),"device":{"reference":f"Device/mic001-{pid}"[:64]},
                 "note":[{"text":"聞診聲音輔助特徵；瀏覽器估測值僅供競賽展示，不作疾病診斷。"}]}
            attach_assessment_tag(obs,suffix)
            save_resource("Observation",validate_resource("Observation",obs))
    audit("submit-assessment",f"Patient/{pid}",f"assessment={suffix}; refresh_window={refresh_minutes}min"); return jsonify({"ok":True,"message":"評估資料已儲存","resources":len(search_local("Observation",pid)),"assessment_id":suffix,"refresh_window_minutes":refresh_minutes})

@app.get("/assessments")
@roles_required("patient","clinician","admin")
def assessment_history():
    requested=str(request.args.get("patient_id") or "").strip()
    if session.get("role")=="patient":
        pid=str(session.get("patient_id") or "")
    else:
        pid=requested
    if not pid or not load_resource("Patient",pid): return outcome("找不到病人資料",404,"not-found")
    with get_db() as conn:
        rows=conn.execute("SELECT resource_json FROM resources WHERE patient_id=? ORDER BY effective_date DESC,updated_at DESC",(pid,)).fetchall()
        rec_rows=conn.execute("SELECT id,assessment_suffix,duration,created_at,updated_at,original_mime FROM voice_recordings WHERE patient_id=? ORDER BY COALESCE(updated_at,created_at) DESC,id DESC",(pid,)).fetchall()
        note_hist_rows=conn.execute("SELECT note_id,assessment_id,practitioner_id,practitioner_name,action,content,at FROM clinician_note_history WHERE patient_id=? ORDER BY at DESC,id DESC",(pid,)).fetchall()
    groups={}
    ungrouped=[]
    legacy_clinician_notes=[]
    for row in rows:
        r=json.loads(row[0]); aid=assessment_id_from_resource(r)
        if aid:
            groups.setdefault(aid,[]).append(r)
        elif r.get("resourceType")=="ClinicalImpression" and r.get("description")=="醫護人員評估註記":
            # 舊版醫護註記沒有 Assessment tag。先暫存，稍後歸入時間最接近的健康評估，
            # 避免「資料有存但歷史卡完全看不到」；不需要使用者重新輸入。
            legacy_clinician_notes.append(r)
        elif r.get("resourceType") not in {"Patient","Person","Device"}:
            ungrouped.append(r)

    # 將舊版未綁 Assessment 的醫護註記歸到最接近、且時間不晚於註記的評估。
    # 若無法判定，就歸到最新一次評估。這只影響歷史顯示，不會製造新的醫療資料。
    if legacy_clinician_notes and groups:
        def _group_time(aid, resources):
            vals=[resource_time_value(x) for x in resources if resource_time_value(x)]
            return max(vals) if vals else aid
        ordered_groups=sorted(((aid,_group_time(aid,rs)) for aid,rs in groups.items()), key=lambda x:x[1])
        for note in legacy_clinician_notes:
            nt=resource_time_value(note)
            candidates=[x for x in ordered_groups if not nt or x[1] <= nt]
            target=(candidates[-1] if candidates else ordered_groups[-1])[0]
            groups.setdefault(target,[]).append(note)
    else:
        ungrouped.extend(legacy_clinician_notes)
    recordings_by={}
    for rr in rec_rows:
        aid=str(rr["assessment_suffix"] or "").strip()
        item={"id":rr["id"],"assessment_id":aid or None,"duration":rr["duration"],"created_at":rr["created_at"],"updated_at":rr["updated_at"],"mime":rr["original_mime"],"url":f"/voice-recordings/{rr['id']}/audio"}
        if aid: recordings_by.setdefault(aid,[]).append(item)
    note_history_by={}
    for nh in note_hist_rows:
        aid=str(nh["assessment_id"] or "").strip()
        if not aid: continue
        note_history_by.setdefault(aid,[]).append({
            "note_id":nh["note_id"],"assessment_id":aid,"practitioner_id":nh["practitioner_id"],
            "practitioner_name":nh["practitioner_name"],"action":nh["action"],"content":nh["content"],"at":nh["at"]
        })
    assessments=[]
    for aid,resources in groups.items():
        summary=summarize_assessment_resources(resources,recordings_by.get(aid,[]))
        summary["clinician_note_history"]=note_history_by.get(aid,[])
        assessments.append({"assessment_id":aid,**summary})
    assessments.sort(key=lambda x:(x.get("time") or x.get("assessment_id") or ""),reverse=True)
    for i,a in enumerate(assessments):
        a["sequence"]=len(assessments)-i
    return jsonify({"patient_id":pid,"count":len(assessments),"assessments":assessments,"ungrouped_count":len(ungrouped)})

@app.get("/clinician/patients")
@roles_required("clinician","admin")
def clinician_patients():
    q=str(request.args.get("q","")).strip().lower()
    with get_db() as conn:
        accounts={r["patient_id"]:dict(r) for r in conn.execute("SELECT id,username,display_name,patient_id,active FROM users WHERE role='patient' AND patient_id IS NOT NULL").fetchall()}
    rows=[]
    for patient in search_local("Patient"):
        acc=accounts.get(patient.get("id"))
        national_id=patient_national_id(patient,acc)
        rows.append({
            "id":patient.get("id"),
            "name":fhir_human_name(patient, acc.get("display_name") if acc else "未命名病人"),
            "national_id":national_id,
            "fhir_pseudonym":fhir_pseudonym_for_patient(patient.get("id")),
            "gender":patient.get("gender","unknown"),
            "birthDate":patient.get("birthDate",""),
            "person_id":person_id_for_patient(patient.get("id")),
            "account":({"id":acc.get("id"),"username":acc.get("username"),"active":bool(acc.get("active"))} if acc else None)
        })
    if q:
        rows=[r for r in rows if q in " ".join(str(r.get(k) or "").lower() for k in ("id","name","national_id","birthDate"))]
    rows.sort(key=lambda x:(x["name"],x["id"]))
    return jsonify({"patients":rows,"query":q,"total":len(rows)})

@app.post("/clinician/patients")
@roles_required("clinician","admin")
def clinician_create_patient():
    """醫護/管理員手動建立病人；可選擇同時建立病人入口帳號。"""
    d=request.get_json(silent=True) or {}
    try:
        requested_pid=str(d.get("patient_id","")).strip() or None
        if requested_pid and not ID_RE.fullmatch(requested_pid):
            raise ValueError("patient FHIR id 格式不正確")
        patient,person=build_patient_identity(d,requested_pid)
        if load_resource("Patient",patient["id"]):
            return outcome("Patient id 已存在",409,"duplicate")
        if not load_resource("Organization","org001"):
            save_resource("Organization",{"resourceType":"Organization","id":"org001","active":True,"name":"TCM PPG FHIR Competition Demo Clinic"})
        save_resource("Patient",validate_resource("Patient",patient))
        save_resource("Person",validate_resource("Person",person))
        fhir_pseudonym_for_patient(patient["id"])
        username=str(d.get("username","")).strip()
        account_created=False
        initial_password=None
        if username:
            username=clean_national_id(username)
            set_patient_national_id(patient, username)
            save_resource("Patient",validate_resource("Patient",patient))
            initial_password=roc_birthday_password(patient.get("birthDate", ""))
            with get_db() as conn:
                if conn.execute("SELECT 1 FROM users WHERE username=?",(username,)).fetchone():
                    raise ValueError("此身分證字號已存在登入帳號")
                conn.execute("INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,active,must_change_password) VALUES(?,?,?,?,?,?,1,1)",
                             (username,generate_password_hash(initial_password),"patient",
                              d.get("display_name") or fhir_human_name(patient,"病人"),
                              person["id"],patient["id"]))
            account_created=True
        audit("clinician-create-patient",f"Patient/{patient['id']}",f"portal_account={account_created}; initial_password=ROC-birthday")
        resp=make_response(jsonify({"ok":True,"patient":patient,"person":person,"portal_account_created":account_created,
                        "initial_password":initial_password,"temporary_password_one_time":bool(initial_password)}),201)
        # 回應中的暫時密碼只供建立當下顯示，不寫入資料庫明文，也避免瀏覽器/代理快取。
        resp.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"
        resp.headers["Pragma"]="no-cache"
        return resp
    except ValueError as exc: return outcome(str(exc))
    except sqlite3.IntegrityError: return outcome("病人身分證字號已存在",409,"duplicate")

@app.post("/clinician/patients/import-hapi")
@roles_required("clinician","admin")
def clinician_import_hapi_patient():
    """醫護以本機病人身分證帳號查詢；系統自動處理 pseudonym 與遠端 HAPI Patient ID。"""
    import requests
    d=request.get_json(silent=True) or {}
    national_id=str(d.get("national_id","")).strip().upper()
    if not national_id:
        return outcome("請輸入病人身分證字號")
    with get_db() as conn:
        acc=conn.execute("SELECT username,display_name,patient_id,active FROM users WHERE role='patient' AND UPPER(username)=? AND active=1",(national_id,)).fetchone()
    if not acc or not acc["patient_id"]:
        return outcome("本機找不到此病人帳號，請先確認身分證字號或建立病人資料",404,"not-found")
    local_pid=str(acc["patient_id"])
    local_patient=load_resource("Patient",local_pid)
    if not local_patient:
        return outcome("此帳號尚未綁定有效 Patient 主檔",404,"not-found")
    pseudo=fhir_pseudonym_for_patient(local_pid)
    remote_id=None
    with get_db() as conn:
        row=conn.execute("SELECT last_remote_patient_id FROM fhir_identity_map WHERE patient_id=?",(local_pid,)).fetchone()
        if row and row[0]: remote_id=str(row[0])
    try:
        base=get_base_url().rstrip('/')
        remote=None
        if remote_id:
            r=requests.get(f"{base}/Patient/{remote_id}",headers={"Accept":"application/fhir+json"},timeout=12)
            if r.ok: remote=r.json()
            elif r.status_code==404: remote_id=None
            else: r.raise_for_status()
        if remote is None:
            r=requests.get(f"{base}/Patient",params={"identifier":f"{PSEUDONYM_SYSTEM}|{pseudo}"},headers={"Accept":"application/fhir+json"},timeout=12)
            r.raise_for_status(); result=r.json(); entries=result.get("entry") or []
            if entries:
                remote=(entries[0] or {}).get("resource") or {}
                remote_id=str(remote.get("id") or "") or None
                if remote_id: remember_remote_patient_id(local_pid,remote_id)
        if remote is None:
            audit("resolve-hapi-patient-miss",f"Patient/{local_pid}",f"pseudonym={pseudo}")
            return jsonify({"ok":True,"matched":False,"message":"本機病人已找到，但 HAPI 尚無對應 Patient；請先上傳此病人的 FHIR 資料。","patient":local_patient,"national_id":national_id,"pseudonym":pseudo})
        remote_pseudo=pseudonym_from_fhir_patient(remote)
        if remote_pseudo and remote_pseudo!=pseudo:
            return outcome("HAPI Patient 的假名識別碼與本機病人不一致",409,"conflict")
        audit("resolve-hapi-patient",f"Patient/{local_pid}",f"remote={remote_id}; pseudonym={pseudo}")
        return jsonify({"ok":True,"matched":True,"message":"已由本機病人自動對應到 HAPI 假名化 Patient","remote_patient_id":remote_id,"pseudonym":pseudo,"patient":local_patient,"national_id":national_id,"account":dict(acc),"remote_patient":remote})
    except requests.RequestException as exc:
        return outcome(f"HAPI 查詢失敗：{exc}",502,"exception")

def verify_current_clinician_password(password: str) -> bool:
    if not password: return False
    with get_db() as conn:
        row=conn.execute("SELECT password_hash FROM users WHERE username=? AND role='clinician' AND active=1",(session.get("username"),)).fetchone()
    return bool(row and check_password_hash(row["password_hash"],password))

def record_clinician_note_history(note_id:str, patient_id:str, assessment_id:str|None, action:str, content:str):
    practitioner_id=str(session.get("practitioner_id") or "")
    practitioner_name=str(session.get("display_name") or session.get("username") or practitioner_id or "醫護人員")
    with get_db() as conn:
        conn.execute(
            "INSERT INTO clinician_note_history(note_id,patient_id,assessment_id,practitioner_id,practitioner_name,action,content,at) VALUES(?,?,?,?,?,?,?,?)",
            (note_id,patient_id,assessment_id,practitioner_id,practitioner_name,action,content,now_iso())
        )

@app.post("/clinician/note/<patient_id>")
@roles_required("clinician")
def clinician_note(patient_id):
    if not load_resource("Patient",patient_id): return outcome("找不到病人",404,"not-found")
    text=str((request.get_json(silent=True) or {}).get("note","")).strip()
    if not text: return outcome("請輸入醫護註記")

    # 醫護專業註記屬於病人最近一次健康評估。若病人尚未完成任何 Assessment，
    # 不建立無歸屬註記，避免之後在歷史畫面中無法判定應顯示在哪一次評估。
    latest_aid=None
    latest_time=""
    with get_db() as conn:
        rows=conn.execute("SELECT resource_json FROM resources WHERE patient_id=? ORDER BY effective_date DESC,updated_at DESC",(patient_id,)).fetchall()
    for row in rows:
        try: r=json.loads(row[0])
        except Exception: continue
        aid=assessment_id_from_resource(r)
        if not aid: continue
        rt=resource_time_value(r) or aid
        if rt>=latest_time:
            latest_time=rt; latest_aid=aid
    if not latest_aid:
        return outcome("此病人尚未完成健康評估，請先建立至少一次健康評估後再新增醫護註記",409,"no-assessment")

    ci={"resourceType":"ClinicalImpression","id":f"clinician-note-{datetime.now().strftime('%Y%m%d%H%M%S')}","status":"completed","subject":{"reference":f"Patient/{patient_id}"},"date":now_iso(),"assessor":{"reference":f"Practitioner/{session.get('practitioner_id') or 'practitioner-001'}"},"description":"醫護人員評估註記","summary":text}
    attach_assessment_tag(ci,latest_aid)
    save_resource("ClinicalImpression",validate_resource("ClinicalImpression",ci))
    record_clinician_note_history(ci["id"],patient_id,latest_aid,"create",text)
    audit("clinician-note",f"Patient/{patient_id}",f"assessment={latest_aid}")
    return jsonify({**ci,"assessment_id":latest_aid})

@app.put("/clinician/note/<patient_id>/<note_id>")
@roles_required("clinician")
def clinician_update_note(patient_id,note_id):
    d=request.get_json(silent=True) or {}
    if not verify_current_clinician_password(str(d.get("password", ""))):
        return outcome("醫護帳號密碼驗證失敗，未執行修改",403,"forbidden")
    ci=load_resource("ClinicalImpression",note_id)
    if not ci or extract_patient_id("ClinicalImpression",ci)!=patient_id:
        return outcome("找不到指定醫護註記",404,"not-found")
    expected=f"Practitioner/{session.get('practitioner_id') or ''}"
    if ci.get("description")!="醫護人員評估註記" or (ci.get("assessor") or {}).get("reference")!=expected:
        return outcome("只能修改自己建立的醫護專業註記",403,"forbidden")
    text=str(d.get("note","")).strip()
    if not text: return outcome("註記內容不可空白")
    ci["summary"]=text; ci["date"]=now_iso()
    aid=assessment_id_from_resource(ci)
    save_resource("ClinicalImpression",validate_resource("ClinicalImpression",ci))
    record_clinician_note_history(note_id,patient_id,aid,"update",text)
    audit("clinician-note-update",f"ClinicalImpression/{note_id}",f"Patient/{patient_id}")
    return jsonify({"ok":True,"message":"醫護專業註記已修改；舊版本已保留於註記歷史","resource":ci})

@app.delete("/clinician/note/<patient_id>/<note_id>")
@roles_required("clinician")
def clinician_delete_note(patient_id,note_id):
    d=request.get_json(silent=True) or {}
    if not verify_current_clinician_password(str(d.get("password", ""))):
        return outcome("醫護帳號密碼驗證失敗，未執行刪除",403,"forbidden")
    ci=load_resource("ClinicalImpression",note_id)
    if not ci or extract_patient_id("ClinicalImpression",ci)!=patient_id:
        return outcome("找不到指定醫護註記",404,"not-found")
    expected=f"Practitioner/{session.get('practitioner_id') or ''}"
    if ci.get("description")!="醫護人員評估註記" or (ci.get("assessor") or {}).get("reference")!=expected:
        return outcome("只能刪除自己建立的醫護專業註記",403,"forbidden")
    aid=assessment_id_from_resource(ci)
    record_clinician_note_history(note_id,patient_id,aid,"delete",str(ci.get("summary") or ""))
    with get_db() as conn:
        conn.execute("DELETE FROM resources WHERE resource_type='ClinicalImpression' AND id=? AND patient_id=?",(note_id,patient_id))
    audit("clinician-note-delete",f"ClinicalImpression/{note_id}",f"Patient/{patient_id}")
    return jsonify({"ok":True,"message":"醫護專業註記已刪除；刪除前內容仍保留於註記歷史與 Audit log"})

@app.get("/admin/people")
@roles_required("admin")
def admin_people():
    """統一人員主檔：把登入帳號與 FHIR Patient/Person/Practitioner 視為同一組資料呈現。"""
    q=str(request.args.get("q","")).strip().lower()
    with get_db() as conn:
        users=[dict(r) for r in conn.execute("SELECT id,username,role,display_name,person_id,patient_id,practitioner_id,active,must_change_password FROM users ORDER BY id").fetchall()]
    by_patient={u.get("patient_id"):u for u in users if u.get("patient_id")}
    by_pract={u.get("practitioner_id"):u for u in users if u.get("practitioner_id")}
    records=[]; consumed=set()
    for patient in search_local("Patient"):
        pid=patient.get("id"); u=by_patient.get(pid); person_id=(u or {}).get("person_id") or person_id_for_patient(pid)
        rec={"record_type":"patient","role":"patient","name":fhir_human_name(patient,(u or {}).get("display_name") or "未命名病人"),
             "user_id":(u or {}).get("id"),"username":(u or {}).get("username"),"active":bool((u or {}).get("active")) if u else None,
             "account_status":(("需首次修改密碼" if u.get("must_change_password") else "已建立登入帳號") if u else "無登入帳號（病歷主檔保留）"),"must_change_password":bool((u or {}).get("must_change_password")) if u else None,"person_id":person_id,"patient_id":pid,"practitioner_id":None,
             "gender":patient.get("gender","unknown"),"birthDate":patient.get("birthDate",""),
             "fhir_pseudonym":fhir_pseudonym_for_patient(pid)}
        records.append(rec)
        if u: consumed.add(u["id"])
    for practitioner in search_local("Practitioner"):
        rid=practitioner.get("id"); u=by_pract.get(rid)
        rec={"record_type":"clinician","role":"clinician","name":fhir_human_name(practitioner,(u or {}).get("display_name") or "未命名醫護"),
             "user_id":(u or {}).get("id"),"username":(u or {}).get("username"),"active":bool((u or {}).get("active")) if u else None,
             "account_status":(("需首次修改密碼" if u.get("must_change_password") else "已建立登入帳號") if u else "無登入帳號（病歷主檔保留）"),"must_change_password":bool((u or {}).get("must_change_password")) if u else None,"person_id":(u or {}).get("person_id"),"patient_id":None,"practitioner_id":rid}
        records.append(rec)
        if u: consumed.add(u["id"])
    for u in users:
        if u["id"] in consumed: continue
        records.append({"record_type":"account","role":u.get("role"),"name":u.get("display_name"),"user_id":u.get("id"),"username":u.get("username"),
                        "active":bool(u.get("active")),"account_status":"需首次修改密碼" if u.get("must_change_password") else "已建立登入帳號","must_change_password":bool(u.get("must_change_password")),"person_id":u.get("person_id"),"patient_id":u.get("patient_id"),"practitioner_id":u.get("practitioner_id")})
    if q:
        def match(r):
            return q in " ".join(str(r.get(k) or "").lower() for k in ("username","name","role","patient_id","person_id","practitioner_id","account_status"))
        records=[r for r in records if match(r)]
    records.sort(key=lambda r:(r.get("role") or "",r.get("name") or "",r.get("patient_id") or r.get("practitioner_id") or ""))
    return jsonify({"people":records,"query":q,"total":len(records)})

@app.get("/admin/users")
@roles_required("admin")
def admin_users():
    q=str(request.args.get("q","")).strip()
    sql="SELECT id,username,role,display_name,person_id,patient_id,practitioner_id,active FROM users"
    params=[]
    if q:
        sql+=" WHERE username LIKE ? OR display_name LIKE ? OR role LIKE ?"
        like=f"%{q}%"; params=[like,like,like]
    sql+=" ORDER BY display_name COLLATE NOCASE, id"
    with get_db() as conn: rows=conn.execute(sql,params).fetchall()
    return jsonify({"users":[dict(r) for r in rows],"query":q,"total":len(rows)})

@app.post("/admin/users")
@roles_required("admin")
def admin_create_user():
    d=request.get_json(silent=True) or {}; role=d.get("role")
    if role not in {"patient","clinician","admin"}: return outcome("role 必須是 patient/clinician/admin")
    try:
        username=clean_national_id(d.get("username")) if role=="patient" else clean_username(d.get("username"))
        password=str(d.get("password", ""))
        if len(password)<6: raise ValueError("密碼至少 6 個字元")
        with get_db() as conn: conn.execute("INSERT INTO users(username,password_hash,role,display_name,person_id,patient_id,practitioner_id) VALUES(?,?,?,?,?,?,?)",
            (username,generate_password_hash(password),role,d.get("display_name") or username,d.get("person_id"),d.get("patient_id"),d.get("practitioner_id")))
    except ValueError as exc: return outcome(str(exc))
    except (KeyError,sqlite3.IntegrityError): return outcome("帳號資料不完整或帳號重複",409,"duplicate")
    audit("create-user",username); return jsonify({"ok":True}),201

@app.post("/admin/users/<int:user_id>/reset-password")
@roles_required("admin")
def admin_reset_user_password(user_id):
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    if not admin_password:
        return outcome("請輸入目前管理員密碼以確認重設",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，未執行重設",403,"forbidden")
        target=conn.execute("SELECT * FROM users WHERE id=? AND active=1",(user_id,)).fetchone()
        if not target:
            return outcome("找不到指定帳號",404,"not-found")
        if target["role"]!="patient" or not target["patient_id"]:
            return outcome("目前僅支援病人帳號以民國生日重設密碼",400,"invalid")
        patient=load_resource("Patient",target["patient_id"])
        birth_date=(patient or {}).get("birthDate","")
        try:
            temporary_password=roc_birthday_password(birth_date)
        except ValueError as exc:
            return outcome(str(exc),400,"invalid")
        conn.execute("UPDATE users SET password_hash=?, must_change_password=1 WHERE id=?",(generate_password_hash(temporary_password),user_id))
        info={"id":target["id"],"username":target["username"],"display_name":target["display_name"],"patient_id":target["patient_id"]}
    audit("reset-password",target["username"],json.dumps(info,ensure_ascii=False))
    resp=make_response(jsonify({"ok":True,"message":"密碼已重設為民國生日；病人下次登入後必須立即修改密碼",
                                "temporary_password":temporary_password,"temporary_password_one_time":True,"target":info}))
    # 暫時密碼僅在本次重設成功回應中出現；資料庫只保存 password_hash。
    resp.headers["Cache-Control"]="no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"]="no-cache"
    return resp

@app.delete("/admin/users/<int:user_id>")
@roles_required("admin")
def admin_delete_user(user_id):
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    if not admin_password: return outcome("請輸入目前管理員密碼以確認刪除",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，未執行刪除",403,"forbidden")
        target=conn.execute("SELECT * FROM users WHERE id=?",(user_id,)).fetchone()
        if not target: return outcome("找不到指定帳號",404,"not-found")
        if target["username"]==session.get("username"):
            return outcome("為避免目前工作階段失效，不能刪除正在登入的管理員帳號",409,"conflict")
        if target["role"]=="admin":
            admins=conn.execute("SELECT COUNT(*) FROM users WHERE role='admin' AND active=1").fetchone()[0]
            if admins<=1: return outcome("系統至少必須保留一個可用管理員帳號",409,"conflict")
        info={"id":target["id"],"username":target["username"],"display_name":target["display_name"],"role":target["role"],"patient_id":target["patient_id"],"practitioner_id":target["practitioner_id"]}
        conn.execute("DELETE FROM users WHERE id=?",(user_id,))
    audit("delete-user",target["username"],json.dumps(info,ensure_ascii=False))
    return jsonify({"ok":True,"message":"登入帳號已刪除。對應 FHIR／病歷主檔仍保留，可在「FHIR／病歷主檔」查看。","deleted":info})

@app.get("/admin/settings/national-id-validation")
@roles_required("admin")
def admin_get_national_id_validation():
    mode=get_setting("national_id_validation_mode","demo")
    return jsonify({"mode":mode,"strict":mode=="strict"})

@app.post("/admin/settings/national-id-validation")
@roles_required("admin")
def admin_set_national_id_validation():
    d=request.get_json(silent=True) or {}
    mode=str(d.get("mode","")).strip().lower()
    admin_password=str(d.get("admin_password", ""))
    if mode not in {"demo","strict"}:
        return outcome("驗證模式必須是 demo 或 strict")
    if not admin_password:
        return outcome("請輸入目前管理員密碼以確認變更",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，設定未變更",403,"forbidden")
    old=get_setting("national_id_validation_mode","demo")
    set_setting("national_id_validation_mode",mode)
    audit("change-national-id-validation","system-setting",json.dumps({"from":old,"to":mode},ensure_ascii=False))
    return jsonify({"ok":True,"mode":mode,"strict":mode=="strict",
                    "message":"身分證驗證已切換為正式檢核模式" if mode=="strict" else "身分證驗證已切換為 Demo／測試模式"})

@app.get("/admin/settings/assessment-refresh-window")
@roles_required("admin")
def admin_get_assessment_refresh_window():
    try: minutes=max(1,min(1440,int(get_setting("assessment_refresh_window_minutes","5"))))
    except (TypeError,ValueError): minutes=5
    return jsonify({"minutes":minutes})

@app.post("/admin/settings/assessment-refresh-window")
@roles_required("admin")
def admin_set_assessment_refresh_window():
    d=request.get_json(silent=True) or {}
    admin_password=str(d.get("admin_password", ""))
    try: minutes=int(d.get("minutes",5))
    except (TypeError,ValueError): return outcome("刷新時間必須是整數分鐘")
    if minutes < 1 or minutes > 1440: return outcome("刷新時間需介於 1～1440 分鐘")
    if not admin_password: return outcome("請輸入目前管理員密碼以確認變更",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password):
            return outcome("管理員密碼驗證失敗，設定未變更",403,"forbidden")
    old=get_setting("assessment_refresh_window_minutes","5")
    set_setting("assessment_refresh_window_minutes",str(minutes))
    audit("change-assessment-refresh-window","system-setting",json.dumps({"from":old,"to":minutes},ensure_ascii=False))
    return jsonify({"ok":True,"minutes":minutes,"message":f"短時間重複評估刷新視窗已設為 {minutes} 分鐘"})

@app.get("/admin/settings/booking-base-interval")
@roles_required("admin")
def admin_get_booking_base_interval():
    return jsonify({"minutes":_booking_base_interval_minutes()})

@app.post("/admin/settings/booking-base-interval")
@roles_required("admin")
def admin_set_booking_base_interval():
    d=request.get_json(silent=True) or {}
    try: minutes=int(d.get("minutes"))
    except Exception: return outcome("請輸入正確的基礎排程單位")
    if minutes<5 or minutes>60 or minutes%5!=0:
        return outcome("基礎排程單位需為 5～60 分鐘，且為 5 分鐘的倍數")
    admin_password=str(d.get("admin_password") or "")
    if not admin_password: return outcome("請輸入目前管理員密碼",400,"reauth-required")
    with get_db() as conn:
        row=conn.execute("SELECT password_hash FROM users WHERE id=? AND role='admin' AND active=1",(session.get("user_id"),)).fetchone()
    if not row or not check_password_hash(row["password_hash"],admin_password):
        return outcome("管理員密碼錯誤",403,"reauth-failed")
    old=_booking_base_interval_minutes()
    set_setting("booking_base_interval_minutes",str(minutes))
    audit("change-booking-base-interval","system-setting",json.dumps({"from":old,"to":minutes},ensure_ascii=False))
    return jsonify({"ok":True,"minutes":minutes,"message":f"系統基礎排程單位已更新為 {minutes} 分鐘；新建立排班將使用此設定，既有排班不會重新切分。"})

@app.get("/admin/settings/fhir-auto-sync")
@roles_required("admin")
def admin_get_fhir_auto_sync():
    try: minutes=max(5,min(1440,int(get_setting("fhir_auto_sync_interval_minutes","60"))))
    except (TypeError,ValueError): minutes=60
    return jsonify({"enabled":get_setting("fhir_auto_sync_enabled","1")=="1","minutes":minutes,
                    "last_attempt":get_setting("fhir_auto_sync_last_attempt",""),
                    "last_success":get_setting("fhir_auto_sync_last_success",""),
                    "last_error":get_setting("fhir_auto_sync_last_error","")})

@app.post("/admin/settings/fhir-auto-sync")
@roles_required("admin")
def admin_set_fhir_auto_sync():
    d=request.get_json(silent=True) or {}; admin_password=str(d.get("admin_password","")); enabled=bool(d.get("enabled",True))
    try: minutes=int(d.get("minutes",60))
    except (TypeError,ValueError): return outcome("自動同步間隔必須是整數分鐘")
    if minutes<5 or minutes>1440: return outcome("自動同步間隔需介於 5～1440 分鐘")
    if not admin_password: return outcome("請輸入目前管理員密碼以確認變更",400,"required")
    with get_db() as conn:
        admin=conn.execute("SELECT * FROM users WHERE username=? AND role='admin' AND active=1",(session.get("username"),)).fetchone()
        if not admin or not check_password_hash(admin["password_hash"],admin_password): return outcome("管理員密碼驗證失敗，設定未變更",403,"forbidden")
    old={"enabled":get_setting("fhir_auto_sync_enabled","1"),"minutes":get_setting("fhir_auto_sync_interval_minutes","60")}
    set_setting("fhir_auto_sync_enabled","1" if enabled else "0"); set_setting("fhir_auto_sync_interval_minutes",str(minutes))
    audit("change-fhir-auto-sync","system-setting",json.dumps({"from":old,"to":{"enabled":enabled,"minutes":minutes}},ensure_ascii=False))
    return jsonify({"ok":True,"enabled":enabled,"minutes":minutes,"message":f"FHIR 自動同步已{'啟用' if enabled else '停用'}；啟用時每 {minutes} 分鐘嘗試同步一次。"})

@app.post("/admin/fhir-auto-sync/run-now")
@roles_required("admin")
def admin_run_fhir_auto_sync_now():
    try: return jsonify({"ok":True,"message":"已完成一次後端 FHIR 同步嘗試。","result":auto_sync_once()})
    except Exception as exc: return outcome(str(exc),502,"exception")

@app.get("/admin/audit")
@roles_required("admin")
def admin_audit():
    with get_db() as conn: rows=conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify({"audit":[dict(r) for r in rows]})

def parse_local_iso(value:str)->datetime:
    try:
        dt=datetime.fromisoformat(str(value).replace("Z","+00:00"))
    except Exception:
        raise ValueError("時間格式不正確")
    if dt.tzinfo is None: dt=dt.replace(tzinfo=TZ_TAIPEI)
    return dt.astimezone(TZ_TAIPEI)

CANCELLATION_WINDOW_MINUTES=10

def _booking_base_interval_minutes():
    try:
        value=int(get_setting("booking_base_interval_minutes","5"))
    except Exception:
        value=5
    # 以 5 分鐘為最小粒度，避免過細造成排班資料膨脹。
    value=max(5,min(60,value))
    return value - (value % 5) if value % 5 else value

def _local_cancel_window(created_at):
    if not created_at:
        return {"can_cancel":False,"created_at":None,"cancel_until":None,"remaining_seconds":0}
    try: created=parse_local_iso(created_at)
    except Exception: return {"can_cancel":False,"created_at":created_at,"cancel_until":None,"remaining_seconds":0}
    until=created+timedelta(minutes=CANCELLATION_WINDOW_MINUTES)
    remaining=max(0,int((until-datetime.now(TZ_TAIPEI)).total_seconds()))
    return {"can_cancel":remaining>0,"created_at":created.isoformat(),"cancel_until":until.isoformat(),"remaining_seconds":remaining}

def _consultation_duration(patient_id:str,practitioner_id:str,default:int=30)->dict:
    with get_db() as conn:
        row=conn.execute("SELECT estimated_duration_minutes,last_actual_duration_minutes,updated_at FROM consultation_duration_preferences WHERE patient_id=? AND practitioner_id=?",(patient_id,practitioner_id)).fetchone()
    if not row:
        return {"estimated_duration_minutes":int(default),"last_actual_duration_minutes":None,"custom":False,"updated_at":None}
    return {"estimated_duration_minutes":int(row["estimated_duration_minutes"]),"last_actual_duration_minutes":row["last_actual_duration_minutes"],"custom":True,"updated_at":row["updated_at"]}

def _patient_display_name(patient_id):
    patient=load_resource("Patient",patient_id)
    with get_db() as conn:
        acc=conn.execute("SELECT display_name FROM users WHERE role='patient' AND patient_id=? ORDER BY id DESC LIMIT 1",(patient_id,)).fetchone()
    fallback=acc["display_name"] if acc else "病人"
    return fhir_human_name(patient,fallback) if patient else fallback

def _merge_time_ranges(rows):
    vals=[]
    for r in rows:
        try: vals.append([parse_local_iso(r["start"]),parse_local_iso(r["end"])])
        except Exception: pass
    vals.sort(key=lambda x:x[0]); out=[]
    for st,en in vals:
        if out and st<=out[-1][1]: out[-1][1]=max(out[-1][1],en)
        else: out.append([st,en])
    return [{"start":a.isoformat(),"end":b.isoformat()} for a,b in out]

@app.get("/appointments/doctors")
@roles_required("patient")
def appointment_doctors():
    with get_db() as conn:
        rows=conn.execute("SELECT display_name,practitioner_id FROM users WHERE role='clinician' AND active=1 AND practitioner_id IS NOT NULL ORDER BY display_name").fetchall()
    return jsonify({"doctors":[{"name":r["display_name"],"practitioner_id":r["practitioner_id"]} for r in rows if load_resource("Practitioner",r["practitioner_id"])]})

@app.get("/appointments/availability")
@roles_required("patient")
def appointment_availability():
    practitioner_id=str(request.args.get("practitioner_id") or "").strip(); patient_id=session.get("patient_id")
    if not practitioner_id: return jsonify({"slots":[]})
    now=datetime.now(TZ_TAIPEI)
    with get_db() as conn:
        rows=conn.execute("""SELECT s.*,a.default_duration_minutes,a.interval_minutes FROM booking_slots s
                             JOIN booking_availability a ON a.id=s.availability_id
                             WHERE s.practitioner_id=? AND a.active=1 ORDER BY s.start_at,s.end_at""",(practitioner_id,)).fetchall()
    # 同一開始時間若因不同排班群組重疊，只保留一個；任一筆已占用則該開始時間不可使用。
    by_start={}
    for r in rows:
        try: st=parse_local_iso(r["start_at"]); en=parse_local_iso(r["end_at"])
        except Exception: continue
        key=st.isoformat(); item={**dict(r),"_st":st,"_en":en}
        old=by_start.get(key)
        if old is None or (old["status"]=="free" and item["status"]!="free"): by_start[key]=item
    entries=sorted(by_start.values(),key=lambda x:x["_st"]); results=[]
    for i,item in enumerate(entries):
        st,en=item["_st"],item["_en"]
        if st<now or item["status"]!="free": continue
        default_duration=int(item["default_duration_minutes"] or 30)
        pref=_consultation_duration(patient_id,practitioner_id,default_duration)
        wanted=max(10,min(240,int(pref["estimated_duration_minutes"])))
        desired_end=st+timedelta(minutes=wanted); cursor=st; chosen=[]
        for cand in entries[i:]:
            if cursor>=desired_end: break
            if cand["_st"]!=cursor or cand["status"]!="free": break
            chosen.append(cand); cursor=cand["_en"]
        if cursor<desired_end: continue
        results.append({"id":item["id"],"start":st.isoformat(),"end":cursor.isoformat(),"estimated_end":desired_end.isoformat(),
                        "duration_minutes":wanted,"occupied_minutes":int((cursor-st).total_seconds()/60),"required_slot_count":len(chosen),
                        "interval_minutes":int(item["interval_minutes"] or _booking_base_interval_minutes()),"custom_duration":bool(pref["custom"])})
    return jsonify({"slots":results})

@app.get("/clinician/availability")
@roles_required("clinician")
def clinician_availability():
    practitioner_id=session.get("practitioner_id")
    with get_db() as conn:
        avrows=conn.execute("SELECT * FROM booking_availability WHERE practitioner_id=? AND active=1 ORDER BY start_at",(practitioner_id,)).fetchall()
        slotrows=conn.execute("SELECT * FROM booking_slots WHERE practitioner_id=? ORDER BY start_at,end_at",(practitioner_id,)).fetchall()
        bookrows=conn.execute("SELECT * FROM bookings WHERE practitioner_id=? AND status IN ('booked','in-progress','fulfilled') ORDER BY start_at",(practitioner_id,)).fetchall()
    schedules=[]
    for r in avrows:
        cw=_local_cancel_window(r["created_at"])
        busy=sum(1 for x in slotrows if x["availability_id"]==r["id"] and x["status"]!="free")
        schedules.append({"id":r["id"],"start":r["start_at"],"end":r["end_at"],"interval_minutes":r["interval_minutes"],
                          "default_duration_minutes":r["default_duration_minutes"],"slot_count":sum(1 for x in slotrows if x["availability_id"]==r["id"]),
                          "busy_count":busy,"can_delete":bool(cw["can_cancel"] and busy==0),"delete_blocked_by_booking":busy>0,**cw})
    slots=[{"id":r["id"],"schedule_id":r["availability_id"],"status":r["status"],"start":r["start_at"],"end":r["end_at"]} for r in slotrows]
    appointments=[]
    for r in bookrows:
        appointments.append({"id":r["id"],"patient_id":r["patient_id"],"patient_name":_patient_display_name(r["patient_id"]),
                             "start":r["start_at"],"end":r["end_at"],"duration_minutes":r["estimated_duration_minutes"],"status":r["status"],
                             "actual_start":r["actual_start_at"],"actual_end":r["actual_end_at"],"actual_duration_minutes":r["actual_duration_minutes"]})
    days={}
    for x in slots:
        try: st=parse_local_iso(x["start"]); en=parse_local_iso(x["end"])
        except Exception: continue
        key=st.date().isoformat(); d=days.setdefault(key,{"date":key,"ranges":[],"free_slots":[],"appointments":[],"schedules":[]})
        # unavailable/deactivated slots are not part of active visible range
        if x["status"]!="unavailable": d["ranges"].append({"start":st.isoformat(),"end":en.isoformat()})
        if x["status"]=="free": d["free_slots"].append({"start":st.isoformat(),"end":en.isoformat()})
    for ap in appointments:
        try: key=parse_local_iso(ap["start"]).date().isoformat()
        except Exception: continue
        days.setdefault(key,{"date":key,"ranges":[],"free_slots":[],"appointments":[],"schedules":[]})["appointments"].append(ap)
    for sc in schedules:
        try: key=parse_local_iso(sc["start"]).date().isoformat()
        except Exception: continue
        days.setdefault(key,{"date":key,"ranges":[],"free_slots":[],"appointments":[],"schedules":[]})["schedules"].append(sc)
    result=[]
    for key,d in sorted(days.items()):
        events=[{"type":"free",**r} for r in _merge_time_ranges(d["free_slots"])] + [{"type":"appointment",**ap} for ap in d["appointments"]]
        events.sort(key=lambda x:str(x.get("start") or ""))
        try: dt=datetime.fromisoformat(key); label=f"{dt.year}/{dt.month:02d}/{dt.day:02d}"
        except Exception: label=key
        result.append({"date":key,"label":label,"ranges":_merge_time_ranges(d["ranges"]),"events":events,"appointment_count":len(d["appointments"]),"schedules":d["schedules"]})
    return jsonify({"days":result,"slots":slots,"schedules":schedules,"appointments":appointments,"cancellation_window_minutes":CANCELLATION_WINDOW_MINUTES,"current_base_interval_minutes":_booking_base_interval_minutes()})

@app.post("/clinician/availability")
@roles_required("clinician")
def clinician_create_availability():
    d=request.get_json(silent=True) or {}; practitioner_id=session.get("practitioner_id")
    if not practitioner_id or not load_resource("Practitioner",practitioner_id): return outcome("醫護帳號尚未綁定 Practitioner",400)
    dates=d.get("dates") or []; start_time=str(d.get("start_time") or "").strip(); end_time=str(d.get("end_time") or "").strip(); confirm_merge=bool(d.get("confirm_merge"))
    interval=_booking_base_interval_minutes()
    try: default_duration=int(d.get("default_duration_minutes") or 30)
    except Exception: return outcome("看診時長格式不正確")
    if default_duration<10 or default_duration>240: return outcome("預設看診時長需介於 10～240 分鐘")
    if not isinstance(dates,list) or not dates: return outcome("請至少選擇一個日期")
    if len(dates)>90: return outcome("一次最多建立 90 個日期")
    targets=[]
    for ds in sorted(set(str(x) for x in dates if x)):
        try: st=parse_local_iso(f"{ds}T{start_time}"); en=parse_local_iso(f"{ds}T{end_time}")
        except Exception: return outcome(f"日期或時間格式不正確：{ds}")
        if en<=st: return outcome("結束時間必須晚於開始時間")
        targets.append((ds,st,en))
    with get_db() as conn:
        existing=conn.execute("SELECT * FROM booking_availability WHERE practitioner_id=? AND active=1 ORDER BY start_at",(practitioner_id,)).fetchall()
    overlaps=[]
    for ds,st,en in targets:
        hits=[]
        for r in existing:
            try: a=parse_local_iso(r["start_at"]); b=parse_local_iso(r["end_at"])
            except Exception: continue
            if a.date()!=st.date(): continue
            if st < b and en > a: hits.append((a,b))
        if hits:
            union_start=min([st]+[x[0] for x in hits]); union_end=max([en]+[x[1] for x in hits])
            overlaps.append(f"{ds}：既有 {', '.join(x[0].strftime('%H:%M')+'～'+x[1].strftime('%H:%M') for x in hits)}；新增 {st.strftime('%H:%M')}～{en.strftime('%H:%M')}；確認後視為 {union_start.strftime('%H:%M')}～{union_end.strftime('%H:%M')}")
    if overlaps and not confirm_merge:
        return outcome("時間交集確認：\n"+"\n".join(overlaps),409,"overlap-confirmation")
    created_total=0; created_dates=0; merged_dates=[]; created_ids=[]; stamp=now_iso()
    with get_db() as conn:
        for ds,st,en in targets:
            if any(x.startswith(ds+'：') for x in overlaps): merged_dates.append(ds)
            aid=f"availability-{uuid.uuid4().hex[:16]}"; created_ids.append(aid)
            conn.execute("INSERT INTO booking_availability(id,practitioner_id,start_at,end_at,interval_minutes,default_duration_minutes,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                         (aid,practitioner_id,st.isoformat(),en.isoformat(),interval,default_duration,1,stamp,stamp))
            cur=st; count=0
            while cur+timedelta(minutes=interval)<=en and count<500:
                slot_end=cur+timedelta(minutes=interval)
                # 若此精確時間格已存在，直接沿用舊格，不建立第二套重複可預約入口。
                dupe=conn.execute("SELECT id FROM booking_slots WHERE practitioner_id=? AND start_at=? AND end_at=? AND status!='unavailable' LIMIT 1",(practitioner_id,cur.isoformat(),slot_end.isoformat())).fetchone()
                if not dupe:
                    sid=f"slot-{uuid.uuid4().hex[:16]}"
                    conn.execute("INSERT INTO booking_slots(id,availability_id,practitioner_id,start_at,end_at,status,booking_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                                 (sid,aid,practitioner_id,cur.isoformat(),slot_end.isoformat(),'free',None,stamp,stamp)); created_total+=1
                cur=slot_end; count+=1
            created_dates+=1
    audit("create-availability",','.join(created_ids),json.dumps({"dates":[x[0] for x in targets],"start_time":start_time,"end_time":end_time,"interval_minutes":interval,"default_duration_minutes":default_duration,"merged_dates":merged_dates},ensure_ascii=False))
    return jsonify({"ok":True,"schedule_ids":created_ids,"count":created_total,"created_dates":created_dates,"merged_dates":merged_dates,"interval_minutes":interval,
                    "message":f"已建立 {created_dates} 個日期的本機排班。"}),201

@app.delete("/clinician/availability/<availability_id>")
@roles_required("clinician")
def clinician_delete_availability(availability_id):
    practitioner_id=session.get("practitioner_id")
    with get_db() as conn:
        row=conn.execute("SELECT * FROM booking_availability WHERE id=?",(availability_id,)).fetchone()
        if not row: return outcome("找不到此排班",404,"not-found")
        if row["practitioner_id"]!=practitioner_id: return outcome("只能刪除自己建立的排班",403,"forbidden")
        cw=_local_cancel_window(row["created_at"])
        if not cw["can_cancel"]: return outcome(f"此排班建立已超過 {CANCELLATION_WINDOW_MINUTES} 分鐘，為避免濫用已無法自行刪除",409,"cancellation-window-expired")
        busy=conn.execute("SELECT COUNT(*) FROM booking_slots WHERE availability_id=? AND status='busy'",(availability_id,)).fetchone()[0]
        if busy: return outcome("此排班已有病人預約，不能直接刪除整段排班；請處理個別預約",409,"has-booking")
        stamp=now_iso(); conn.execute("UPDATE booking_availability SET active=0,updated_at=? WHERE id=?",(stamp,availability_id))
        conn.execute("UPDATE booking_slots SET status='unavailable',updated_at=? WHERE availability_id=? AND status='free'",(stamp,availability_id))
    audit("cancel-availability",availability_id,json.dumps({"rule_minutes":CANCELLATION_WINDOW_MINUTES},ensure_ascii=False))
    return jsonify({"ok":True,"id":availability_id,"status":"cancelled","message":"排班已取消；此資料僅屬本機排班系統。"})

@app.get("/clinician/patient-duration/<patient_id>")
@roles_required("clinician")
def clinician_get_patient_duration(patient_id):
    if not load_resource("Patient",patient_id): return outcome("找不到病人",404,"not-found")
    practitioner_id=session.get("practitioner_id"); pref=_consultation_duration(patient_id,practitioner_id,30)
    return jsonify({"patient_id":patient_id,"practitioner_id":practitioner_id,**pref})

@app.put("/clinician/patient-duration/<patient_id>")
@roles_required("clinician")
def clinician_set_patient_duration(patient_id):
    if not load_resource("Patient",patient_id): return outcome("找不到病人",404,"not-found")
    practitioner_id=session.get("practitioner_id"); d=request.get_json(silent=True) or {}
    try:
        estimated=int(d.get("estimated_duration_minutes")); raw=d.get("last_actual_duration_minutes"); actual=None if raw in (None,"") else int(raw)
    except Exception: return outcome("看診時長必須為整數分鐘")
    if estimated<10 or estimated>240: return outcome("建議預約時長需介於 10～240 分鐘")
    if actual is not None and (actual<1 or actual>480): return outcome("最近實際看診時間需介於 1～480 分鐘")
    stamp=now_iso()
    with get_db() as conn:
        conn.execute("INSERT INTO consultation_duration_preferences(patient_id,practitioner_id,estimated_duration_minutes,last_actual_duration_minutes,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(patient_id,practitioner_id) DO UPDATE SET estimated_duration_minutes=excluded.estimated_duration_minutes,last_actual_duration_minutes=excluded.last_actual_duration_minutes,updated_at=excluded.updated_at",(patient_id,practitioner_id,estimated,actual,stamp))
    audit("update-patient-consultation-duration",patient_id,json.dumps({"practitioner_id":practitioner_id,"estimated_duration_minutes":estimated,"last_actual_duration_minutes":actual},ensure_ascii=False))
    return jsonify({"ok":True,"patient_id":patient_id,"practitioner_id":practitioner_id,"estimated_duration_minutes":estimated,"last_actual_duration_minutes":actual,"updated_at":stamp})

@app.post("/appointment")
@roles_required("patient")
def create_appointment():
    d=request.get_json(silent=True) or {}; pid=session.get("patient_id"); slot_id=str(d.get("slot_id") or "").strip()
    if not load_resource("Patient",pid): return outcome("找不到病人",404,"not-found")
    if not slot_id: return outcome("請先選擇可預約開始時間")
    with get_db() as conn:
        conn.execute("BEGIN IMMEDIATE")
        first=conn.execute("""SELECT s.*,a.default_duration_minutes,a.interval_minutes,a.active FROM booking_slots s
                              JOIN booking_availability a ON a.id=s.availability_id WHERE s.id=?""",(slot_id,)).fetchone()
        if not first or not first["active"]: return outcome("此預約時段不存在或已失效",404,"not-found")
        if first["status"]!="free": return outcome("此時段已被其他病人預約，請重新選擇",409,"conflict")
        practitioner_id=first["practitioner_id"]
        pref=_consultation_duration(pid,practitioner_id,int(first["default_duration_minutes"] or 30)); wanted=max(10,min(240,int(pref["estimated_duration_minutes"])))
        start_dt=parse_local_iso(first["start_at"]); desired_end=start_dt+timedelta(minutes=wanted); cursor=start_dt; chosen=[]
        rows=conn.execute("""SELECT s.* FROM booking_slots s JOIN booking_availability a ON a.id=s.availability_id
                             WHERE s.practitioner_id=? AND a.active=1 ORDER BY s.start_at,s.end_at""",(practitioner_id,)).fetchall()
        by_start={}
        for r in rows:
            try: st=parse_local_iso(r["start_at"]); en=parse_local_iso(r["end_at"])
            except Exception: continue
            key=st.isoformat(); item=(st,en,r)
            old=by_start.get(key)
            if old is None or (old[2]["status"]=="free" and r["status"]!="free"): by_start[key]=item
        for st,en,r in sorted(by_start.values(),key=lambda x:x[0]):
            if st<start_dt: continue
            if cursor>=desired_end: break
            if st!=cursor or r["status"]!="free": break
            chosen.append((r["id"],st,en)); cursor=en
        if cursor<desired_end: return outcome("此開始時間後方已沒有足夠的連續空檔，可能剛被其他病人預約，請重新選擇",409,"conflict")
        rid=f"booking-{uuid.uuid4().hex[:16]}"; stamp=now_iso()
        conn.execute("INSERT INTO bookings(id,patient_id,practitioner_id,start_at,end_at,estimated_duration_minutes,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
                     (rid,pid,practitioner_id,start_dt.isoformat(),desired_end.isoformat(),wanted,'booked',stamp,stamp))
        for sid,_,_ in chosen:
            cur=conn.execute("UPDATE booking_slots SET status='busy',booking_id=?,updated_at=? WHERE id=? AND status='free'",(rid,stamp,sid))
            if cur.rowcount!=1: raise RuntimeError("預約時段已被其他病人占用")
            conn.execute("INSERT OR IGNORE INTO booking_slot_links(booking_id,slot_id) VALUES(?,?)",(rid,sid))
    audit("appointment",rid,json.dumps({"slot_ids":[x[0] for x in chosen],"practitioner_id":practitioner_id,"estimated_duration_minutes":wanted},ensure_ascii=False))
    return jsonify({"id":rid,"status":"booked","start":start_dt.isoformat(),"end":desired_end.isoformat(),"estimated_duration_minutes":wanted}),201

@app.get("/appointments/mine")
@roles_required("patient")
def my_appointments():
    pid=session.get("patient_id")
    with get_db() as conn:
        rows=conn.execute("SELECT * FROM bookings WHERE patient_id=?",(pid,)).fetchall()
        practitioner_names={r["practitioner_id"]:r["display_name"] for r in conn.execute("SELECT practitioner_id,display_name FROM users WHERE practitioner_id IS NOT NULL").fetchall()}
    items=[]
    now_dt=datetime.now(TZ_TAIPEI)
    for r in rows:
        cw=_local_cancel_window(r["created_at"])
        items.append({"id":r["id"],"status":r["status"],"start":r["start_at"],"end":r["end_at"],"estimated_duration_minutes":r["estimated_duration_minutes"],
                      "actual_start":r["actual_start_at"],"actual_end":r["actual_end_at"],"actual_duration_minutes":r["actual_duration_minutes"],
                      "practitioner_id":r["practitioner_id"],"practitioner_name":practitioner_names.get(r["practitioner_id"]) or "醫護人員",**cw,"cancellation_window_minutes":CANCELLATION_WINDOW_MINUTES})
    def _sort_booking(x):
        try: start=parse_local_iso(x.get("start"))
        except Exception: start=now_dt
        upcoming=x.get("status")=="booked" and start>=now_dt
        return (0 if upcoming else 1, start.timestamp() if upcoming else -start.timestamp())
    items.sort(key=_sort_booking)
    return jsonify({"appointments":items,"cancellation_window_minutes":CANCELLATION_WINDOW_MINUTES})

@app.get("/appointments/patient/<patient_id>")
@roles_required("clinician")
def clinician_patient_appointments(patient_id):
    practitioner_id=session.get("practitioner_id")
    with get_db() as conn: rows=conn.execute("SELECT * FROM bookings WHERE patient_id=? AND practitioner_id=? ORDER BY start_at DESC",(patient_id,practitioner_id)).fetchall()
    items=[]
    for r in rows:
        cw=_local_cancel_window(r["created_at"])
        items.append({"id":r["id"],"status":r["status"],"start":r["start_at"],"end":r["end_at"],"estimated_duration_minutes":r["estimated_duration_minutes"],
                      "actual_start":r["actual_start_at"],"actual_end":r["actual_end_at"],"actual_duration_minutes":r["actual_duration_minutes"],**cw})
    return jsonify({"appointments":items})

def _ceil_to_booking_grid(dt:datetime, interval_minutes:int)->datetime:
    """Round a local datetime upward to the next booking-grid boundary."""
    interval=max(1,int(interval_minutes or 5))
    base=dt.replace(second=0,microsecond=0)
    minute_of_day=base.hour*60+base.minute
    rem=minute_of_day % interval
    if rem or dt.second or dt.microsecond:
        add=(interval-rem) if rem else interval
        base=base+timedelta(minutes=add)
    return base

@app.post("/appointment/<appointment_id>/start")
@roles_required("clinician")
def start_appointment(appointment_id):
    practitioner_id=session.get("practitioner_id")
    with get_db() as conn:
        row=conn.execute("SELECT * FROM bookings WHERE id=?",(appointment_id,)).fetchone()
        if not row: return outcome("找不到此預約",404,"not-found")
        if row["practitioner_id"]!=practitioner_id: return outcome("只能操作自己負責的預約",403,"forbidden")
        if row["status"]=="fulfilled": return outcome("此預約已完成",409,"already-completed")
        if row["status"]=="cancelled": return outcome("此預約已取消",409,"cancelled")
        if row["status"]=="in-progress":
            return jsonify({"ok":True,"id":appointment_id,"status":"in-progress","actual_start":row["actual_start_at"],"message":"此病人已在看診中。"})
        stamp=now_iso()
        conn.execute("UPDATE bookings SET status='in-progress',actual_start_at=COALESCE(actual_start_at,?),updated_at=? WHERE id=?",(stamp,stamp,appointment_id))
    audit("start-consultation",appointment_id,json.dumps({"practitioner_id":practitioner_id},ensure_ascii=False))
    return jsonify({"ok":True,"id":appointment_id,"status":"in-progress","actual_start":stamp,"message":"已記錄開始看診時間。"})

@app.post("/appointment/<appointment_id>/complete")
@roles_required("clinician")
def complete_appointment(appointment_id):
    practitioner_id=session.get("practitioner_id")
    now_dt=datetime.now(TZ_TAIPEI); stamp=now_dt.isoformat()
    released=[]
    with get_db() as conn:
        row=conn.execute("SELECT * FROM bookings WHERE id=?",(appointment_id,)).fetchone()
        if not row: return outcome("找不到此預約",404,"not-found")
        if row["practitioner_id"]!=practitioner_id: return outcome("只能操作自己負責的預約",403,"forbidden")
        if row["status"]=="cancelled": return outcome("此預約已取消",409,"cancelled")
        if row["status"]=="fulfilled": return outcome("此預約已完成",409,"already-completed")
        scheduled_start=parse_local_iso(row["start_at"]); scheduled_end=parse_local_iso(row["end_at"])
        actual_start=parse_local_iso(row["actual_start_at"]) if row["actual_start_at"] else min(now_dt,scheduled_start)
        if actual_start>now_dt: actual_start=now_dt
        actual_minutes=max(0,int((now_dt-actual_start).total_seconds()//60))
        # Store at least one minute for a started/finished consultation so the history is useful.
        if now_dt>actual_start and actual_minutes==0: actual_minutes=1
        interval=_booking_base_interval_minutes()
        release_from=_ceil_to_booking_grid(now_dt,interval)
        links=conn.execute("SELECT l.slot_id,s.start_at,s.end_at FROM booking_slot_links l JOIN booking_slots s ON s.id=l.slot_id WHERE l.booking_id=? ORDER BY s.start_at",(appointment_id,)).fetchall()
        for link in links:
            slot_start=parse_local_iso(link["start_at"])
            if now_dt < scheduled_end and slot_start>=release_from:
                conn.execute("UPDATE booking_slots SET status='free',booking_id=NULL,updated_at=? WHERE id=? AND booking_id=?",(stamp,link["slot_id"],appointment_id)); released.append(link["slot_id"])
            else:
                conn.execute("UPDATE booking_slots SET status='completed',updated_at=? WHERE id=? AND booking_id=?",(stamp,link["slot_id"],appointment_id))
        conn.execute("UPDATE bookings SET status='fulfilled',actual_start_at=?,actual_end_at=?,actual_duration_minutes=?,completed_at=?,updated_at=? WHERE id=?",
                     (actual_start.isoformat(),stamp,actual_minutes,stamp,stamp,appointment_id))
        # Keep the observed duration as a reference for this patient-practitioner pair; do not automatically overwrite the estimated duration.
        pref=conn.execute("SELECT estimated_duration_minutes FROM consultation_duration_preferences WHERE patient_id=? AND practitioner_id=?",(row["patient_id"],practitioner_id)).fetchone()
        if pref:
            conn.execute("UPDATE consultation_duration_preferences SET last_actual_duration_minutes=?,updated_at=? WHERE patient_id=? AND practitioner_id=?",(actual_minutes,stamp,row["patient_id"],practitioner_id))
        else:
            conn.execute("INSERT INTO consultation_duration_preferences(patient_id,practitioner_id,estimated_duration_minutes,last_actual_duration_minutes,updated_at) VALUES(?,?,?,?,?)",
                         (row["patient_id"],practitioner_id,row["estimated_duration_minutes"],actual_minutes,stamp))
    early=now_dt < scheduled_end
    audit("complete-consultation",appointment_id,json.dumps({"actual_duration_minutes":actual_minutes,"early_finish":early,"released_slot_ids":released,"base_interval_minutes":_booking_base_interval_minutes()},ensure_ascii=False))
    return jsonify({"ok":True,"id":appointment_id,"status":"fulfilled","actual_start":actual_start.isoformat(),"actual_end":stamp,"actual_duration_minutes":actual_minutes,
                    "early_finish":early,"released_slot_count":len(released),"released_from":release_from.isoformat() if early and released else None,
                    "message":("已提前完成看診，剩餘可用時間已依排程單位重新釋放。" if early and released else "已完成看診並記錄實際看診時間。")})

@app.post("/appointment/<appointment_id>/cancel")
@roles_required("patient","clinician")
def cancel_appointment(appointment_id):
    role=session.get("role")
    with get_db() as conn:
        row=conn.execute("SELECT * FROM bookings WHERE id=?",(appointment_id,)).fetchone()
        if not row: return outcome("找不到此預約",404,"not-found")
        if row["status"]!="booked": return outcome("此預約目前不是可取消狀態",409,"not-booked")
        if role=="patient" and row["patient_id"]!=session.get("patient_id"): return outcome("只能取消自己的預約",403,"forbidden")
        if role=="clinician" and row["practitioner_id"]!=session.get("practitioner_id"): return outcome("只能取消自己負責的預約",403,"forbidden")
        cw=_local_cancel_window(row["created_at"])
        if not cw["can_cancel"]: return outcome(f"此預約建立已超過 {CANCELLATION_WINDOW_MINUTES} 分鐘，為避免濫用已無法自行刪除；如需變更請聯絡對方處理改期",409,"cancellation-window-expired")
        stamp=now_iso(); conn.execute("UPDATE bookings SET status='cancelled',cancelled_at=?,cancelled_by_role=?,updated_at=? WHERE id=?",(stamp,role,stamp,appointment_id))
        links=conn.execute("SELECT slot_id FROM booking_slot_links WHERE booking_id=?",(appointment_id,)).fetchall(); released=[]
        for link in links:
            conn.execute("UPDATE booking_slots SET status='free',booking_id=NULL,updated_at=? WHERE id=? AND booking_id=?",(stamp,link["slot_id"],appointment_id)); released.append(link["slot_id"])
    audit("cancel-appointment",appointment_id,json.dumps({"cancelled_by":role,"released_slot_ids":released,"rule_minutes":CANCELLATION_WINDOW_MINUTES},ensure_ascii=False))
    return jsonify({"ok":True,"id":appointment_id,"status":"cancelled","released_slot_ids":released,"message":"預約已取消，原占用時段已重新開放。"})

def audit_system(action,target="",detail=""):
    try:
        with get_db() as conn:
            conn.execute("INSERT INTO audit_log(at,username,role,action,target,detail) VALUES(?,?,?,?,?,?)",
                         (now_iso(),"SYSTEM","system",action,target,detail))
    except Exception:
        pass



def _rolling_semantic_key(r:dict)->str:
    rt=str(r.get("resourceType") or "")
    if rt=="Observation":
        code=r.get("code") or {}
        for c in code.get("coding") or []:
            if isinstance(c,dict) and c.get("code"):
                return f"obs-{c.get('system','')}-{c.get('code')}"
        return f"obs-{code.get('text') or r.get('id') or 'value'}"
    if rt=="QuestionnaireResponse":
        q=str(r.get("questionnaire") or "questionnaire")
        return "qr-"+q.rsplit('/',1)[-1]
    if rt=="ClinicalImpression":
        return "ci"
    return str(r.get("id") or rt or "resource")

def _sanitize_slot_part(value:str)->str:
    value=re.sub(r"[^A-Za-z0-9._-]+","-",str(value or "")).strip("-")
    return value[:96] or "item"

def hapi_public_retention_plan(resources:list[dict])->tuple[list[dict],dict[str,str],dict]:
    """Keep full local history but expose only the latest N assessments per patient on public HAPI.

    History resources are assigned to 10 reusable remote slots. The 11th assessment reuses
    the slot of the oldest assessment instead of creating an 11th public-history set.
    """
    # Build the complete local assessment timeline so slot assignment stays stable even when
    # background sync receives only the currently dirty/new resources.
    timeline={}
    with get_db() as conn:
        rows=conn.execute("SELECT patient_id,resource_json,effective_date FROM resources WHERE resource_type IN ('Observation','QuestionnaireResponse','ClinicalImpression') AND patient_id IS NOT NULL").fetchall()
    for row in rows:
        try: r=json.loads(row["resource_json"])
        except Exception: continue
        aid=assessment_id_from_resource(r)
        pid=str(row["patient_id"] or "").strip()
        if not pid or not aid: continue
        t=resource_time_value(r) or str(row["effective_date"] or "") or aid
        timeline.setdefault(pid,{})[aid]=max(str(timeline.setdefault(pid,{}).get(aid) or ""),str(t))
    plan={}
    latest_by_patient={}
    for pid,items in timeline.items():
        ordered=sorted(items.items(),key=lambda kv:(kv[1],kv[0]))
        for idx,(aid,_t) in enumerate(ordered):
            plan[(pid,aid)]=(idx % HAPI_PUBLIC_ASSESSMENT_LIMIT)+1
        latest_by_patient[pid]={aid for aid,_ in ordered[-HAPI_PUBLIC_ASSESSMENT_LIMIT:]}

    kept=[]
    grouped={}
    omitted=0
    for r in resources:
        rt=str(r.get("resourceType") or "")
        if rt not in HAPI_HISTORY_RESOURCE_TYPES:
            kept.append(r); continue
        pid=extract_patient_id(rt,r)
        aid=assessment_id_from_resource(r)
        # Legacy ungrouped history stays local only. Public HAPI is intentionally assessment-based.
        if not pid or not aid or aid not in latest_by_patient.get(pid,set()):
            omitted+=1; continue
        kept.append(r)
        grouped.setdefault((pid,aid,rt),[]).append(r)

    rolling_keys={}
    for (pid,aid,rt),items in grouped.items():
        slot=plan.get((pid,aid),1)
        pseudo=fhir_pseudonym_for_patient(pid)
        # Stable order inside an assessment; semantic key keeps HR/SpO2/HRV etc. in consistent slots.
        items=sorted(items,key=lambda r:(_rolling_semantic_key(r),resource_time_value(r),str(r.get("id") or "")))
        seen={}
        for r in items:
            semantic=_sanitize_slot_part(_rolling_semantic_key(r))
            seen[semantic]=seen.get(semantic,0)+1
            suffix=f"-{seen[semantic]}" if seen[semantic]>1 else ""
            local_ref=f"{rt}/{r.get('id')}"
            rolling_keys[local_ref]=f"{pseudo}-slot{slot:02d}-{rt}-{semantic}{suffix}"
    stats={
        "assessmentLimit":HAPI_PUBLIC_ASSESSMENT_LIMIT,
        "omittedOlderHistoryResources":omitted,
        "patientsWithAssessmentHistory":len(latest_by_patient),
        "latestAssessmentCounts":{pid:len(v) for pid,v in latest_by_patient.items()}
    }
    return kept,rolling_keys,stats

def get_fhir_sync_map():
    with get_db() as conn:
        rows=conn.execute("SELECT local_ref,remote_ref FROM fhir_sync_state").fetchall()
    return {r["local_ref"]:r["remote_ref"] for r in rows}

def get_resources_for_sync(dirty_only=False):
    # 僅取得競賽核心的病人健康 FHIR Resource。排班、預約與 Encounter 永不送往 HAPI。
    allowed=sorted(HAPI_SYNC_RESOURCE_TYPES)
    placeholders=",".join("?" for _ in allowed)
    sql=f"SELECT resource_type,id,resource_json,updated_at FROM resources WHERE resource_type IN ({placeholders})"
    params=list(allowed)
    if dirty_only:
        sql += " AND NOT EXISTS (SELECT 1 FROM fhir_sync_state s WHERE s.local_ref=(resources.resource_type || '/' || resources.id) AND COALESCE(s.last_synced_updated_at,'')=COALESCE(resources.updated_at,''))"
    sql += " ORDER BY resource_type,id"
    with get_db() as conn:
        rows=conn.execute(sql,params).fetchall()
    return [(json.loads(r["resource_json"]),r["updated_at"]) for r in rows]

def remember_sync_result(id_map, local_updated_map):
    stamp=now_iso()
    with get_db() as conn:
        for local_ref,remote_ref in (id_map or {}).items():
            if local_ref not in local_updated_map:
                continue
            if not isinstance(local_ref,str) or not isinstance(remote_ref,str) or "/" not in local_ref or "/" not in remote_ref:
                continue
            conn.execute("INSERT INTO fhir_sync_state(local_ref,remote_ref,last_synced_updated_at,last_sync_at) VALUES(?,?,?,?) "
                         "ON CONFLICT(local_ref) DO UPDATE SET remote_ref=excluded.remote_ref,last_synced_updated_at=excluded.last_synced_updated_at,last_sync_at=excluded.last_sync_at",
                         (local_ref,remote_ref,local_updated_map.get(local_ref),stamp))

def perform_hapi_sync(resources,filename,dirty_only=False,background=False):
    try:
        if dirty_only:
            pairs=get_resources_for_sync(True); resources=[r for r,_ in pairs]
        else:
            pairs=[]
        if not resources:
            result={"ok":True,"skipped":True,"message":"目前沒有尚未同步或已更新的 FHIR 資料。","processedCount":0,"createdCount":0,"updatedCount":0,"idMap":{}}
            return result if background else jsonify(result)
        # 即使手動上傳端點傳入本機所有 Resource，也只允許核心健康資料進 HAPI。
        local_only_types=sorted({str(r.get("resourceType") or "") for r in resources if r.get("resourceType") not in HAPI_SYNC_RESOURCE_TYPES})
        skipped_local_only_count=sum(1 for r in resources if r.get("resourceType") not in HAPI_SYNC_RESOURCE_TYPES)
        resources=[r for r in resources if r.get("resourceType") in HAPI_SYNC_RESOURCE_TYPES]
        if not resources:
            result={"ok":True,"skipped":True,"message":"目前沒有需要同步的核心病人健康 FHIR 資料。","processedCount":0,"createdCount":0,"updatedCount":0,"idMap":{},"skippedLocalOnlyResources":skipped_local_only_count,"skippedLocalOnlyTypes":local_only_types}
            return result if background else jsonify(result)
        resources,rolling_slot_keys,retention_stats=hapi_public_retention_plan(resources)
        if not resources:
            result={"ok":True,"skipped":True,"message":"目前沒有屬於最近 10 次 Assessment 的核心 FHIR 資料需要同步。","processedCount":0,"createdCount":0,"updatedCount":0,"idMap":{},"publicRetention":retention_stats}
            return result if background else jsonify(result)
        upload_resources,pseudonyms=pseudonymize_resources_for_hapi(resources)
        # Organization 不對外同步，因此移除 Patient 上可能存在的 managingOrganization，避免形成懸空 reference。
        for r in upload_resources:
            if r.get("resourceType")=="Patient":
                r.pop("managingOrganization",None)
        result=upload_ppg_demo(upload_resources, existing_id_map=get_fhir_sync_map(), rolling_slot_keys=rolling_slot_keys)
        result["publicRetention"]=retention_stats
        result["skippedLocalOnlyResources"]=skipped_local_only_count
        result["skippedLocalOnlyTypes"]=local_only_types
        for local_pid,pseudo in pseudonyms.items():
            remote_ref=(result.get("idMap") or {}).get(f"Patient/{local_pid}")
            if isinstance(remote_ref,str) and remote_ref.startswith("Patient/"):
                remember_remote_patient_id(local_pid,remote_ref.split("/",1)[1])
        if dirty_only:
            local_updated_map={f"{r.get('resourceType')}/{r.get('id')}":u for r,u in pairs if r.get('resourceType') and r.get('id')}
        else:
            with get_db() as conn:
                rows=conn.execute("SELECT resource_type,id,updated_at FROM resources").fetchall()
            local_updated_map={f"{r['resource_type']}/{r['id']}":r['updated_at'] for r in rows}
        remember_sync_result(result.get("idMap") or {},local_updated_map)
        result["privacyMode"]="pseudonymized"; result["pseudonymizedPatients"]=len(pseudonyms)
        result["privacyNote"]="HAPI Patient 不包含本機登入身分證與真實姓名；本機以隨機 pseudonym 對照。公用 HAPI 每位病人僅循環保留最近 10 次 Assessment 展示資料，本機仍保留完整歷史。"
        outdir=BASE_DIR/"hapi_results"; outdir.mkdir(exist_ok=True); path=outdir/filename
        path.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
        result["savedResultFile"]=str(path.relative_to(BASE_DIR))
        return result if background else jsonify(result)
    except (HapiFhirError,ValueError,KeyError,OSError) as exc:
        if background: raise
        return outcome(str(exc),502,"exception")

def auto_sync_once():
    set_setting("fhir_auto_sync_last_attempt",now_iso())
    try:
        result=perform_hapi_sync([],"latest_auto_sync_readback.json",dirty_only=True,background=True)
        set_setting("fhir_auto_sync_last_success",now_iso()); set_setting("fhir_auto_sync_last_error","")
        audit_system("hapi-auto-sync","dirty-local-resources",json.dumps({"processed":result.get("processedCount",0),"created":result.get("createdCount",0),"updated":result.get("updatedCount",0),"skipped":result.get("skipped",False)},ensure_ascii=False))
        return result
    except Exception as exc:
        set_setting("fhir_auto_sync_last_error",str(exc)[:1000]); audit_system("hapi-auto-sync-failed","dirty-local-resources",str(exc)[:1000]); raise

def auto_sync_loop():
    import time
    while True:
        try:
            enabled=get_setting("fhir_auto_sync_enabled","1")=="1"
            try: interval=max(5,min(1440,int(get_setting("fhir_auto_sync_interval_minutes","60"))))
            except (TypeError,ValueError): interval=60
            last=get_setting("fhir_auto_sync_last_attempt",""); due=False
            if not last:
                set_setting("fhir_auto_sync_last_attempt",now_iso())
            else:
                try: due=(datetime.now(TZ_TAIPEI)-datetime.fromisoformat(last)).total_seconds() >= interval*60
                except Exception: due=True
            if enabled and due: auto_sync_once()
        except Exception as exc:
            print(f"[FHIR AUTO SYNC] {now_iso()} failed: {exc}")
        time.sleep(60)

@app.get("/hapi/status")
@login_required
def hapi_status():
    try:
        m=server_metadata(); return jsonify({"ok":True,"server":get_base_url(),"fhirVersion":m.get("fhirVersion"),"software":m.get("software")})
    except HapiFhirError as exc: return outcome(str(exc),502,"exception")


def _upload(resources,filename):
    return perform_hapi_sync(resources,filename,dirty_only=False,background=False)

@app.post("/hapi/upload-demo")
@roles_required("clinician","admin")
def hapi_upload_demo():
    resources=[]
    for rt in HAPI_SYNC_RESOURCE_TYPES: resources.extend(search_local(rt))
    audit("hapi-upload","patient-core-fhir-resources"); return _upload(resources,"latest_upload_and_readback.json")

@app.post("/hapi/upload-manual")
@roles_required("clinician","admin")
def hapi_upload_manual():
    from seed_demo import generate_samples_from_input, replace_local_demo
    try: resources=generate_samples_from_input(request.get_json(silent=True) or {}); replace_local_demo(resources)
    except ValueError as exc: return outcome(str(exc))
    return _upload(resources,"latest_manual_upload_and_readback.json")

@app.get("/hapi/latest-result")
@login_required
def latest_result():
    files=list((BASE_DIR/"hapi_results").glob("latest*_readback.json")) if (BASE_DIR/"hapi_results").exists() else []
    if not files: return outcome("尚無 HAPI 上傳結果",404,"not-found")
    latest=max(files,key=lambda p:p.stat().st_mtime); payload=json.loads(latest.read_text(encoding="utf-8")); payload["resultFile"]=str(latest.relative_to(BASE_DIR)); return jsonify(payload)

if __name__=="__main__":
    init_db()
    threading.Thread(target=auto_sync_loop,name="fhir-auto-sync",daemon=True).start()
    # 首次啟動會由 init_db() 建立三種角色的競賽測試帳號與必要 FHIR 身分。
    port=int(os.getenv("PORT","5000"))
    if os.getenv("AUTO_OPEN_BROWSER","1")=="1": threading.Timer(1.2,lambda:webbrowser.open_new(f"http://127.0.0.1:{port}/demo-start")).start()
    app.run(host="0.0.0.0",port=port,debug=os.getenv("FLASK_DEBUG")=="1",use_reloader=False)

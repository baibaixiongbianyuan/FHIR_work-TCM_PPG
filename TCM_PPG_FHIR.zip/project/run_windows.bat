@echo off
setlocal EnableExtensions
cd /d "%~dp0"
chcp 65001 >nul

set "HEALTH_URL=http://127.0.0.1:5000/"
set "APP_URL=http://127.0.0.1:5000/demo-start"
set "PYTHON_CMD="
where py >nul 2>nul && set "PYTHON_CMD=py -3"
if not defined PYTHON_CMD (
  where python >nul 2>nul && set "PYTHON_CMD=python"
)
if not defined PYTHON_CMD (
  echo [ERROR] Python 3 was not found.
  echo Please install Python 3.11 or newer and enable "Add Python to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo [1/5] Creating virtual environment...
  %PYTHON_CMD% -m venv .venv || goto :error
)
set "PY=%CD%\.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo [ERROR] Virtual-environment Python was not found.
  goto :error
)

echo [2/5] Installing required packages...
"%PY%" -m pip install --disable-pip-version-check -r requirements.txt || goto :error

echo [3/5] Initializing database...
"%PY%" database.py || goto :error

rem If a healthy server is already running, just open it.
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri '%HEALTH_URL%' -TimeoutSec 2; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if not errorlevel 1 (
  echo [4/5] Website server is already running.
  echo [5/5] Opening browser...
  start "" "%APP_URL%"
  timeout /t 1 /nobreak >nul
  exit /b 0
)

rem Remove a stale PID file. If that PID is still alive but the HTTP service is not,
rem terminate only that previously recorded process before restarting.
if exist ".server.pid" (
  set /p OLD_PID=<.server.pid
  if defined OLD_PID (
    tasklist /FI "PID eq %OLD_PID%" 2>nul | find "%OLD_PID%" >nul
    if not errorlevel 1 taskkill /PID %OLD_PID% /T /F >nul 2>nul
  )
  del /q ".server.pid" >nul 2>nul
)

if exist "server.log" del /q "server.log" >nul 2>nul

echo [4/5] Starting website in background...
for /f %%P in ('powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=Start-Process -WindowStyle Hidden -FilePath '%PY%' -ArgumentList 'server_background.py' -WorkingDirectory '%CD%' -PassThru; $p.Id"') do set "SERVER_PID=%%P"
if not defined SERVER_PID (
  echo [ERROR] Could not start the background server process.
  goto :showlog
)
> .server.pid echo %SERVER_PID%

rem Wait until Flask really answers before opening the browser. This prevents the
rem page from opening against a dead/not-yet-ready API and showing "Failed to fetch".
set "READY="
for /L %%I in (1,1,30) do (
  powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -Uri '%HEALTH_URL%' -TimeoutSec 1; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
  if not errorlevel 1 (
    set "READY=1"
    goto :ready
  )
  tasklist /FI "PID eq %SERVER_PID%" 2>nul | find "%SERVER_PID%" >nul
  if errorlevel 1 goto :showlog
  timeout /t 1 /nobreak >nul
)

goto :showlog

:ready
echo [5/5] Server is ready. Opening browser...
start "" "%APP_URL%"
timeout /t 1 /nobreak >nul
exit /b 0

:showlog
echo.
echo [ERROR] The website server did not become ready.
echo Background PID: %SERVER_PID%
echo.
if exist "server.log" (
  echo ===== server.log =====
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-Content -Path 'server.log' -Tail 60" 2>nul
  echo ======================
) else (
  echo No server.log was produced.
)
if exist ".server.pid" del /q ".server.pid" >nul 2>nul
pause
exit /b 1

:error
echo.
echo Startup failed. Check the error above.
pause
exit /b 1

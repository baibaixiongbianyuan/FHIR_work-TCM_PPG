from seed_demo import generate_samples
from hapi_client import server_metadata,upload_ppg_demo,get_base_url
import json
from pathlib import Path

def main():
    print('1/3 檢查 HAPI FHIR Server：',get_base_url())
    meta=server_metadata(); print('FHIR version:',meta.get('fhirVersion'))
    print('2/3 建立並上傳新版三角色/問卷/PPG/預約相關 FHIR 資源...')
    result=upload_ppg_demo(generate_samples())
    out=Path(__file__).resolve().parent/'hapi_results'/'latest_upload_and_readback.json'; out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('3/3 完成 POST + GET read-back：',result['createdCount'],'resources')
    print('結果：',out)
if __name__=='__main__': main()

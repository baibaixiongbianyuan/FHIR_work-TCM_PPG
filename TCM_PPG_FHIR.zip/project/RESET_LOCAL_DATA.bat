@echo off
setlocal
cd /d "%~dp0"
chcp 65001 >nul

echo ==========================================================
echo  警告：這會清除本機 SQLite 帳號、病人及本機 FHIR 資料
echo  不會刪除已經上傳到外部 HAPI FHIR Server 的資料
echo ==========================================================
echo.
set /p CONFIRM=若確定要重設，請輸入 RESET 後按 Enter: 
if /I not "%CONFIRM%"=="RESET" (
  echo 已取消。
  pause
  exit /b 0
)

if exist "database.db" del /f /q "database.db"
if exist "hapi_results" rmdir /s /q "hapi_results"
if exist "__pycache__" rmdir /s /q "__pycache__"

echo.
echo 本機資料已清除。
echo 下次執行 START.bat 時會建立全新資料庫，僅保留初始管理員：admin / admin123
echo.
pause

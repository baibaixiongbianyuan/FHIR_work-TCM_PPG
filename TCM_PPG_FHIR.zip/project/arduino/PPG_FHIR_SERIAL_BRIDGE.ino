#include <SparkFun_Bio_Sensor_Hub_Library.h>
#include <Wire.h>

// Arduino Nano 33 IoT + SparkFun MAX30101 & MAX32664
// 依你們原本接線：RESET=4, MFIO=5
int resPin = 4;
int mfioPin = 5;
SparkFun_Bio_Sensor_Hub bioHub(resPin, mfioPin);
bioData body;

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 4000) {}
  Wire.begin();

  int result = bioHub.begin();
  if (result != 0) {
    Serial.println("{\"status\":\"sensor_init_failed\"}");
    return;
  }
  bioHub.configBpm(MODE_TWO);
  delay(4000);
}

void loop() {
  body = bioHub.readBpm();

  // 每行一個 JSON，供 Python ppg_device.py 直接解析。
  // MAX32664 常見 BPM 輸出包含 heartRate / oxygen / confidence，
  // 不強行把 confidence 或其他欄位當成 HRV。
  if (body.heartRate > 0 && body.oxygen > 0) {
    Serial.print("{\"heartRate\":");
    Serial.print(body.heartRate);
    Serial.print(",\"oxygen\":");
    Serial.print(body.oxygen);
    Serial.print(",\"confidence\":");
    Serial.print(body.confidence);
    Serial.println("}");
  }
  delay(500);
}

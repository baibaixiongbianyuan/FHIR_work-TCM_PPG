from app import init_db, DB_PATH

if __name__ == "__main__":
    init_db()
    print(f"Database ready: {DB_PATH}")

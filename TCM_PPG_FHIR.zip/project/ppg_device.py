from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, asdict
from typing import Any

try:
    import serial
    from serial.tools import list_ports
except Exception:  # pyserial is optional at import time; API reports unavailable cleanly
    serial = None
    list_ports = None


DEVICE_HINTS = ("arduino", "nano", "sparkfun", "usb serial", "usb-serial", "cp210", "ch340", "acm")


@dataclass
class PortInfo:
    device: str
    description: str = ""
    manufacturer: str = ""
    product: str = ""
    serial_number: str = ""
    vid: int | None = None
    pid: int | None = None
    score: int = 0

    def public(self) -> dict[str, Any]:
        d = asdict(self)
        if d.get("vid") is not None:
            d["vid"] = f"{d['vid']:04X}"
        if d.get("pid") is not None:
            d["pid"] = f"{d['pid']:04X}"
        return d


def _score_port(p: Any) -> int:
    text = " ".join(str(x or "") for x in (getattr(p, "description", ""), getattr(p, "manufacturer", ""), getattr(p, "product", ""))).lower()
    score = sum(3 for hint in DEVICE_HINTS if hint in text)
    # Arduino SA common VID, plus a small score for any USB serial device.
    if getattr(p, "vid", None) in {0x2341, 0x2A03}: score += 10
    if getattr(p, "vid", None) is not None: score += 1
    return score


def list_candidate_ports() -> list[PortInfo]:
    if list_ports is None:
        return []
    out: list[PortInfo] = []
    for p in list_ports.comports():
        out.append(PortInfo(
            device=p.device,
            description=p.description or "",
            manufacturer=p.manufacturer or "",
            product=getattr(p, "product", "") or "",
            serial_number=p.serial_number or "",
            vid=p.vid,
            pid=p.pid,
            score=_score_port(p),
        ))
    return sorted(out, key=lambda x: (-x.score, x.device))


def detect_ppg_device() -> dict[str, Any]:
    if serial is None:
        return {"available": False, "reason": "pyserial-not-installed", "ports": [], "message": "未安裝 pyserial，將使用手動輸入。"}
    ports = list_candidate_ports()
    if not ports:
        return {"available": False, "reason": "no-serial-port", "ports": [], "message": "未偵測到序列埠裝置，請使用手動輸入。"}
    best = ports[0]
    # score>0 means it resembles Arduino/USB serial. If only unknown ports exist, expose them but do not claim a PPG device.
    available = best.score > 0
    return {
        "available": available,
        "reason": "candidate-found" if available else "unknown-serial-port",
        "selected": best.public() if available else None,
        "ports": [p.public() for p in ports],
        "message": (f"偵測到候選 PPG 載具：{best.device} {best.description}" if available else "偵測到序列埠，但無法確認為 Arduino/PPG；請手動選擇或使用手動輸入。"),
    }


def _to_float(v: Any) -> float | None:
    try:
        if v in (None, ""): return None
        return float(v)
    except (TypeError, ValueError):
        return None


def _normalize_payload(obj: dict[str, Any]) -> dict[str, float | None]:
    keys = {str(k).lower().replace("_", "").replace("-", ""): v for k, v in obj.items()}
    heart = next((_to_float(keys[k]) for k in ("heartrate", "heart", "hr", "bpm") if k in keys), None)
    spo2 = next((_to_float(keys[k]) for k in ("spo2", "oxygen", "oxygensaturation") if k in keys), None)
    hrv = next((_to_float(keys[k]) for k in ("hrv", "rmssd", "hrvrmssd") if k in keys), None)
    confidence = next((_to_float(keys[k]) for k in ("confidence", "conf") if k in keys), None)
    return {"heartRate": heart, "spo2": spo2, "hrv": hrv, "confidence": confidence}


def parse_sensor_line(line: str) -> dict[str, float | None] | None:
    line = line.strip()
    if not line:
        return None
    # Preferred firmware format: one JSON object per line.
    try:
        obj = json.loads(line)
        if isinstance(obj, dict):
            data = _normalize_payload(obj)
            if data["heartRate"] is not None or data["spo2"] is not None or data["hrv"] is not None:
                return data
    except Exception:
        pass

    # Accept human-readable lines such as: heartRate=72 oxygen=98 hrv=42
    pairs = re.findall(r"([A-Za-z][A-Za-z0-9_-]*)\s*[:=]\s*(-?\d+(?:\.\d+)?)", line)
    if pairs:
        data = _normalize_payload(dict(pairs))
        if data["heartRate"] is not None or data["spo2"] is not None or data["hrv"] is not None:
            return data

    # Last-resort CSV: heartRate,spo2,hrv (third field optional)
    if re.fullmatch(r"\s*-?\d+(?:\.\d+)?\s*,\s*-?\d+(?:\.\d+)?(?:\s*,\s*-?\d+(?:\.\d+)?)?\s*", line):
        vals = [float(x.strip()) for x in line.split(",")]
        return {"heartRate": vals[0], "spo2": vals[1], "hrv": vals[2] if len(vals) > 2 else None, "confidence": None}
    return None


def _valid(data: dict[str, float | None]) -> bool:
    hr, spo2, hrv = data.get("heartRate"), data.get("spo2"), data.get("hrv")
    if hr is not None and not 30 <= hr <= 220: return False
    if spo2 is not None and not 70 <= spo2 <= 100: return False
    if hrv is not None and not 1 <= hrv <= 300: return False
    return hr is not None or spo2 is not None or hrv is not None


def read_ppg_sample(port: str | None = None, baudrate: int = 115200, timeout_seconds: float = 8.0) -> dict[str, Any]:
    if serial is None:
        raise RuntimeError("pyserial 未安裝")
    candidates = list_candidate_ports()
    if not port:
        candidates = [p for p in candidates if p.score > 0]
        if not candidates:
            raise RuntimeError("未偵測到可用的 Arduino/PPG 序列埠")
        port = candidates[0].device
    info = next((p for p in list_candidate_ports() if p.device == port), PortInfo(device=port))

    deadline = time.monotonic() + max(1.0, min(timeout_seconds, 20.0))
    samples: list[dict[str, float | None]] = []
    raw_tail: list[str] = []
    try:
        with serial.Serial(port=port, baudrate=int(baudrate), timeout=0.6) as ser:
            # Many Arduino boards reset when the serial port opens.
            time.sleep(1.5)
            try: ser.reset_input_buffer()
            except Exception: pass
            while time.monotonic() < deadline:
                raw = ser.readline().decode("utf-8", errors="ignore").strip()
                if not raw: continue
                raw_tail.append(raw[:240]); raw_tail = raw_tail[-5:]
                parsed = parse_sensor_line(raw)
                if parsed and _valid(parsed):
                    samples.append(parsed)
                    if len(samples) >= 3: break
    except Exception as exc:
        raise RuntimeError(f"無法讀取 {port}：{exc}") from exc

    if not samples:
        raise RuntimeError("已連線序列埠，但沒有讀到可辨識的 PPG 資料。韌體請輸出 JSON、key=value 或 CSV。")

    def avg(key: str) -> float | None:
        vals = [float(s[key]) for s in samples if s.get(key) is not None]
        return round(sum(vals) / len(vals), 2) if vals else None

    data = {"heartRate": avg("heartRate"), "spo2": avg("spo2"), "hrv": avg("hrv"), "confidence": avg("confidence")}
    return {
        "ok": True,
        "source": "device",
        "port": info.public(),
        "baudrate": int(baudrate),
        "samplesUsed": len(samples),
        "data": data,
        "missing": [k for k in ("heartRate", "spo2", "hrv") if data.get(k) is None],
        "rawTail": raw_tail,
    }
